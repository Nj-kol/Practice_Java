package com.bdcoe.api

import java.nio.charset.Charset
import java.nio.file.Paths
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.{IvParameterSpec, PBEKeySpec, SecretKeySpec}

import com.jio.bdcoe.conf.ConfigLoader
import com.jio.bdcoe.utils.io.FileUtils

/**
 * Generates two keys :
 *
 * 1. Base64 encoded Secret key
 * 2. Base64 encoded intialization vector
 *
 * @author Nilanjan
 */
object GenerateMasterKey extends App {

  if (args.length != 1) {
    println("Usage : <dbtype>")
    System.exit(1)
  }

  private val dbType = args(0).trim
  private val secretsStrategy = "PBKDF2WithHmacSHA256"
  private val fileName = s"${dbType}-api-secure.properties"
  private val factory = SecretKeyFactory.getInstance(secretsStrategy)
  private val confLoader = ConfigLoader.getInstance
  private val config = confLoader.getConfig

  // Get the values needed to create the master key
  private val secretPhrase = config.getString(s"com.jio.bdcoe.${dbType}.security.passphrase")
  private val salt = config.getString(s"com.jio.bdcoe.${dbType}.security.salt")
  private val ivText = config.getString(s"com.jio.bdcoe.${dbType}.security.ivseed")

  private def encode(data: Array[Byte]) = Base64.getEncoder.encodeToString(data)

  private def generateMasterKeys(passphrase: String, salt: String) {

    val spec = new PBEKeySpec(passphrase.toCharArray, salt.getBytes, 65536, 256)
    val secret = new SecretKeySpec(factory.generateSecret(spec).getEncoded, "AES")
    val ivspec = new IvParameterSpec(ivText.getBytes(Charset.forName("UTF8")))

    val sb = new StringBuilder()
    val specProp =
      s"""
        com.jio.bdcoe.${dbType}.security.spec="${encode(secret.getEncoded)}"
        """.trim
    val ivProp =
      s"""
        com.jio.bdcoe.${dbType}.security.iv="${encode(ivspec.getIV)}"
        """.trim

    sb.append(specProp)
    sb.append("\n")
    sb.append(ivProp)

    // Write the master keys to disk
    val currDir = Paths.get(".").toAbsolutePath
    FileUtils.writeFile(s"${currDir}/${fileName}",sb.toString())
  }

  generateMasterKeys(secretPhrase,salt)
}