package com.bdcoe.api

import java.io.File
import java.util.Base64
import scala.io.Source
import com.typesafe.config.ConfigFactory
import com.jio.bdcoe.conf.ConfigLoader
import com.jio.bdcoe.utils.encryption.EncryptionUtils
import com.jio.bdcoe.utils.io.FileUtils

/**
 * Generates token for API users
 *
 * @author Nilanjan Sarkar
 */
object TokenGenerator extends App {

  if (args.length < 1) {
    println("Please specify Datastore")
    System.exit(1)
  }

  private val confLoader = ConfigLoader.getInstance
  private val dbType = args(0).trim.toLowerCase()

  dbType match {
    case "hive" => {
      if (args.length != 3) {
        println("Usage : <dbType> <principal> <keyTabPath>")
        System.exit(1)
      }
      val principal = args(1)
      val keyTabPath = args(2)
      generateTokenForKerberosDatasources(principal,keyTabPath)
    }
    case "oracle" | "mysql" => {
      if (args.length != 5) {
        println("Usage : <dbType> <schemaName> <dbUser> <dbPassWord> <use-case>")
        System.exit(1)
      }
      val schemaName = args(1)
      val dbUser = args(2)
      val dbPassWord = args(3)
      val usecase = args(4)
      generateTokenForPBDataSources(dbType,schemaName,dbUser,dbPassWord,usecase)
    }
  }

  /**
   * Generate token for Datasources which have password based authentication
   *
   * @param dbType
   * @param schemaName
   * @param dbUser
   * @param dbPassWord
   * @param usecase
   */
  private def generateTokenForPBDataSources(dbType: String,schemaName: String,dbUser: String,dbPassWord: String,usecase: String): Unit = {
    val MASTER_KEY_CONF = confLoader.getSysPropOrEnv(s"bdcoe.${dbType}.security.master.conf.file",s"${dbType}-api-secure.properties")
    val secureConfig = if(new File(MASTER_KEY_CONF).exists) ConfigFactory.parseReader(Source.fromFile(MASTER_KEY_CONF).bufferedReader()) else null
    val config = confLoader.getConfig.withFallback(secureConfig)
    val secretKey = config.getString(s"com.jio.bdcoe.${dbType}.security.spec")
    val iv = config.getString(s"com.jio.bdcoe.${dbType}.security.iv")
    val passfileBaseLocation = config.getString(s"com.jio.bdcoe.${dbType}.security.passfiles.baselocation")

    // Step 1 : encrypt the file and write
    val encryptedPass = EncryptionUtils.encrypt(dbPassWord,secretKey,iv)

    // Step 2: Generate a file name
    val fileName = s"${passfileBaseLocation}/${usecase}_${dbUser}"

    // Step 3: Write the encrypted password to file
    FileUtils.writeFile(fileName,encryptedPass)

    // Step 4: Generate the token
    val token =
      s"""
      {"schema":"${schemaName}","username":"${dbUser}","passfile":"${fileName}"}
      """.trim

    println(s"Got token ${token}")
    println(s"Encoded Token ${Base64.getEncoder.encodeToString(token.getBytes)}")
  }

  private def generateTokenForKerberosDatasources(principal: String,keyTabPath: String): Unit = {
    val token =
      s"""
      {"principal":"${principal}","keytab":"${keyTabPath}"}
      """.trim

    println(s"Got token ${token}")
    println(s"Encoded Token ${Base64.getEncoder.encodeToString(token.getBytes)}")
  }

}
