import sbt.Keys.{artifactName, publishLocalConfiguration, _}
import sbt.librarymanagement.{Artifact, ModuleID, ScalaVersion}
import sbt.{AutoPlugin, Compile}
import sbt._
import sbtassembly.AssemblyPlugin.autoImport.assembly

object PublishArtifactPlugin extends AutoPlugin {

  override def projectSettings = Seq(
    organization := "com.jio.bdcoe",
    isSnapshot := false,
    scalaVersion := "2.11.12",
    publishMavenStyle := true,
    updateOptions := updateOptions.value.withGigahorse(false),
    publishArtifact in (Compile, packageDoc) := false,
    publishArtifact in (Compile, packageSrc) := false,
    version := {
      val verSuffix = if (isSnapshot.value) "-SNAPSHOT" else ""
      "0.1.0"+verSuffix
    },
    crossPaths := false,

    publishConfiguration := publishConfiguration.value.withOverwrite(true),
    publishLocalConfiguration := publishLocalConfiguration.value.withOverwrite(true),

    artifactName := { (sv: ScalaVersion, module: ModuleID, artifact: Artifact) =>
      artifact.name + "-" + module.revision + "." + artifact.extension
    },
    publishTo := {
      val repoUri = "http://10.141.51.157:9081/repository/JEP_Artifact_3rdParty"
      if (isSnapshot.value)
        Some("snapshots" at repoUri)
      else
        Some("releases"  at repoUri)
    },
    artifact in (Compile, assembly) := {
      val art = (artifact in (Compile, assembly)).value
      art.withClassifier(Some("assembly"))
    }
  )
}
