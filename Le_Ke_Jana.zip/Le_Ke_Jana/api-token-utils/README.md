# API Token Utility

## Generate Master Key

Usage :

```bash
# Syntax
java \
-Dbdcoe.ext.conf.file="${SOME_PATH}/api-service-config.properties" \
-cp "/home/centos/nilanjan/rest_services/mysql/auth-token/api-token-utils.jar" \
com.bdcoe.api.GenerateMasterKey <dbType>

# Example

java \
-Dbdcoe.ext.conf.file="${PWD}/api-service-config.properties" \
-cp "/home/centos/nilanjan/rest_services/mysql/auth-token/api-token-utils.jar" \
com.bdcoe.api.GenerateMasterKey oracle
```

This will generate a file containing master keys (created using AES) called `mysql-api-secure.properties` in the directory where it is run from from

Sample contents of the file :

```bash
com.jio.bdcoe.oracle.security.spec="G4AG0Ti7Y6FpGGnPM8T+Fib86Zh8oN0sJoJqyHl4urc="
com.jio.bdcoe.oracle.security.iv="cmVzdC1hcGktNTg3ODY4MY=="
```

## Generate Token for API Tenants

Usage :

```bash
java -cp \
-Dbdcoe.mysql.security.master.conf.file="${SOME_PATH}/mysql-api-secure.properties" \
-Dbdcoe.ext.conf.file="${SOME_PATH}/api-service-config.properties" \
"/home/centos/nilanjan/rest_services/mysql/api-token-utils.jar" \
com.bdcoe.api.TokenGenerator \
<dbType> <schemaName> <dbUser> <dbPassWord> <usecase_name>

# Example
java \
-Dbdcoe.oracle.security.master.conf.file="${PWD}/oracle-api-secure.properties" \
-Dbdcoe.ext.conf.file="${PWD}/api-service-config.properties" \
-cp "${PWD}/api-token-utils.jar" \
com.bdcoe.api.TokenGenerator \
"oracle" "ORCLEDEV" "devuser" "devuser#321" "parivartan"
```

Output :

```bash
Got token {"schema":"ORCLEDEV","username":"devuser","passfile":"/home/centos/nilanjan/rest_services/oracle/auth-token/passfiles/parivartan_devuser"}
Encoded Token eyJzY2hlbWEiOiJPUkNMRURFViIsInVzZXJuYW1lIjoiZGV2dXNlciIsInBhc3NmaWxlIjoiL2hvbWUvY2VudG9zL25pbGFuamFuL3Jlc3Rfc2VydmljZXMvb3JhY2xlL2F1dGgtdG9rZW4vcGFzc2ZpbGVzL3Bhcml2YXJ0YW5fZGV2dXNlciJ9
```