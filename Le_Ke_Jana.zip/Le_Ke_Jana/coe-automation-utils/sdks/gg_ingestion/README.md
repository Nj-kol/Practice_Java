# Golden Gate (GG) Ingestion SDK

To create a master for Golden Gate(GG) based ingestions, a lot of manual work is involved. :

- Find the primary keys for GG by looking at the external table for GG
- Create a DDL script for a master table by describing the external GG table, paste definition to notepad and making the necessary changes such as adding partition clause, changing the format to ORC, defining bloom filters for primary key columns
- manually create a folder structure with `historical` and `incremental` folder
- for every table to create a master for creating two files, one in `historical` and `incremental` folder
- Once all this is done, add entries for the same in the `properties` file as well.

just to name a few.

The endeavor is to create an SDK that automates this entire flow. For example, just give the name of the GG external table and everything will be created automatically.

## Usage

## Step 1 : Define a seed spec

Go the location where the code has ben installed ( Ex - `cd /home/Nilanjan1.Sarkar/sdks/gg_ingestion` )

* Create a seed specification file  ( The name can be anything )

```bash
vim seed_spec.properties
```

**Sample**

```
gg.dir.prefix=rilprod

default.developer.name=nilanjan
default.gg.schema.name=network_dev
default.master.schema.name=network_dev

scripts.base=/home/Nilanjan1.Sarkar/sdks

release.name=infra_recon_phase_three

masters.log.dir=/home/Nilanjan1.Sarkar/one_infra/logs/infra_recon_phase_three/masters
masters.log.retention.period=1

master.ingestion.jobs.to.execute=udc_instance,udc_role_inst,udc_def,udc_role_def
```

**Assumptions**

Most GG artifacts follow the convention :

```
Data path   : hdfs dfs -ls /ogg1/<schema_in_lowercase>.<table_name_in_lowercase>
Schema path : hdfs dfs -ls /ogg1/avro_def/<schema_in_lowercase>.<table_name_in_uppercase>.avsc 

Examples -

hdfs dfs -ls /ogg1/rilprod.udc_role_inst
hdfs dfs -ls /ogg1/avro_def/RILPROD.UDC_ROLE_INST.avsc 

hdfs dfs -ls /ogg1/zabbixlf.events
hdfs dfs -ls /ogg1/avro_def/ZABBIXLF.EVENTS.avsc
```

So, the table names mentioned in the property `master.ingestion.jobs.to.execute` should be consistent with that

## Step 2 : Generate the spec

```bash
sh generate_gg_master_artifacts.sh \
/home/Nilanjan1.Sarkar/sdks/gg_ingestion/seed_spec.properties \
/home/Nilanjan1.Sarkar/one_infra/init/conf/jdbl-dev-coe-env.properties
```

* Check 

```bash
ls -l /home/Nilanjan1.Sarkar/sdks
ls -l /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three

vim /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/masters/ddl/gg_external_table_ddl.hql
vim /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/masters/ddl/masters_ddl.hql

vim /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/conf/infra_recon_phase_three.properties

ls -al /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/masters/dataload/historical
ls -al /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/masters/dataload/incremental

vim /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/masters/dataload/historical/nilanjan_udc_def_master_po_v1.hql
vim /home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/masters/dataload/incremental/nilanjan_udc_def_master_po_v1.hql
```

## Step 5 : Run the ingestion

Note: This assumes you have already run the generated DDLs

```bash
cd /home/Nilanjan1.Sarkar/one_infra/init/drivers

sh master_tables_schedule_v2.sh \
/home/Nilanjan1.Sarkar/sdks/infra_recon_phase_three/conf/infra_recon_phase_three.properties \
/home/Nilanjan1.Sarkar/one_infra/init/conf/jbdl-dev-coe-env.properties
```

## Step 6 : Check

```sql
SELECT count(1) as num_records
FROM network_dev.nilanjan_udc_instance_master_po_v1
GROUP BY partition_date;

SELECT count(1) as num_records
FROM network_dev.nilanjan_udc_role_inst_po_v1
GROUP BY partition_date;
```

References
==========
https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_wiki/wikis/Data-Platforms.wiki?wikiVersion=GBwikiMaster&pagePath=%2FJio%20Data%20Platforms%20Vision%20and%20Architecture%2FData%20Engineering%2FTools%20%26%20SDKs%2FIngestion%20SDKs%2FGolden%20Gate%20(GG)%20Ingestion%20SDK&pageId=531