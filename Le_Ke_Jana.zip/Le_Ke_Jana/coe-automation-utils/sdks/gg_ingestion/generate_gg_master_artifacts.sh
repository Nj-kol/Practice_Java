#!/bin/sh

##
# Shell Script to auto-generate GG based ingestion artifacts
#
# @author Nilanjan1.Sarkar
##
if [ "$#" -ne 2 ]; then
   echo "Usage: sh <path_to_seed_spec> <path_to_env_properties_file>"
   exit 1
fi

SEED_PROPERTY_FILE=$1
ENV_PROPERTY_FILE=$2

function getProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $SEED_PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

function getEnvProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $ENV_PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

QUEUE_NAME=$(getEnvProperty "yarn.queue")
HIVE_NAMESPACE_URL=$(getEnvProperty "hive.namespace")
HIVE_PARAMS=$(getEnvProperty "hive.params")
BEELINE_CONN_URL="$HIVE_NAMESPACE_URL;${PARAMS}?tez.queue.name=$QUEUE_NAME"

GG_DB_NAME=$(getProperty "default.gg.schema.name")
TARGET_DB_NAME=$(getProperty "default.master.schema.name")
DEVELOPER_NAME=$(getProperty "default.developer.name")
BASE_LOC=$(getProperty "scripts.base")
RELEASE_NAME=$(getProperty "release.name")

SDK_PATH=${PWD}
TEMPLATES_PATH=${SDK_PATH}/templates
ARTIFACTS_BASE=${BASE_LOC}/${RELEASE_NAME}
MASTER_SPEC_PATH=${BASE_LOC}/${RELEASE_NAME}/conf
DDL_PATH=${BASE_LOC}/${RELEASE_NAME}/masters/ddl

function getSpecProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat "${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties" | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

# Generate DDL for GG external table
function generateGGTableDDLs {

  VALUE=$(getProperty "master.ingestion.jobs.to.execute")
  IFS="," read -a iter_list <<< $VALUE

  GG_DIR_PREFIX=$(getProperty "gg.dir.prefix")

  echo " " >> ${DDL_PATH}/gg_external_table_ddl.hql

  for GG_TABLE_NAME in "${iter_list[@]}"
  do
        echo "CREATE EXTERNAL TABLE IF NOT EXISTS ${TARGET_DB_NAME}.${GG_TABLE_NAME}" >> ${DDL_PATH}/gg_external_table_ddl.hql
        echo "STORED AS AVRO LOCATION '/ogg1/${GG_DIR_PREFIX}.${GG_TABLE_NAME}'" >> ${DDL_PATH}/gg_external_table_ddl.hql
        echo "TBLPROPERTIES ('avro.schema.url'='/ogg1/avro_def/${GG_DIR_PREFIX^^}.${GG_TABLE_NAME^^}.avsc');"  >> ${DDL_PATH}/gg_external_table_ddl.hql
        echo " " >> ${DDL_PATH}/gg_external_table_ddl.hql
  done
}

# Generate ddl statements based on the GG external table
function generateMasterTableDDLs {

  VALUE=$(getProperty "master.ingestion.jobs.to.execute")
  IFS="," read -a iter_list <<< $VALUE

  for GG_TABLE_NAME in "${iter_list[@]}"
  do
        echo "THE GG DETAILS ARE : ${GG_DB_NAME} ${GG_TABLE_NAME}"
        GG_DB_NAME=$(getSpecProperty "master.${GG_TABLE_NAME}.source.db.name")
        MASTER_TABLE_NAME=$(getSpecProperty "master.${GG_TABLE_NAME}.target.table.name")

        # Create the DDL based on
        beeline -u "${BEELINE_CONN_URL}" --outputformat=csv2 -e "SHOW CREATE TABLE ${GG_DB_NAME}.${GG_TABLE_NAME}" > ${DDL_PATH}/${GG_TABLE_NAME}.txt

        # Append template
        cat ${TEMPLATES_PATH}/master_footer.txt >> ${DDL_PATH}/${GG_TABLE_NAME}.txt

        # Fill in the template
        QUERY_FOR_PK="SELECT concat_ws(',',primary_keys) FROM ${GG_DB_NAME}.${GG_TABLE_NAME} LIMIT 1"

        PK_LIST=$(beeline -u "${BEELINE_CONN_URL}" --showHeader=false --outputformat=csv2 -e "${QUERY_FOR_PK}")
        STANDARDIZED_PK_LIST=${PK_LIST,,}

        # Post processing
        sed -i -e 's/createtab_stmt//g' ${DDL_PATH}/${GG_TABLE_NAME}.txt
        sed -i -e 's/EXTERNAL//g' ${DDL_PATH}/${GG_TABLE_NAME}.txt
        sed -i -e 's/TABLE/TABLE IF NOT EXISTS/g' ${DDL_PATH}/${GG_TABLE_NAME}.txt
        sed -i -e "s/${GG_DB_NAME}/${GG_DB_NAME}/g" ${DDL_PATH}/${GG_TABLE_NAME}.txt
        sed -i -e "s/${GG_TABLE_NAME}/${DEVELOPER_NAME}_${GG_TABLE_NAME}_master_po_v1/g" ${DDL_PATH}/${GG_TABLE_NAME}.txt
        sed -i -e "s/PRIMARY_KEY_COLUMN_NAMES/${STANDARDIZED_PK_LIST}/g" ${DDL_PATH}/${GG_TABLE_NAME}.txt
        sed -i -e '/ROW FORMAT SERDE/,+12d' ${DDL_PATH}/${GG_TABLE_NAME}.txt
  done

  # Merge files
  find ${DDL_PATH} -name "*.txt" -o -name "my*.txt" | xargs cat > ${DDL_PATH}/masters_ddl.hql

  # Delete temp files
  find ${DDL_PATH} -name "*.txt" -delete
}

# Generate properties for each gg table for which master table needs to be created
function generateIngestionSpec {

  # doPreProcessing
  touch ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo "scripts.base=$(getProperty "scripts.base")" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo " " >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo "release.name=$(getProperty "release.name")" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo " " >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo "masters.log.dir=$(getProperty "masters.log.dir")" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo "masters.log.retention.period=$(getProperty "masters.log.retention.period")" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo "master.ingestion.jobs.to.execute=$(getProperty "master.ingestion.jobs.to.execute")" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  echo " " >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties

  VALUE=$(getProperty "master.ingestion.jobs.to.execute")
  IFS="," read -a iter_list <<< $VALUE

  for GG_TABLE_NAME in "${iter_list[@]}"
  do
    # Fill in the template
    QUERY_FOR_PK="SELECT concat_ws(',',primary_keys) FROM ${GG_DB_NAME}.${GG_TABLE_NAME} LIMIT 1"

    PK_LIST=$(beeline -u "${BEELINE_CONN_URL}" --showHeader=false --outputformat=csv2 -e "${QUERY_FOR_PK}")
    STANDARDIZED_PK_LIST=${PK_LIST,,}

    # Post processing
    echo "master.${GG_TABLE_NAME}.source.db.name=${GG_DB_NAME}" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
    echo "master.${GG_TABLE_NAME}.source.table.name=${GG_TABLE_NAME}" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
    echo "master.${GG_TABLE_NAME}.primary.key.column.names=${STANDARDIZED_PK_LIST}" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
    echo "master.${GG_TABLE_NAME}.target.db.name=${TARGET_DB_NAME}" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
    echo "master.${GG_TABLE_NAME}.target.table.name=${DEVELOPER_NAME}_${GG_TABLE_NAME}_master_po_v1" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
    echo "master.${GG_TABLE_NAME}.retention.period=3" >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
    echo " " >> ${MASTER_SPEC_PATH}/${RELEASE_NAME}.properties
  done
}

# Generate the folder structure for the release
function generatePlaceHolders {
  # Generate folders
  mkdir -p ${ARTIFACTS_BASE}/masters/ddl
  mkdir -p ${ARTIFACTS_BASE}/conf
  mkdir -p ${ARTIFACTS_BASE}/masters/dataload/historical
  mkdir -p ${ARTIFACTS_BASE}/masters/dataload/incremental
}

# Generate the HQL files required for ingestion
function generateSripts {

  echo "Now generating scripts for master creation"
  MASTER_SCRIPTS_BASE="${ARTIFACTS_BASE}/masters/dataload"

  VALUE=$(getProperty "master.ingestion.jobs.to.execute")
  IFS="," read -a iter_list <<< $VALUE

  for TABLE_NAME in "${iter_list[@]}"
  do
    MASTER_TABLE_NAME=$(getSpecProperty "master.${TABLE_NAME}.target.table.name")
    touch ${MASTER_SCRIPTS_BASE}/historical/${MASTER_TABLE_NAME}.hql
    cat ${TEMPLATES_PATH}/historical_template.txt >> ${MASTER_SCRIPTS_BASE}/historical/${MASTER_TABLE_NAME}.hql
    touch ${MASTER_SCRIPTS_BASE}/incremental/${MASTER_TABLE_NAME}.hql
    cat ${TEMPLATES_PATH}/incremental_template.txt >> ${MASTER_SCRIPTS_BASE}/incremental/${MASTER_TABLE_NAME}.hql
  done
}

# Step 1 : Generate the project structure
generatePlaceHolders

# Step 2 : Generate the DDLs for GG external tables
generateGGTableDDLs

# Step 3 : Generate the master table ingestion spec
generateIngestionSpec

# Step 4 : Generate the DDls for master tables
generateMasterTableDDLs

# Step 5 : Generate the scripts for master tables
generateSripts