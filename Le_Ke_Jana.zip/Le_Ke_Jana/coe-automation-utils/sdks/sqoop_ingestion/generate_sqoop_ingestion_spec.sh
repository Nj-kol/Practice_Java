#!/bin/sh

##
# Shell Script to auto-generate Sqoop ingestion spec which can be used by the Sqoop Ingestion Framework
#
# @author Nilanjan1.Sarkar
##
if [ "$#" -ne 2 ]; then
   echo "Usage: sh <path_to_seed_spec> <path_to_env_properties_file>"
   exit 1
fi

SEED_PROPERTY_FILE=$1
ENV_PROPERTY_FILE=$2

function getProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $SEED_PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

function getEnvProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $ENV_PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

QUEUE_NAME=$(getEnvProperty "yarn.queue")
HIVE_NAMESPACE_URL=$(getEnvProperty "hive.namespace")
HIVE_PARAMS=$(getEnvProperty "hive.params")
BEELINE_CONN_URL="$HIVE_NAMESPACE_URL;${PARAMS}?tez.queue.name=$QUEUE_NAME"

COlUMN_LIST=""
SPLIT_BY_COL=""

function generateOptionsFile {
  JDBL_URL=$1
  USER=$2
  PASSWD=$3
  DATA_SOURCE=$4
  OPTION_FILE_LOCATION=${SPEC_PATH}/${DATA_SOURCE}_option_file.txt
  touch "${OPTION_FILE_LOCATION}"
  echo "import" >> "${OPTION_FILE_LOCATION}"
  echo "-Dmapreduce.job.classloader=true" >> "${OPTION_FILE_LOCATION}"
  echo "-Dmapreduce.job.user.classpath.first=true" >> "${OPTION_FILE_LOCATION}"
  echo "-Dmapred.job.queue.name=dev-coe" >> "${OPTION_FILE_LOCATION}"
  echo "-Dmapreduce.map.memory.mb=2048" >> "${OPTION_FILE_LOCATION}"
  echo "-Dorg.apache.sqoop.splitter.allow_text_splitter=true" >> "${OPTION_FILE_LOCATION}"
  echo "--connect" >> "${OPTION_FILE_LOCATION}"
  echo "${JDBL_URL}" >> "${OPTION_FILE_LOCATION}"
  echo "--username" >> "${OPTION_FILE_LOCATION}"
  echo "${USER}" >> "${OPTION_FILE_LOCATION}"
  echo "--password" >> "${OPTION_FILE_LOCATION}"
  echo "${PASSWD}" >> "${OPTION_FILE_LOCATION}"
}

## Add common header
function generateHeader {
    head -n +4 ${SEED_PROPERTY_FILE} >> ${SPEC_PATH}/ingestion_spec.properties

    SQOOP_JOBS_TO_JOB=""

    SQOOP_DATA_SOURCES=$(getProperty "sqoop.sources")
    IFS="," read -a iter_list <<< $SQOOP_DATA_SOURCES

    counter=0
    # For each sources to ingest, generate ingestion spec
    for DATA_SOURCE in "${iter_list[@]}"
    do
      TABLE_LIST=$(getProperty "sqoop.${DATA_SOURCE}.tables.to.ingest")
      if [[ "$counter" -gt 0 ]]; then
        SQOOP_JOBS_TO_JOB+=","
      fi
      SQOOP_JOBS_TO_JOB+="${TABLE_LIST}"
      counter=$((counter+1))
    done
    echo "" >> ${SPEC_PATH}/ingestion_spec.properties
    echo "sqoop.jobs.to.execute=${SQOOP_JOBS_TO_JOB}" >> ${SPEC_PATH}/ingestion_spec.properties
    echo "" >> ${SPEC_PATH}/ingestion_spec.properties
}

function generateForOracle {

  DATA_SOURCE=$1
  DB_NAME=$(getProperty "sqoop.${DATA_SOURCE}.server.db")
  SERVER_IP=$(getProperty "sqoop.${DATA_SOURCE}.server.ip")
  SERVER_PORT=$(getProperty "sqoop.${DATA_SOURCE}.server.port")
  SERVER_SCHEMA=$(getProperty "sqoop.${DATA_SOURCE}.server.schema")
  USER=$(getProperty "sqoop.${DATA_SOURCE}.user.name")
  PASSWD=$(getProperty "sqoop.${DATA_SOURCE}.user.password")
  TABLE_LIST=$(getProperty "sqoop.${DATA_SOURCE}.tables.to.ingest")

  JDBL_URL="jdbc:oracle:thin:@${SERVER_IP}:${SERVER_PORT}/${DB_NAME}"

  echo "Connecting to ${JDBL_URL} ${USER} ${PASSWD} ${DATA_SOURCE}"

  # Generate options file
  generateOptionsFile ${JDBL_URL} ${USER} ${PASSWD} ${DATA_SOURCE}

  # Generate spec for each table
  IFS="," read -a iter_list <<< $TABLE_LIST
  for TABLE_NAME in "${iter_list[@]}"
    do
    QUERY_TEMPLATE="SELECT LISTAGG (COLUMN_NAME, ',') WITHIN GROUP (ORDER BY COLUMN_ID) AS col_names FROM all_tab_columns  WHERE owner='${SERVER_SCHEMA}' AND table_name = '${TABLE_NAME}' ORDER BY column_id ASC"

    RAW_COLUMM_LIST=`sqoop eval -Dmapreduce.job.classloader=true -Dmapreduce.job.user.classpath.first=true -Dmapred.job.queue.name=${QUEUE_NAME} --connect ${JDBL_URL} --username ${USER} --password ${PASSWD} --query "${QUERY_TEMPLATE}"`
    COlUMN_LIST=`echo "${RAW_COLUMM_LIST}" | grep "^|" | grep "," | cut -d" " -f2`
    arrIN=(${COlUMN_LIST//,/ })
    SPLIT_BY_COL=${arrIN[0]}
    echo "Columns to fetch : ${COlUMN_LIST}"
    echo "Split by columns : ${SPLIT_BY_COL}"
    appendToSpec ${DATA_SOURCE} ${TABLE_NAME} ${COlUMN_LIST} ${SPLIT_BY_COL}
  done
}


# Funtion to get a comma seperated list for tables from Microsoft SQL Server Database
function generateForSQLServer {
  DATA_SOURCE=$1
  DB_NAME=$(getProperty "sqoop.${DATA_SOURCE}.server.db")
  SERVER_IP=$(getProperty "sqoop.${DATA_SOURCE}.server.ip")
  SERVER_PORT=$(getProperty "sqoop.${DATA_SOURCE}.server.port")
  USER=$(getProperty "sqoop.${DATA_SOURCE}.user.name")
  PASSWD=$(getProperty "sqoop.${DATA_SOURCE}.user.password")
  TABLE_LIST=$(getProperty "sqoop.${DATA_SOURCE}.tables.to.ingest")

  JDBL_URL="jdbc:sqlserver://${SERVER_IP}:${SERVER_PORT};databasename=${DB_NAME}"

  # Generate options file
  generateOptionsFile ${JDBL_URL} ${USER} ${PASSWD} ${DATA_SOURCE}

  echo "INSIDE generateForSQLServer ${DATA_SOURCE} ${TABLE_LIST} ${JDBL_URL} ${USER} ${PASSWD}"

  # Generate spec for each table
  IFS="," read -a iter_list <<< $TABLE_LIST

  for TABLE_NAME in "${iter_list[@]}"
    do

    QUERY_TEMPLATE="SELECT DISTINCT(REPLACE(REVERSE(STUFF(REVERSE((SELECT name + ',' AS [data()] FROM sys.columns WHERE OBJECT_NAME(object_id) = '${TABLE_NAME}' ORDER BY column_id FOR XML PATH(''))),1,1,'')),' ',''))"

    RAW_COLUMM_LIST=`sqoop eval -Dmapreduce.job.classloader=true -Dmapreduce.job.user.classpath.first=true -Dmapred.job.queue.name=${QUEUE_NAME} --connect ${JDBL_URL} --username ${USER} --password ${PASSWD} --query "${QUERY_TEMPLATE}"`

    COlUMN_LIST=`echo "${RAW_COLUMM_LIST}" | grep "^|" | grep "," | cut -d" " -f2`
    arrIN=(${COlUMN_LIST//,/ })
    SPLIT_BY_COL=${arrIN[0]}
    echo "Columns to fetch : ${COlUMN_LIST}"
    echo "Split by columns : ${SPLIT_BY_COL}"
    appendToSpec ${DATA_SOURCE} ${TABLE_NAME} ${COlUMN_LIST} ${SPLIT_BY_COL}
  done
}


function appendToSpec {
  DATA_SOURCE=$1
  TABLE_NAME=$2
  COlUMN_LIST=$3
  SPLIT_BY_COL=$4
  OPTION_FILE_LOCATION=${SPEC_PATH}/${DATA_SOURCE}_option_file.txt

  SERVER_SCHEMA=$(getProperty "sqoop.${DATA_SOURCE}.server.schema")
  DEFAULT_DEVELOPER_NAME=$(getProperty "sqoop.${DATA_SOURCE}.default.developer.name")
  DEFAULT_MAPPER=$(getProperty "sqoop.${DATA_SOURCE}.default.mappers")
  DEFAULT_PARTITION_SPEC=$(getProperty "sqoop.${DATA_SOURCE}.default.partition.spec=0")
  DEFAULT_RETENTION=$(getProperty "sqoop.${DATA_SOURCE}.default.retention")
  TARGET_DB_NAME=$(getProperty "sqoop.${DATA_SOURCE}.target.schema")
  HDFS_BASE_PATH=$(getProperty "sqoop.${DATA_SOURCE}.target.base.location")

  # Generate individual spec
  echo "sqoop.${TABLE_NAME}.source.schema.name=${SERVER_SCHEMA}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.options.file.location=${OPTION_FILE_LOCATION}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.column.names=${COlUMN_LIST}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.split.by.column=${SPLIT_BY_COL}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.target.schema.name=${TARGET_DB_NAME}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.target.table.name=${DEFAULT_DEVELOPER_NAME}_${TABLE_NAME}_avro" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.hdfs.base.location=${HDFS_BASE_PATH}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.num.mappers=${DEFAULT_MAPPER}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.partition.spec=${DEFAULT_PARTITION_SPEC}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo "sqoop.${TABLE_NAME}.retention.period=${DEFAULT_RETENTION}" >> ${SPEC_PATH}/ingestion_spec.properties
  echo " " >> ${SPEC_PATH}/ingestion_spec.properties
}


# Generate the final ingestion spec to be fed to the Sqoop Ingestion Framework
function generateIngestionSpec {

SQOOP_DATA_SOURCES=$(getProperty "sqoop.sources")
IFS="," read -a iter_list <<< $SQOOP_DATA_SOURCES

# For each sources to ingest, generate ingestion spec
for DATA_SOURCE in "${iter_list[@]}"
do

  DB_DIALECT=$(getProperty "sqoop.${DATA_SOURCE}.dialect")

  if [ "$DB_DIALECT" == "sqlserver" ]; then
      generateForSQLServer ${DATA_SOURCE}
    elif [ "$DB_DIALECT" == "oracle" ]; then
      generateForOracle ${DATA_SOURCE}
    else
      echo "The dialect is currently not supported. Exiting the application"
      exit 1
  fi
done
}


BASE_LOC=$(getProperty "scripts.base")
RELEASE_NAME=$(getProperty "release.name")

SPEC_PATH=${BASE_LOC}/releases/${RELEASE_NAME}/conf

# Generate path if not exists
mkdir -p ${SPEC_PATH}

generateHeader

generateIngestionSpec