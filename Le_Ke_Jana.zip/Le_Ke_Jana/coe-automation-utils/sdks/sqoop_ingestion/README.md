# Sqoop Ingestion SDK

# Workflow

![Sqoop_sdk.drawio.png](Sqoop_sdk_workflow.png)

* Create a ***seed spec*** file containing details of ingestion such as connectivity, tables to ingest etc.
* Use this seed spec as an input to the Sqoop SDK, which generates all the necessary artifacts such as :
  - ***ingestion spec*** ( used by the Sqoop ingestion framework )
  - ***option files per datasource***
* Use the Sqoop ingestion framework along with the artifacts generated in the last step to ingest the data to JBDL

## Generate Artifacts

Generate all the artifacts such as ingestion spec and options file

Example -

```bash
sh generate_sqoop_ingestion_spec.sh \
/home/Nilanjan1.Sarkar/sdks/sqoop/seed_spec.properties \
/home/Nilanjan1.Sarkar/one_infra/init/conf/jbdl-dev-coe-env.properties
```

## Check Artifacts generated

Check if the arifacts have been generated successfully

Example -

```bash
cd /home/Nilanjan1.Sarkar/sdks/releases/my_release/conf
```

## Run the ingestion

Run the actual Sqoop Ingestion using the existing Sqoop Ingestion Framework

Example -

```bash
cd /home/Nilanjan1.Sarkar/one_infra/init/ingestion/sqoop

sh sqoop_ingest_as_avro_schedule.sh \
/home/Nilanjan1.Sarkar/sdks/my_release/conf/ingestion_spec.properties \
/home/Nilanjan1.Sarkar/one_infra/init/conf/jbdl-dev-coe-env.properties
```

## For re-run

Since the Sqoop Ingestion Framework uses ***checkpointing***, you need to delete the logs commit log file to run it again

```bash
rm -R /home/Nilanjan1.Sarkar/one_infra/logs/one_fiber/sqoop
```

## Reference

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_wiki/wikis/Data-Platforms.wiki?wikiVersion=GBwikiMaster&pagePath=%2FJio%20Data%20Platforms%20Vision%20and%20Architecture%2FData%20Engineering%2FTools%20%26%20SDKs%2FIngestion%20SDKs%2FSqoop%20Ingestion%20SDK&pageId=563