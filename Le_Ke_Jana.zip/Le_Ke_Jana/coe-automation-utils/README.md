
# coe-utilities

## Tools

* Vacuum: A new tool to automatically Identify and Clean up unused tables in dev coe
* Auto-gather sample data for PII tagging used during RR
* Auto-gather table statistics for RR
* Search for a table matching a pattern in JBDL

## SDKs

* Ingestion SDKs
  - Sqoop Ingestion SDK
  - Golden Gate (GG) Ingestion SDK

## References

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_wiki/wikis/Data-Platforms.wiki?wikiVersion=GBwikiMaster&pagePath=%2FJio%20Data%20Platforms%20Vision%20and%20Architecture%2FData%20Engineering%2FTools%20%26%20SDKs&pageId=656