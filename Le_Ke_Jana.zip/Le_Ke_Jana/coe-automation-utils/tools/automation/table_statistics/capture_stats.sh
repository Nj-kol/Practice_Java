#!/bin/sh

##
# Shell Script to auto-gather table statistics for RR

# @author Nilanjan1.Sarkar
##
if [ "$#" -ne 1 ]; then
   echo "Usage: sh capture_stats.sh job.properties"
   exit 1
fi

PROPERTY_FILE=$1

function getProperty {
   PROP_KEY=$1
   PROP_VALUE=$(cat $PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

BASE_LOC=$(getProperty "scripts.base")
DB_NAME=$(getProperty "hive.database")
QUEUE_NAME=$(getProperty "yarn.queue")
HIVE_NAMESPACE_URL=$(getProperty "hive.namespace")
HIVE_PARAMS=$(getProperty "hive.params")
BEELINE_CONN_URL="$HIVE_NAMESPACE_URL?tez.queue.name=$QUEUE_NAME"

# Create a file to record stats
rm -f table_stats.csv
echo "table_name,avg_data_size_per_day,avg_record_count_per_day,avg_files_per_day,avg_file_size" > table_stats.csv

VALUE=$(getProperty "tables.names")

IFS="," read -a iter_list <<< $VALUE

for TABLE_NAME in "${iter_list[@]}"
do
        max_parameters=`beeline -u "$BEELINE_CONN_URL;$HIVE_PARAMS" --outputformat=csv2 -e "select
        max(partition_date) as max_partition_date from $DB_NAME.$TABLE_NAME"`

        latest_partition=`echo $max_parameters | cut -d' ' -f2`

        echo $latest_partition

        record_count=`beeline -u "$BEELINE_CONN_URL;$HIVE_PARAMS" --outputformat=csv2 -e "select count(1) AS num_records from $DB_NAME.$TABLE_NAME where partition_date='$latest_partition'"`

        avg_record_count_per_day=`echo $record_count | cut -d' ' -f2`

        echo $avg_record_count_per_day

        desc_out=`beeline -u "$BEELINE_CONN_URL;$HIVE_PARAMS" --outputformat=csv2 -e "DESCRIBE EXTENDED $DB_NAME.$TABLE_NAME"`

        table_base_path=$(echo "${desc_out}" | egrep -o 'location:[^,]+' | sed 's/location://')

        echo "Table name is $TABLE_NAME"
        echo "Table location: $table_base_path"

        file_path="${table_base_path}/partition_date=${latest_partition}"

        num_files=`hdfs dfs -du -h $file_path | wc -l`

        avg_files_per_day=$(expr $num_files - 1 )

        echo "Average num of files per day - $avg_files_per_day"

        size=`hdfs dfs -du -h -s ${file_path} | awk '{print $1}'`
        unit=`hdfs dfs -du -h -s ${file_path} | awk '{print $2}'`

        avg_data_size_per_day="$size$unit"

        echo "Average data size per day - $avg_data_size_per_day"

        # Outsource floating point division to python
        avg_file_size=$(python doDivsion.py $size $avg_files_per_day)

        echo "Average file size per day - $avg_file_size"

        echo "$TABLE_NAME,$avg_data_size_per_day,$avg_record_count_per_day,$avg_files_per_day,$avg_file_size$unit" >> table_stats.csv
done