# Gather Table Statistics

# Usage

```bash
sh capture_stats.sh job.properties
```

This creates a file called `table_stats.csv` with the following output -

```
table_name,avg_data_size_per_day,avg_record_count_per_day,avg_files_per_day,avg_file_size
nilanjan_negis_plugin_ref_item_avro,101.9K,1483,4,25K
nilanjan_negis_equipment_ref_item_avro,199.1K,2717,4,49K
nilanjan_negis_transmedia_unit_avro,568.5M,11667986,6,94M
nilanjan_negis_structure_ref_item_avro,24.8K,151,4,6K
nilanjan_negis_splice_closure_avro,263.7M,5358263,4,65M
nilanjan_circ_path_element_master_po_v1,987.8M,31727342,4,246M
```


## References

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_wiki/wikis/Data-Platforms.wiki?wikiVersion=GBwikiMaster&pagePath=%2FJio%20Data%20Platforms%20Vision%20and%20Architecture%2FData%20Engineering%2FTools%20%26%20SDKs%2FGather%20Table%20Statistics&_a=edit&pageId=306
