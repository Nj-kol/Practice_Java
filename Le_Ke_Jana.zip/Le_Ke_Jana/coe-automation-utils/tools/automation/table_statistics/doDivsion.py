from __future__ import division
import sys

size = float(sys.argv[1])
num_files = int(sys.argv[2])
answer = size/num_files
avg_file_size = str(round(answer,2))
print avg_file_size