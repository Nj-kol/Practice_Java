#!/bin/sh

##
# Shell Script to check counts per partition

# @author Nilanjan1.Sarkar
##

if [ "$#" -ne 2 ]; then
   echo "Usage: sh doMark.sh <path_to_lable_list_file> <path_to_env_properties_file>"
   exit 1
fi

TABLE_LIST_FILE=$1
PROPERTY_FILE=$2

function getProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

CURRENT_DATE=$(date +''%Y-%m-%d)

DB_NAME=$(getProperty "hive.database")
QUEUE_NAME=$(getProperty "yarn.queue")
HIVE_NAMESPACE_URL=$(getProperty "hive.namespace")
HIVE_PARAMS=$(getProperty "hive.params")
WINSCP_TRANSFER=$(getProperty "winscp.transfer.location")

BEELINE_CONN_URL="${HIVE_NAMESPACE_URL}?tez.queue.name=${QUEUE_NAME}"

FILE_NAME="sanity_report_${CURRENT_DATE}.txt"

rm -f ${FILE_NAME}

while read TABLE_NAME; do
    QUERY="SELECT count(1) AS record_count,partition_date FROM ${TABLE_NAME} GROUP BY partition_date"
    echo "${TABLE_NAME}" >> "${FILE_NAME}"
    beeline -u "${BEELINE_CONN_URL}" --outputformat=table -e "${QUERY}" >> "${FILE_NAME}"
    echo "" >> "${FILE_NAME}"
done <$TABLE_LIST_FILE
