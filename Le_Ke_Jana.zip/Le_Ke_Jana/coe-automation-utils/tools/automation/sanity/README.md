# Table level sanity checks 

Check counts per partition

```bash
sh doSanity.sh table_names.txt jbdl-dev-coe-env.properties 
```

Sample table_names.txt

```
network.assigned_route_master_avro
network.mdsurvey_bridge_avro
network.mdsurvey_pipeline_avro
network.mdsurvey_tunnel_avro
network.mdsurvey_road_network_avro
network.mdsurvey_structure_avro
network.final_authority_span_avro
network.span_row_update_avro
```

Sample output 


sanity_report_2021-12-30.txt

```
network.mdsurvey_road_network_avro
+---------------+-----------------+--+
| record_count  | partition_date  |
+---------------+-----------------+--+
+---------------+-----------------+--+

network.mdsurvey_structure_avro
+---------------+-----------------+--+
| record_count  | partition_date  |
+---------------+-----------------+--+
| 1             | 2021-12-29      |
| 1             | 2021-12-30      |
+---------------+-----------------+--+

network.final_authority_span_avro
+---------------+-----------------+--+
| record_count  | partition_date  |
+---------------+-----------------+--+
| 2             | 2021-12-29      |
| 2             | 2021-12-30      |
+---------------+-----------------+--+
```
