# Generate sample data based for RR's based on random sampling

## Running the script

```bash
sh fetch_sample_data.sh job.properties
```

This will do the following :
- Generate sample data for all the tables specified as csv,
- Create a zip file containing all csv files
- move the zip to a location accessible to WinSCP for transferring to JBDL Desktop

## Output

![Samples.png](Samples.png)

## References

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_wiki/wikis/Data-Platforms.wiki?wikiVersion=GBwikiMaster&pagePath=%2FJio%20Data%20Platforms%20Vision%20and%20Architecture%2FData%20Engineering%2FTools%20%26%20SDKs%2FTable%20Sampling&_a=edit&pageId=322
