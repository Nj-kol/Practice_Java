#!/bin/sh

##
# Shell Script to generate sample data, for example - for for RR's, based on random sampling

# @author Nilanjan1.Sarkar
##
if [ "$#" -ne 1 ]; then
   echo "Usage: sh fetch_sample_data.sh job.properties"
   exit 1
fi

PROPERTY_FILE=$1

DATE=$(date +''%Y-%m-%d)

function getProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

SAMPLING_PERCENT=$(getProperty "sampling.percent")
RECORDS_TO_FETCH=$(getProperty "records.to.fetch")
DB_NAME=$(getProperty "hive.database")
QUEUE_NAME=$(getProperty "yarn.queue")
HIVE_NAMESPACE_URL=$(getProperty "hive.namespace")
HIVE_PARAMS=$(getProperty "hive.params")
WINSCP_TRANSFER=$(getProperty "winscp.transfer.location")

BEELINE_CONN_URL="${HIVE_NAMESPACE_URL}?tez.queue.name=${QUEUE_NAME}"

function doTransfer {
    # compress files
    zip -r samples.zip ${PWD}/samples

    # move files to transfer location
    mkdir -p ${WINSCP_TRANSFER}
    mv samples.zip ${WINSCP_TRANSFER}
}

function doSampling {
        VALUE=$(getProperty "tables.names")

        IFS="," read -a iter_list <<< $VALUE

        # Create a placeholder for holding sample files
        mkdir -p ${PWD}/samples

        for TABLE_NAME in "${iter_list[@]}"
        do
        beeline -u "${BEELINE_CONN_URL}" --outputformat=csv2 -e "SELECT * FROM ${DB_NAME}.${TABLE_NAME} LIMIT ${RECORDS_TO_FETCH};" > ${PWD}/samples/${TABLE_NAME}.csv
        done
}

# Remove existing
rm -R samples

# Create samples of data
doSampling

# transfer samples to a staging location for WinSCP
doTransfer