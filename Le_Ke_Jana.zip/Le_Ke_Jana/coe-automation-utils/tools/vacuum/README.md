# Installation

Make the scripts executable -

```bash
chmod +x doMark.sh

chmod +x doSweep.sh
```

# Usage

## Phase 1 : Identify and Mark tables

```bash
./doMark.sh job.properties jbdl-dev-coe-env.properties
```

This will produce a file called mark.csv in the current directory. Inspect the file before moving to the next step

* Sample output:

```
owner,schema_name,table_name,table_type,accessed_days_ago,last_access_date
Nilanjan1.Sarkar,network_dev,nilanjan_cause_codes,external,1,2022-01-10
Nilanjan1.Sarkar,network_dev,nilanjan_enb_site_p1,external,6,2022-01-05
Nilanjan1.Sarkar,network_dev,nilanjan_enb_site_rp1,external,6,2022-01-05
Nilanjan1.Sarkar,network_dev,nilanjan_p91_hrp1000_master_po_v1,managed,4,2022-01-07
Nilanjan1.Sarkar,network_dev,nilanjan_p91_pa0001_master_po_v1,managed,4,2022-01-07
Nilanjan1.Sarkar,network_dev,nilanjan_p91_qmel_master_po_v1,managed,4,2022-01-07
Nilanjan1.Sarkar,network_dev,nilanjan_tt_cause_codes,external,25,2021-12-17
```

## Phase 2 : Sweep all unused table based on time elapsed since last access

```bash
./doSweep.sh job.properties jbdl-dev-coe-env.properties
```
