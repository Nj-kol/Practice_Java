#!/bin/sh

##
# Shell Script mark user tables to drop
#
# @author Nilanjan1.Sarkar
##

if [ "$#" -ne 2 ]; then
   echo "Usage: sh doMark.sh <path_to_job_properties_file> <path_to_env_properties_file>"
   exit 1
fi

PROPERTY_FILE=$1
ENV_PROPERTY_FILE=$2

function getProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

function getEnvProperty {
   local PROP_KEY=$1
   local PROP_VALUE=$(cat $ENV_PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2-)
   echo $PROP_VALUE
}

SCHEMAS_TO_SEARCH=$(getProperty "schemas.to.search")
SEARCH_KEY=$(getProperty "search.key")

QUEUE_NAME=$(getEnvProperty "yarn.queue")
HIVE_NAMESPACE_URL=$(getEnvProperty "hive.namespace")
HIVE_PARAMS=$(getEnvProperty "hive.params")
BEELINE_CONN_URL="$HIVE_NAMESPACE_URL;${PARAMS}?tez.queue.name=$QUEUE_NAME"

function doSetUp {
  # Remove file from earlier iteration
  rm -f mark.csv

  # Write file header
  echo "owner,schema_name,table_name,table_type,accessed_days_ago,last_access_date" >> mark.csv
}

# Search for tables across schemas
function probeTables {

  IFS="," read -a iter_list <<< $SCHEMAS_TO_SEARCH

  for SCHEMA in "${iter_list[@]}"
  do
     QUERY="USE ${SCHEMA};SHOW TABLES LIKE '*${SEARCH_KEY}*'"
     RES=`beeline -u "${BEELINE_CONN_URL}" --outputformat=csv2 -e "${QUERY}" | xargs | sed "s/tab_name//"`
     echo ${RES}
     if [[ "${#RES}" -gt 0 ]]; then
       IFS=" " read -a iter_list <<< $RES
        for TABLE_NAME in "${iter_list[@]}"
        do
          gatherStats ${SCHEMA} ${TABLE_NAME}
        done
     fi
  done
}

# Derive access statistics
function gatherStats {
  HIVE_DB_NAME=$1
  HIVE_TABLE_NAME=$2
  desc_out=`beeline -u "$BEELINE_CONN_URL" --outputformat=csv2 -e "USE ${HIVE_DB_NAME};SHOW TABLE EXTENDED LIKE ${HIVE_TABLE_NAME}"`
  owner=$(echo "${desc_out}" | egrep -o 'owner:[^,]+' | cut -f2- -d:)

  USER_NAME=$(getProperty "owner")

  if [ "$owner" = "${USER_NAME}" ]; then
    last_access_ts=$(echo "${desc_out}" | egrep -o 'lastAccessTime:[^,]+' | cut -f2- -d: |  cut -c1-10 )
    last_access_date=`date -d @${last_access_ts} +"%Y-%m-%d"`
    current_day=$(date +"%Y-%m-%d")
    accessed_days_ago=$(( ($(date -d ${current_day} +%s) - $(date -d ${last_access_date} +%s)) / 86400))

    # Get the table type
    desc_formatted_out=`beeline -u "$BEELINE_CONN_URL" --outputformat=csv2 -e "USE ${HIVE_DB_NAME};DESCRIBE FORMATTED ${HIVE_TABLE_NAME}"`
    table_desc=$(echo "${desc_formatted_out}" | egrep -o 'EXTERNAL_TABLE')
    if [ "${#table_desc}" -gt 0 ]; then
     table_type=external
    else
     table_type=managed
    fi
    echo "${owner},${HIVE_DB_NAME},${HIVE_TABLE_NAME},${table_type},${accessed_days_ago},${last_access_date}" >> mark.csv
  fi
}

doSetUp

probeTables