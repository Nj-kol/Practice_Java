
# Objectives and Key Results

## To build Reusable Components and Platform

1. Created the Deployment automation Framework 
2. Created the Sqoop Ingestion Framework
3. Created the Sqoop Ingestion SDK
4. Created the Golden Gate Ingestion SDK
5. Created the Vaccum Tool

**Measure**

1. Deployment automation Framework standardized and cut-down deployment time
2. Sqoop Ingestion Framework & SDK, cut-down development time for Sqoop
3. GG Ingestion SDK cut-down development time for GG
4. Vaccum Tool, made easy for team for clean up

## Effective Requirement Analysis

1. Worked with various stakeholders to understand required for One Infra for seamless delivery
2. Worked with all internal stakeholders for better collaboration in releases

**Measure**

Analyzing the User Stories w.r.t. to the functionalities. Analyzing and discussing the requirement with team members and product owners. Proactively preparing the wiki docs and organized sessions to clarify doubts.

## Continuous Improvement of Domain, Technical and Behavioral Skills

1. Created automation scripts for to help team reduce repetetive work
2. Actively created the wiki pages to document and curate all common information
3. Introduced best practices such as git branch naming, Release Notes, code review meetings etc

**Measure**

New practices such as git branch naming, Release Notes and structured wiki pages helped the team to ramp up quickly and collaborate better. Suite of automation scripts that helped the team cut down on repetitive work improving their productivity

## Adherence to Effective Scrum Practices

1. Mapped all work items to Features, User Stories and tasks and managed their lifecycle.
2. Actively involved in daily scrum, sprint planning, sprint review meetings.

**Measure**

Adhering to all Scrum best practices helped delivered work in a more structured manner, and helped in measurement of velocity and volume of work delivered

## Active Contribution to Teams Growth

1. Performed peer to peer review for team members development
2. Shared new information by created wiki pages
3. Actively participated in interviews to expand the team
4. Trained new joiners by required skills for JBDL

# My Development

## Release 

Would like to get opportunities in Architecture and Product Design. Have tried to demonstrate my competence in this area by taking initiativ to introduce new features and modularization in API framework and all-new automation products for infra recon

Want to get invoved and contribute to other areas in JBDL beyond regular ETL work

## Leadership


## Feedback

- I wanted to understand if there is something I could do on my part that could help 
- I also wanted some feedback from you as well


