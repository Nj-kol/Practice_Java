
# Achievements

## To build Reusable Components and Platform

1. Designed Hive REST submit Architecture
2. Created Redis API 
3. Led the initiative on researching Ignite
4. Proposed improvement in Superset - HA architecture, Celery flower

## Effective Requirement Analysis

1. Designed and evolved the future platform for API platform on JBDL
2. Worked with various stakeholders to understand required for One Infra

## Continuous Improvement of Domain, Technical and Behavioral Skills

1. Token basd authentication in API
2. Modular redesign of API codebase
3. Automated unit testing (JUnit) in API Framework
4. Data profiling reporting- elimination of temporary tables, richer data profiling reports
5. Contributed to Open source - Superset

## Active Contribution to Teams Growth

1. Performed peer to peer review for team members development
2. Shared new information by created wiki pages
3. Participated in Campus drives and lateral hiring
4. Trained new joiners by required skills for JBDL

Would like the opportunity to work of projects with real time streaming
where I belive I can added significangt value gien by experience

# Points to raise

## Release from API

- I have working mostly on the API platform for the past one year. And it has been an truly wonderful journey through which 
  I got to learn all a stack which I had not much knowledge prior to this

- I know you have tried really hard to push the API Platform, but due to direction from the higher management this has
  not been able to garner much traction even after a year

- As a consequence, I frankly, have not got the visibility as I had hoped for

- I think I'd like to move out of API for sometime. If you remember our last meeting, I had expressed my desire to work in the 
  Data Engineering area where I feel I would be contribute more given my experience especially in the area of building Real time Architectures where I have substantial experience

- Whenever required, I'd be happy to support any future API endeavours

## Leadership

- As a lead, I still haven't got anything ownership of any one area despite part of a lot of initiatives

- The work that I have been doing is moslty development centric, but it is an area where I am not getting the opportunity
  to hone or showcase my leadership skills despite my role being a lead

- I feel it is limiting my chances to see myself leadership roles in future in this organization. One of reason for joining
  Jio is that I feel that it is a great place to learn and grow one's career

- I would like to lead a initiative where I have some ownership and possibly a team under me

## Feedback

- I wanted to understand if there is something I could do on my part that could help 
- I also wanted some feedback from you as well

## Scratchpad
