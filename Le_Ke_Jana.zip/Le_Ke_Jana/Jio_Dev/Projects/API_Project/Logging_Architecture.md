
# Logging Architecture

## Container based

1. Approach : Streaming to collector

* The logger uses a socket appender and fowards data directly either to logstash or Elasticsearch. 

* No logs are written to disk

2. Approach : Streaming to Queue

* The logger uses a socket appender and writes data 
  to kafka

* Logstash reads data to kafka, which in turn writes to elastic search

* No logs are written to disk

3. Approach : Docker logs

* The container writes logs to standard out
* An agent,filebeat/fluend, runs in the host on which the container
  runs and forwards logs to ELK

4. Approach : Side-car pattern

* The container writes logs to file
* An agent,filebeat/fluend, runs in the same container as the service and forwards logs to ELK

## Non Container based

* Approach 1 and 2 remains the same

3. Approach : Side-car pattern

* The service running on the host writes log files to disk
* * An agent,filebeat/fluend, runs in the same host
  as the service and forwards logs to ELK

## Aggregation 

split slices -> select the kind of aggregation 

/Users/nilanjan1.sarkar/Library/Containers/com.docker.docker/Data

## Kafka logging

https://www.youtube.com/watch?v=G7wMwEDkX_4

https://www.youtube.com/watch?v=S511BgBs_3E

https://www.youtube.com/channel/UC-Z7T0lAq_xECevIz8E5R5w/search?query=microservices

Book : Microservice architecture and pitfalls

https://logz.io/blog/deploying-kafka-with-elk/


## Centralized Logging

* Any centralized logging approach needs the following components:

	1. Collection
	2. Transport
	3. Processing/enrichment
	4. Storage
	5. Analysis
	6. Alerting

* But before this, a way needs to be devised for creating a context :

	1. Request context Id
	2. Context Id Hierarchy
	3. Context Id Extraction
	4. Context Id Consistency

* There are two general approach towards log collection

1. Log consolidation
2. Log Streaming

References
==========
https://engineering.naukri.com/2018/09/centralizing-logs-naukri-com-with-kafka-and-elk-stack/
https://libraries.io/github/otto-de/logback-kafka-appender
https://gquintana.github.io/2017/12/01/Structured-logging-with-SL-FJ-and-Logback.html
https://sadique.io/blog/2016/06/30/json-logging-for-spring-applications/

**Kafka Appender**

https://examples.javacodegeeks.com/enterprise-java/logback/logback-kafka-appender-example/
https://github.com/danielwegener/logback-kafka-appender
https://sadique.io/blog/2016/06/30/json-logging-for-spring-applications/
https://libraries.io/github/otto-de/logback-kafka-appender
https://stackoverflow.com/questions/22615311/is-there-a-logback-layout-that-creates-json-objects-with-message-parameters-as-a
https://www.zhangjianbing.com/archives/38/

**ELK Plugins**

https://www.elastic.co/guide/en/logstash/current/first-event.html
https://www.elastic.co/guide/en/logstash/current/plugins-filters-json.html

//Avro
https://www.elastic.co/guide/en/logstash/current/plugins-codecs-avro.html

// Kibana
https://www.youtube.com/watch?v=430TwfwnV3E

## Components of a logging system

* Appender
* Encoder
* Layout
* Pattern

An *encoder* can be plugged into any appender

## Structured logging

* The term "structured logging" means, a log is more than a message string. 
* The message is associated with contextual information about what was occurring, 
  it tells more detail about what was going on when this log was printed

* For example in logback :

    // Configuration
	Logger demoLogger = LoggerFactory.getLogger("logodyssey.DemoLogger");
	demoLogger.info("Hello world!");

	// Produces

	```
	11:54:57.251 [http-nio-8080-exec-1] INFO  com.javainuse.ELKController - Welcome to Jio!
	```

    Notice how this "Welcome to Jio!" message is qualified with several fields:
    a timestamp, a thread Id, a level and a logger/category.

* A log is more than a textual message, it can be enriched 
  with information at different levels:

	1. Line of code: message, timestamp, level, threadId, appender…​
	2. User or transaction: user Id, session Id…​
	3. Deployment unit: application Id, container Id, host Id, environment Id (production, staging)…​

#### Mapped Diagnostic Context

* How can we enrich this contextual information provided by default, 
  and add the user Id for example? It is the purpose of the MDC (Mapped Diagnostic Context):

  ```
  MDC.put("userId", "gquintana");
  logger.info("Hello world!");
  MDC.remove("userId");
  ```

  The MDC is a map-like object filled in the Java code, and used in
  the back-end logging library to output custom data. With the adequate 
  configuration, we can get the user Id the log:

  ```
  21:10:29.178 [Thread-1] gquintana INFO  logodyssey.DemoLogger - Hello world!
  ```

* The MDC can store any information about :
  - the user (user Id, session Id, token Id)
  - the current request (request Id, transaction Id)
  - long running threads (batch instance Id, broker client Id).

  Later on, this information will be part of the log.

* Having this kind of information allows to group logs by user, 
  by request, by processing.

* Remember that logs may be scattered across different servers, 
  on different time periods. These additional fields allow correlating
  logs belonging to the same scenario and finding answers to questions 
  like "what was the user X doing when he met this nasty error?"

