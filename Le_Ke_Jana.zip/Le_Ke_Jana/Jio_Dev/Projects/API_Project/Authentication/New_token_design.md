
## Token Structure

**Per service token**

```json
{
   "token_id" : 1,
   "tenant":"cybersecurity",
   "resource_name":"hive-rest",
   "token_type" : "kerberos",
   "crdentials":{
      "client_id":"dev_jbdl_hiverest@RJIL.RIL.COM",
      "client_secret":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"
   }
}
```

**Quota Service**

```json
{
   "quota_id" : 1,
   "token_id" : 1,
   "tenant":"cybersecurity",
   "resource_name":"hive-rest",
   "enabled":true,
   "start_time": "2022-05-03",
   "end_time": "2022-05-21",
   "num_records":10000,
   "time_grain":"1 day"
}
```
GET /quota/<resource_name>/<tenant>

GET /quota/mysql-rest/osp

POST /notifications/hive-rest/cybersecurity


https://www.youtube.com/watch?v=gcbcU3EutTc

