
# OpenID

**App Instances**

10.143.165.75:9000
10.143.164.80:9000


Identity Provider is decoupled from the API server

## Run Keycloak in docker

docker run -p 9080:9080 \
-e KEYCLOAK_USER=admin \
-e KEYCLOAK_PASSWORD=admin \
quay.io/keycloak/keycloak:10.0.1


localhost:9080

https://www.keycloak.org/getting-started/getting-started-docker


quay.io/keycloak/keycloak:10.0.1
jboss/keycloak



docker run -p 8080:8080 \
-e KEYCLOAK_USER=admin \
-e KEYCLOAK_PASSWORD=admin \
jboss/keycloak


https://www.youtube.com/watch?v=NZI3C6vdjQk&list=PLShDm2AZYnK22Gqm5UJJ5WlUm48AYhHQ_&index=4

Use Open ID Connect for Kubernetes API server : https://www.youtube.com/watch?v=gJ81eaGlN_I&list=PLShDm2AZYnK22Gqm5UJJ5WlUm48AYhHQ_&index=5

https://github.com/etiennedi/keycloak-nginx-https-self

## Kubernetes with Keycloak

https://www.youtube.com/playlist?list=PL6uCOAmtd02ZeszENF91C5kND212rSewI


