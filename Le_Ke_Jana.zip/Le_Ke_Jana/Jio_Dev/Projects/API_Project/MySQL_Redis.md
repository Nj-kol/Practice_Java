

https://github.com/KarelCemus/play-redis

https://github.com/KarelCemus/play-redis-samples/tree/master/hello_world

https://github.com/KarelCemus/play-redis/blob/2.7.0/doc/20-configuration.md

https://index.scala-lang.org/lifeway/play-redis

https://mvnrepository.com/artifact/com.github.karelcemus/play-redis


## testing

