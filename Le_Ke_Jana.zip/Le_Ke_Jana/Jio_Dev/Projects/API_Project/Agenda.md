
# Agenda

* Architecture Overview
  - API gateway
  - Service Registry
  - Configuration Server
  - Circuit Breaker
  - API and Storge seperation
  - Telemetry
     - Monitoring
     - Logging
     - Distributed Tracing

  API gateway
  Service Registry
  Configuration Server
  Circuit Breaker
  API and Storge seperation
  Telemetry
  Monitoring
  Logging
  Distributed Tracing

* Demo

* Evaluation

* Roadmap

  * Telemetry
     - Logging
  * Security
  * Spring 2.0 upgrade and exploration
  * Use case implemetation

* Questions

## Evaluation

**Pros**

* Good for Human-To-Machine interactions via REST based protocols
* Mature and stable tech 
* Easier to learn
* Large developer pool & community support

**Cons**

* Cross cutting concerns tightly coupled to framework
* Tied to a specific language i.e Java
* Not so efficient for high volume Machine-To-Machine data transfer
  - REST over HTTP with text based payloads (JSON,XML) are not 
    suited for streaming paradigmns
  - RPC based protocols with binary payloads over HTTP/2 ( gGRPC )
    are much well suited for this model

## Feedback

## Tech Stack 

* Microservices

* Monitoring
  - Micrometer
  - Prometheus
  - Graphana

* Log Analytics
  - Kafka
  - Logstash
  - Elasticsearch
  - Kibana

* Distributed Tracing 
  - OpenTracing
  - Jaeger

http://10.141.165.155:8080/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/JBDL%20API%20Platform/
