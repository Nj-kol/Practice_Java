
# Demo K8s demo

## Install MySql as a docker service

sudo docker container run -p 3306:3306 -d \
--name mysql-standalone \
-e MYSQL_ROOT_PASSWORD=asd \
-v mysql-standalone-data:/var/lib/mysql \
mysql:5.6

## Install MySql Client 

export http_proxy=http://10.144.106.132:8678
export https_proxy=http://10.144.106.132:8678
yum install mysql

**Check if you can connect from mysql client**

mysql -h 172.16.0.10 -P 3306 -u root -pasd

## Prepare data

CREATE USER 'nilanjan'@'%' IDENTIFIED BY 'asd';
GRANT ALL PRIVILEGES ON *.* TO 'nilanjan'@'%';
FLUSH PRIVILEGES;

mysql -h 10.144.96.247 -P 3306 -u nilanjan -p

USE api_demos;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(255) DEFAULT NULL,
  `fisrt_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
)

INSERT INTO user VALUES (1,'Bangalore','Shubham','Dubey');
INSERT INTO user VALUES (2,'Bangalore','Shikhar','Srivastava');
INSERT INTO user VALUES (3,'Bangalore','Pawan','Kurmi');
INSERT INTO user VALUES (4,'Navi Mumbai','Raghuram','Velega');

SELECT * FROM user;

## Prepare K8s Environment

**Label node for specific scheduling**

kubectl label node jkaas-npd-worker-k8sjaws36925734-6791-5490 type=my-images

**Create namespace**

kubectl create namespace api-poc

kubectl create namespace istio-demos
kubectl label namespace istio-demos istio-injection=enabled

**Create a cluster role binding**
 
kubectl create clusterrolebinding api-poc \
--clusterrole=cluster-admin \
--serviceaccount=api-poc:default

kubectl describe clusterrolebinding  api-poc
kubectl delete clusterrolebinding api-poc

## Deploy CRUD App

**Clone Repo**

mkdir /home/cloud-user/Repos
cd /home/cloud-user/Repos
git clone http://git.jkaas.jio.com/K8SPROJ356958/mysql-data-service.git

**Env variables**

export BASE_PATH=/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/spring-cloud-kubernetes/mysql-data-service

export BASE_PATH=/home/cloud-user/Repos/mysql-data-service

cd ${BASE_PATH}

**Build jar**

mvn clean install

**Build & Push image to registry**

sudo docker build -t registry.jkaas.jio.com:4567/k8sproj356958/mysql-data-service ${BASE_PATH}
sudo docker push registry.jkaas.jio.com:4567/k8sproj356958/mysql-data-service

sudo docker pull registry.jkaas.jio.com:4567/k8sproj356958/mysql-data-service

**Create secrets**

kubectl apply -f ${BASE_PATH}/mysql-secrets.yaml -n api-poc
kubectl apply -f ${BASE_PATH}/mysql-secrets.yaml -n istio-demos

**Create external endpoints**

kubectl apply -f ${BASE_PATH}/external_endpoint.yaml -n api-poc
kubectl apply -f ${BASE_PATH}/external_endpoint.yaml -n istio-demos

**Deploy app**

kubectl apply -f ${BASE_PATH}/deploy.yaml -n api-poc
kubectl apply -f ${BASE_PATH}/deploy.yaml -n istio-demos

**Deploy service**

kubectl apply -f ${BASE_PATH}/service.yaml -n api-poc

**Check**

kubectl get po -n api-poc
kubectl get po  -n istio-demos
kubectl logs user-data-service-799d669759-64zxf -n api-poc

**URL**

curl http://10.157.88.193:30094/user/getbyid/3   ( CRUD service )

http://10.157.88.193:30094/swagger-ui.html 

**Scale the app**

kubectl scale --replicas=3 deployment user-data-service -n api-poc
kubectl delete pods user-data-service-f64c5fd6-6k5rr -n api-poc  

**Teardowm**

kubectl delete -f ${BASE_PATH}/mysql-secrets.yaml -n api-poc
kubectl delete -f ${BASE_PATH}/external_endpoint.yaml -n api-poc
kubectl delete -f ${BASE_PATH}/deploy.yaml -n api-poc
kubectl delete -f ${BASE_PATH}/service.yaml -n api-poc

#### Deploy Service App

**Clone Repo**

mkdir /home/cloud-user/Repos

cd /home/cloud-user/Repos

git clone http://git.jkaas.jio.com/K8SPROJ356958/user-services-api.git

**Env variables**

export BASE_PATH=/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/spring-cloud-kubernetes/user-services-api

export BASE_PATH=/home/cloud-user/Repos/user-services-api

**Build jar**

mvn clean install

**Build & Push image to registry**

sudo docker build -t registry.jkaas.jio.com:4567/k8sproj356958/user-services-api ${BASE_PATH}
sudo docker push registry.jkaas.jio.com:4567/k8sproj356958/user-services-api

**Deploy k8s manifests**

kubectl apply -f ${BASE_PATH}/config.yaml -n api-poc
kubectl apply -f ${BASE_PATH}/role.yaml -n api-poc
kubectl apply -f ${BASE_PATH}/deploy.yaml -n api-poc
kubectl apply -f ${BASE_PATH}/service.yaml -n api-poc

kubectl apply -f ${BASE_PATH}/config.yaml -n istio-demos
kubectl apply -f ${BASE_PATH}/role.yaml -n istio-demos
kubectl apply -f ${BASE_PATH}/deploy.yaml -n istio-demos

**Check**

kubectl get po -n api-poc 
kubectl logs <pod_name> -n api-poc

**Scale the app**

kubectl scale --replicas=3 deployment user-app -n api-poc

**Teardowm**

kubectl delete -f ${BASE_PATH}/config.yaml -n api-poc
kubectl delete -f ${BASE_PATH}/role.yaml -n api-poc
kubectl delete -f ${BASE_PATH}/deploy.yaml -n api-poc
kubectl delete -f ${BASE_PATH}/service.yaml -n api-poc

**URL**

curl http://10.157.88.204:30184/services/greet/4 

http://10.157.88.204:30184/swagger-ui.html

*Reload the configuration*

kubectl apply -f ${BASE_PATH}/config.yaml -n api-poc
curl http://10.157.88.193:30184/actuator/refresh -d {} -H "Content-Type: application/json"

## Accessing URLs

Both the services have been exposed as NodePort services. Only the IP needs to be found out to access the URLs which
can be done using : kubectl get po -n api-poc -o wide

The above command will produce a column called NODE. Use the Floating IP of these nodes to access them.

Syntax : http://<Floating_IP>:<NodePort>/<remaining_path>

**API Docs**

Syntax  : http://<Floating_IP>:<NodePort>/swagger-ui.html
Example : http://10.157.88.193:30184/swagger-ui.html

Note : If the page does not load even after giving the correct Floating IP, check the nodeport for the service. You can do this as : kubect; get svc -n api-poc

## Housekeeping

watch kubectl get po -n api-poc
kubectl get svc -n api-poc

kubectl describe pod user-app-8b7fd4596-5tj7b -n api-poc
kubectl describe pod user-data-service-7c895cbb6c-m2z7d -n api-poc

kubectl logs user-app-8b7fd4596-gtm9d -n api-poc
kubectl logs user-data-service-7c895cbb6c-g9pf6 -n api-poc

# Ambassador Mappings 

## User App

```
apiVersion: getambassador.io/v1
kind: Mapping
metadata:
  name: user-app-mapping
spec:
  prefix: /jio/jbdl/api/
  service: user-app.api-poc:9181
  labels:
    ambassador:
      - request_label:
        - user-app-mapping
```

kubectl apply -f ambassador-mapping-user-app.yaml -n api-poc

**Through ambassador**

http://10.157.88.226:30036/jio/services/greet/4
http://10.157.88.214:30036/jio/services/greet/4
http://10.157.88.204:30036/jio/services/greet/4

## Repo 

git clone http://git.jkaas.jio.com/K8SPROJ356958/mysql-data-service.git
git clone http://git.jkaas.jio.com/K8SPROJ356958/user-services-api.git

# Observability

## Prometheus

http://10.157.88.214:30000

## Graphana

http://10.157.88.193:32000/

## Jaeger

http://10.157.88.214:30988/search

