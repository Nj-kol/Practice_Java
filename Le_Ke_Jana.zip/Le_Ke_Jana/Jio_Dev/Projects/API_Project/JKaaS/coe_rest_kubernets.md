# COE Rest kubenetes

# Spring Bare metal


java -jar /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Databases/coe-rest-kubernetes/target/coe-rest-kubernetes-0.0.1-SNAPSHOT.jar

scp -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem \
-r /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Databases/coe-rest-kubernetes/target/coe-rest-kubernetes-0.0.1-SNAPSHOT.jar \
cloud-user@10.157.88.204:/home/cloud-user

java -jar /home/cloud-user/coe-rest-kubernetes-0.0.1-SNAPSHOT.jar

curl -H "Content-Type: application/json" -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 where subscriber_gender is not null limit 50", "maxRows":"100", "principal":"dev_jbdl_hiverest@RJIL.RIL.COM", "keytab":"/home/cloud-user/keytabs/dev_jbdl_hiverest.keytab"}' -X POST http://localhost:9181/bdcoe/services/hive/query

curl -H "Content-Type: application/json" -d '{"query":"select subscriber_id, cell_mcc, cell_mnc from network.probes_userplane_20191007 limit 40", "maxRows":"100", "principal":"dev_jbdl_hiverest@RJIL.RIL.COM", "keytab":"/Users/nilanjan1.sarkar/Downloads/dev_jbdl_hiverest.keytab"}' -X POST http://localhost:9181/bdcoe/services/hive/query

# JKaas

## Build

cd /home/cloud-user/Repos

git clone http://git.jkaas.jio.com/K8SPROJ356958/coe-rest-kubernetes.git

mvn clean install

sudo docker build -t registry.jkaas.jio.com:4567/k8sproj356958/coe-rest-kubernetes ${PWD}
sudo docker push registry.jkaas.jio.com:4567/k8sproj356958/coe-rest-kubernetes

## K8s Deploy

**Set some environment variables for shortcuts**

export BASE_PATH=/home/cloud-user/Repos/coe-rest-kubernetes
export CONFIG_PATH=/home/cloud-user/k8s_hadoop_files
export KEYTAB_PATH=/home/cloud-user/keytabs

**Create Namespace**

kubectl create namespace coe-rest

**Create Kerberos config secrets**

kubectl create configmap krb5-config --from-file=/etc/krb5.conf -n coe-rest

Note: The /etc/krb5.conf file must be the same as in the JBDL environment

**Create keytab secrets**

kubectl create secret generic keytab-secret \
--from-file=${KEYTAB_PATH}/dev_jbdl_hiverest.keytab \
-n coe-rest

Note: The keytab file must be procured in advance from system administrator

**Deploy application artifacts**

kubectl apply -f ${BASE_PATH}/role.yaml -n coe-rest
kubectl apply -f $BASE_PATH/external_endpoint.yaml -n coe-rest
kubectl apply -f ${BASE_PATH}/deploy.yaml -n coe-rest

## Housekeeping

kubectl get po -n coe-rest -o wide
kubectl get svc -n coe-rest
kubectl get ep -n coe-rest

kubectl logs coe-rest-kubernetes-587f5d4864-7z9zj -f -n coe-rest
kubectl exec -it coe-rest-services-8484c49c6b-425w4 -n coe-rest bash

## Teardown

kubectl delete -f ${BASE_PATH}/role.yaml -n coe-rest
kubectl delete -f ${BASE_PATH}/deploy.yaml -n coe-rest
kubectl delete -f $BASE_PATH/external_endpoint.yaml -n coe-rest

## Test

**Machines**

jkaas-npd-master-k8sjaws36925734-3008-2097    10.157.88.236   
jkaas-npd-master-k8sjaws36925734-3478-8456    10.157.88.255  
jkaas-npd-master-k8sjaws36925734-9407-9823    10.157.88.206   
jkaas-npd-worker-k8sjaws36925734-3805-946     10.157.88.214   
jkaas-npd-worker-k8sjaws36925734-4437-9230    10.157.88.193   
jkaas-npd-worker-k8sjaws36925734-494-7110     10.157.88.226   
jkaas-npd-worker-k8sjaws36925734-6791-5490    10.157.88.204   
jkaas-npd-worker-k8sjaws36925734-9537-5355    10.157.88.220   

**API Docs**

Syntax  : http://<Floating_IP>:<NodePort>/swagger-ui.html
Example : http://10.157.88.193:30284/swagger-ui.html

*Try using Open API*

{
   "query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 where subscriber_gender is not null limit 25",
   "maxRows": "25",
   "principal": "dev_jbdl_hiverest@RJIL.RIL.COM",
   "keytab":"/app/restapi_keytabs/keytab-volume/dev_jbdl_hiverest.keytab"
}

## Scale 

kubectl scale --replicas=3 deployment coe-rest-kubernetes -n coe-rest
kubectl delete pods user-data-service-f64c5fd6-6k5rr -n coe-rest  

kubectl get po -n coe-rest -o wide

kubectl delete pods coe-rest-kubernetes-587f5d4864-vk2cj -n coe-rest 

kubectl exec -it coe-rest-kubernetes-587f5d4864-7z9zj -n coe-rest bash

**Works fine**

kubectl logs coe-rest-kubernetes-587f5d4864-5htdq -f -n coe-rest

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 where subscriber_gender is not null limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/keytab-volume/dev_jbdl_hiverest.keytab"}' http://10.157.88.226:30284/bdcoe/services/hive/query

**Works Fine**

kubectl logs coe-rest-kubernetes-587f5d4864-7z9zj -f -n coe-rest

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 where subscriber_gender is not null limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/keytab-volume/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30284/bdcoe/services/hive/query

**Works**

kubectl logs coe-rest-kubernetes-587f5d4864-9frmk -f -n coe-rest

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 where subscriber_gender is not null limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/keytab-volume/dev_jbdl_hiverest.keytab"}' http://10.157.88.214:30284/bdcoe/services/hive/query

# Note 

There seems to be some issue with the node : jkaas-npd-worker-k8sjaws36925734-6791-5490

Thus, it has been tainted ( kubectl taint nodes jkaas-npd-worker-k8sjaws36925734-6791-5490 key=value:NoSchedule )

To untaint :

kubectl taint nodes jkaas-npd-worker-k8sjaws36925734-6791-5490  key:NoSchedule-

# Observabality

kubectl get po -n observability -o wide

## Prometheus

**Update mappings**

*Add new entry*

vi /home/cloud-user/deployments/prometheus/prometheus-config-map.yaml

```
      - job_name: 'coe-rest-kubernetes'
        metrics_path: '/actuator/prometheus'
        scrape_interval: 5s
        static_configs:
        - targets: ['coe-rest-kubernetes.coe-rest.svc.cluster.local:9181']
```

*Apply the latest config*

kubectl apply -f prometheus-config-map.yaml

*Restart prometheus by deleting the current pod*

kubectl get po -n observability
kubectl delete pods prometheus-deployment-76c97b96f8-pxvkc -n observability

**Access Prometheus UI**

http://10.157.88.214:30000

## Graphana

http://10.157.88.193:32000

## Jaeger

http://10.157.88.214:30988/search

http://10.157.88.193:30988/search
 


