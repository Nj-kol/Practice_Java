
# Existing REST Service 

* Feature 120006
  * Story 119172
    * Task 119094
    * Task 118983

## Build

cd /home/cloud-user/Repos
git clone http://git.jkaas.jio.com/K8SPROJ356958/coe-rest-services-spring.git

## Create namespace

kubectl config use-context docker-desktop
kubectl config use-context sameer3.sharma@K8SPROJ356958.K8SJAWS36925734.AnalyticsCOE

kubectl create namespace coe-rest
kubectl delete namespace coe-rest

## Create secrets

export BASE_PATH=/home/cloud-user/Repos/coe-rest-services-spring
export CONFIG_PATH=/home/cloud-user/k8s_hadoop_files
export KEYTAB_PATH=/home/cloud-user/keytabs

**Create HDFS config secrets**

kubectl create secret generic hdfs-secret \
--from-file=${CONFIG_PATH}/hdfs-site.xml \
--from-file=${CONFIG_PATH}/core-site.xml \
-n coe-rest

**Create Hive config secrets**

kubectl create secret generic hive-secret \
--from-file=${CONFIG_PATH}/hive-site.xml \
-n coe-rest

**Create Kerberos config secrets**

kubectl create configmap krb5-config \
--from-file=/etc/krb5.conf \
-n coe-rest

**Create keytab secrets**

kubectl create secret generic keytab-secret \
--from-file=${KEYTAB_PATH}/dev_jbdl_hiverest.keytab \
-n coe-rest

## Build image

**Build jar**

cd ${BASE_PATH}

mvn clean install

**Build & Push image to registry**

sudo docker build -t registry.jkaas.jio.com:4567/k8sproj356958/coe-rest-services-spring ${BASE_PATH}
sudo docker push registry.jkaas.jio.com:4567/k8sproj356958/coe-rest-services-spring

sudo docker build -t 10.141.51.157:5700/coe-rest-services-spring .
sudo docker push 10.141.51.157:5700/coe-rest-services-spring

## Deploy as k8s

kubectl apply -f ${BASE_PATH}/role.yaml -n coe-rest
kubectl apply -f $BASE_PATH/external_endpoint.yaml -n coe-rest
kubectl apply -f ${BASE_PATH}/config.yaml -n coe-rest
kubectl apply -f ${BASE_PATH}/deploy.yaml -n coe-rest

## Housekeeping 

kubectl get po -n coe-rest -o wide
kubectl get svc -n coe-rest
kubectl get cm -n coe-rest

kubectl logs coe-rest-services-spring-5f79b86b97-p5q78 -f -n coe-rest

kubectl exec -it coe-rest-services-8484c49c6b-425w4 -n coe-rest bash

kubectl describe pod coe-rest-services-spring-5f79b86b97-j4r8f -n coe-rest

## Test

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 where subscriber_gender is not null limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/keytab-volume/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30284/bdcoe/services/hive/query

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age  from network.probes_userplane_20191007  limit 100","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/keytab-volume/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30284/bdcoe/services/hive/query

## Teardown

kubectl delete -f ${BASE_PATH}/deploy.yaml -n coe-rest

## HK

* View information about the secret

kubectl get secret hdfs-secret -n coe-rest

* View more detailed information about the Secret:

kubectl describe secret hdfs-secret -n coe-rest
kubectl describe secret hive-secret -n coe-rest
kubectl describe secret krb5-secret -n coe-rest
kubectl describe secret keytab-secret -n coe-rest

kubectl exec -it coe-rest-services-7ddffd5cff-j4hmh bash -n coe-rest

## Scale 

kubectl scale --replicas=3 deployment coe-rest-services-spring -n coe-rest
kubectl delete pods coe-rest-services-spring-559fcbb954-k5x8x -n coe-rest  


Nexus : http://10.141.51.157:9081/repository/DSP_Docker_Registry/

# Observability

## Prometheus

http://10.157.88.193:30000/graph

## Jaeger

http://10.157.88.193:30988/search

## Graphana

http://10.157.88.193:32000





