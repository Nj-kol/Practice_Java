
# Runbook for coe-rest-services-k8s

Port the existing service coe-rest-services to k8s environment

## Build

cd /home/cloud-user/JKaaS_Repos
git clone http://git.jkaas.jio.com/K8SPROJ356958/coe-rest-services-k8s

## Create namespace

kubectl config use-context docker-desktop
kubectl config use-context sameer3.sharma@K8SPROJ356958.K8SJAWS36925734.AnalyticsCOE

kubectl create namespace jbdl-api-core
kubectl create namespace jbdl-api-services

## Set Env variables

export ENV=dev
export BASE_PATH=/home/cloud-user/JKaaS_Repos/coe-rest-services-k8s
export CONFIG_PATH=${BASE_PATH}/resources/${ENV}

export KRB_PATH=/home/cloud-user/kerberos_files

## Create secrets

**Create configuration secrets**

kubectl create secret generic config-secret \
--from-file=${CONFIG_PATH}/hdfs-site.xml \
--from-file=${CONFIG_PATH}/core-site.xml \
--from-file=${CONFIG_PATH}/hive-site.xml \
--from-file=${CONFIG_PATH}/hive-config.properties \
-n jbdl-api-services 

kubectl describe secret config-secret -n jbdl-api-services 
kubectl delete secret config-secret -n jbdl-api-services 

**Create Kerberos configmap**

kubectl create configmap krb5-config \
--from-file=${CONFIG_PATH}/krb5.conf \
-n jbdl-api-services 

kubectl describe configmap krb5-config -n jbdl-api-services 
kubectl delete configmap krb5-config -n jbdl-api-services 

**Create keytab secrets**

kubectl create secret generic krb5-secret \
--from-file=${KRB_PATH}/dev_jbdl_hiverest.keytab \
-n jbdl-api-services 

## Build image

**Build jar**

cd ${BASE_PATH}

mvn clean install

**Build & Push image to registry**

sudo docker build -t registry.jkaas.jio.com:4567/k8sproj356958/coe-rest-services-k8s ${BASE_PATH}
sudo docker push registry.jkaas.jio.com:4567/k8sproj356958/coe-rest-services-k8s

sudo docker build -t 10.141.51.157:5700/coe-rest-services-k8s ${BASE_PATH}
sudo docker push 10.141.51.157:5700/coe-rest-services-k8s

## Deploy to k8s

**Using Kustomize**

kubectl apply -k ${BASE_PATH}/deploy/app/overlays/${ENV}

**Apply Ingress Rule**

kubectl apply -f ${BASE_PATH}/traefik_ingress_rule.yaml -n jbdl-api-services

**Manual**

kubectl apply -f ${BASE_PATH}/role.yaml -n jbdl-api-services
kubectl apply -f $BASE_PATH/external_endpoint.yaml -n jbdl-api-services
kubectl apply -f ${BASE_PATH}/deploy.yaml -n jbdl-api-services

## Housekeeping 

kubectl get po -n jbdl-api-services -o wide
kubectl get svc -n jbdl-api-services
kubectl get ep -n jbdl-api-services

kubectl get cm -n jbdl-api-services

kubectl logs coe-rest-services-75f9cc8888-zbfst -f -n jbdl-api-services

stern traefik -n jbdl-api-core --tail 5 

stern coe-rest-services -n jbdl-api-services --tail 5

kubectl exec -it coe-rest-services-75f9cc8888-456d4 -n jbdl-api-services bash

kubectl describe coe-rest-services-75f9cc8888-456d4 -n jbdl-api-services

## Teardown

kubectl delete -f ${BASE_PATH}/deploy.yaml -n jbdl-api-services

## Test

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/krb5-keytab-volume/dev_jbdl_hiverest.keytab"}' http://api.k8sjaws36925734.jkaas.jio.com:32752/bdcoe/services/hive/query

**Inside a pod**

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/krb5-keytab-volume/dev_jbdl_hiverest.keytab"}' http://coe-rest-services.coe-rest:9000/bdcoe/services/hive/query

**Local**

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/krb5-keytab-volume/dev_jbdl_hiverest.keytab"}' http://localhost:9000/bdcoe/services/hive/query

## Scale 

kubectl scale deployment coe-rest-services -n jbdl-api-services --replicas=3  

kubectl scale deployment dummy-k8s-app -n jbdl-api-services --replicas=1 

watch kubectl get po -n jbdl-api-services 

# Application Observability

## Traefik

http://api.k8sjaws36925734.jkaas.jio.com:32752/dashboard/

## Prometheus

http://10.157.88.226:30000/graph

## Jaeger

http://10.157.88.193:30988/search

## Graphana

http://10.157.88.214:32000

# Ops

## Trasfer from local

scp -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem  \
-r /Users/nilanjan1.sarkar/Documents/JBDL_Repos/coe-rest-services/target/coe-rest-services-assembly-1.0.0-SNAPSHOT.jar \
cloud-user@10.157.88.204:/home/cloud-user/JKaaS_Repos/coe-rest-services-k8s/target

## Check connectivity Inside pod

kubectl exec -it coe-rest-services-5747b69b6f-j9gzp -n jbdl-api-services bash

```
timeout 1 bash -c "</dev/tcp/hive-service/2181" && echo Port open || echo Port closed
timeout 1 bash -c "</dev/tcp/kafka-brokers/6667" && echo Port open || echo Port closed
timeout 1 bash -c "</dev/tcp/bdpdata0280.jio.com/6667" && echo Port open || echo Port closed
```

cat /etc/krb5.conf
cd /etc/config-volume
cd /app/restapi_keytabs/krb5-keytab-volume

ping adldap.rjil.ril.com

## Edit jar 

sudo yum install zip
sudo yum install unzip

chmod a+x target/coe-rest-services-assembly-1.0.0-SNAPSHOT.jar
vim target/coe-rest-services-assembly-1.0.0-SNAPSHOT.jar

hive-jbdl-prod-config.properties

References
===========
Exisiting :https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_Hive_Rest_Service/coe-rest-services

https://www.playframework.com/documentation/2.8.x/ApplicationSecret


The are :

1. One config map
   - krb5-config

2. Two secrets
   - config-secret
   - krb5-secret

# New deploy

scp -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem  \
-r ${PWD}/deploy \
cloud-user@10.157.88.204:/home/cloud-user/JKaaS_Repos/coe-rest-services-k8s

**Volume attached nodes**

jkaas-npd-worker-k8sjaws36925734-9537-5355 
jkaas-npd-worker-k8sjaws36925734-3805-946
jkaas-npd-worker-k8sjaws36925734-4437-9230 

ssh -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem cloud-user@10.157.88.220
ssh -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem cloud-user@10.157.88.214
ssh -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem cloud-user@10.157.88.193

sudo docker image rm 10.141.51.157:5700/coe-rest-services-k8s
sudo docker image pull 10.141.51.157:5700/coe-rest-services-k8s

kubectl get all -n jbdl-api-services

kubectl kustomize ${PWD}

kubectl apply -k /home/cloud-user/JKaaS_Repos/coe-rest-services-k8s/deploy/app/overlays/dev
kubectl delete -k /home/cloud-user/JKaaS_Repos/coe-rest-services-k8s/deploy/app/overlays/dev

kubectl get svc -n jbdl-api-services
kubectl get po -n jbdl-api-services -o wide

kubectl get ep -n jbdl-api-services -o wide

kubectl logs coe-rest-services-1 -n jbdl-api-services


Scaling ElasticSearch on Kubernetes : https://www.youtube.com/watch?v=RyPPnhFd5_o
Running Elasticsearch on Kubernetes : https://www.youtube.com/watch?v=0UhYxy0d4x0&t


