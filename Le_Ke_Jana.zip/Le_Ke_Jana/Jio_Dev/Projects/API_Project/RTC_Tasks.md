# Stories

# Initial Work

## Week 1 | Story : API Framework High Level Design | 4 to 8

* Design high level architecture - 3 days
* Create a sample app API and Storge seperation - 2 days

## Week 2 | Story : Explore Spring Cloud Components | 11 to 15

* Integrate Configuration Server to architecture - 1 day
* Integrate Service Registry to architecture - 1 day
* Integrate API gateway to architecture - 1 day
* Integrate Circuit Breaker to architecture - 1 day
* Integate Distributed Tracing to architecture - 1 day

## Week 3 | Story : Distributed Logging for API framework | 18 to 22

* Do high level research on Distributed Logging   - 2 days
* Test kafka apppender     - 1 day 
* Set up ELK stack locally - 1 day
* Intergate sample app with log streaming pipeline - 1 day

## Week 4 | Story : Microservice Monitoring Design | 25 to 29

* Design high level architecture for Microservice Monitoring Design - 2 days
* Explore Prometheus and Graphana - 1
* Integrate with Micrometer - 1
* Integrate Monitoring to sample app - 1 day

# Stories 

* System Story 121754 - Move the coe-rest-service-k8s to Jbdl k8s cluster ( mini replica of prod )

* System Story 124342 - Design a system for Large Volume transfer (in a streaming manner) of data from JBDL
  - Task 124343 : Create a POC on gRPC for streaming data
  - Task 124345 : Configure NGINX ( For bare metal ) to act as reverse proxy for gRPC applications
  - Task 124347 : Create a POC for deploying gRPC based applications on Kuberentes
  - Task 124348 : Configure Traefik ( For Kubernetes ) to act as reverse proxy for gRPC applications

* Task 122681 - Create the RR for jbdl api platform

* System Story 126933 - Retrofit the latest version of coe-rest-service with k8s artifacts
  - Task 126934 : Add k8s artifacts to coe-rest-service app

