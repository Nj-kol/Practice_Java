
# API PLatform demo

Hello, welcome to this demo on the proposed API Platform for JBDL. 
The purpose was to create a "platform" that enables developers to quickly create APIs without having to worry about the microservice infrastructure which is required to operationlize thier work

## Agenda

* Core Pltatform
  - API Gateway
  - API and Storage Seperation
 
	* Cross Cutting Concerns
	  - Service Registry
	  - Configuration Server
	  - Circuit Breaker

* Observability
     - Distributed Tracing

	* Telemetry
	  	- Monitoring
	  	- Logging

## Core Platform

* The entry point to our services would be through an API gateway. There are several advantages to this approach
of not directly exposing the service endpoint to consumer such as security, routing amongst others.

* In this demo, we have seperate the concerns of API endpoint + service logic and persistence into two services for easy decoupling
of storage layer

Let's see this in action - SHOW

We'll show this bottom up i.e from persistence layer to the API gateway for ease of understanding

* Each service in the platform is required to register themselves to a central registry with an unique identier.
  This enables services to "discover" each other without having to worry about things such as 
  - The IP address or DNS of the service
  - Number of instances of the service present

- There is a confoguration server that helps in externalizing configuration information. In this case, the configutations
  are fetched from github

- To control service outages against requst spikes, we have enabled circuit breaker across API to help the service recover

## Observability

It is not enough to get platform up and running, once it is up we need to "observe" what it is doing

#### Distributed Tracing
 
In a microservice architecture, there is seperation of concerns which is to say "do just one thing and do it right". Invariably, over time a number of services will come up which talks to each other to get the overall work done. Thus, there exists some causal relationship across several services. Distributed Tracing is required to address just this, to trace a request that "spans" several
services.

For this we have use an abstraction called "OpenTracing" that decouples our services from a particular tracing software.

Let's see this in action - SHOW

As you can see not only does it capture the data for spans, but you can also visually see relationship among the various services
for a particular request

#### Telemetry

Telemetry is the collection of measurements. To that end, the two most common questions that arise during the runtime of the application are :

1. What is the application doing currently
2. How is it behaving?

The first question technically alludes to Application Logging. 
The second question is concened about Application Monitoring

**Logging**

Lets now look into logging. There are general approach towards log collection

1. Log Consolidation
   - Here log files written to disk are collected at some frequency to some centralized location for further processing

2. Log Streaming
   - Here logs are not written as fils to disk, but rather treated as streams of data

We wanted to make the logging framework scalable and container friendly, hence we took the second approch i.e. Log Streaming. For this, we chose the stack of :

* Kafka         - For buffering streaming log data
* Logstash      - For pre-processing
* Elasticsearch - For storage
* Kibana        - For visualization & Analytics

Let's see this in action - SHOW

We have created a very simple dashboard to showcase the analytics capabilities

**Monitoring**

Once the application is up and running, it is important to see how it is behaving in terms of resource utilization. This is where the Monitoring comes into the picture.

 For this, we chose the stack of :

* Promethues    - For storing metrics data as a time series
* Graphana      - For Visualization, Analytics & Alerting

The benefit of using Promethues is that it follows a "pull" based approach i.e. it polls the target every X unit of time








