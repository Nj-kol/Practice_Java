## Properties to look into

setConnectionTimeout(long connectionTimeoutMs)
setIdleTimeout(long idleTimeoutMs)
setMinimumIdle(int minIdle)
setValidationTimeout(long validationTimeoutMs)

https://www.javadoc.io/doc/com.zaxxer/HikariCP/2.6.3/com/zaxxer/hikari/HikariConfig.html


com.jio.bdcoe.mysql.connectionTimeout="5000"
com.jio.bdcoe.mysql.idleTimeout="15000"
com.jio.bdcoe.mysql.minimumIdle="8"
com.jio.bdcoe.mysql.validationTimeout="1000"

