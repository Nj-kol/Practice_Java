
Instead of :

```json
{
  "query":"select * from customers where customerNumber=496"
}
```

Use :

```json
{
  "source":"customers",
  "columns":"all",
  "criteria":"customerNumber=496"
}
```
