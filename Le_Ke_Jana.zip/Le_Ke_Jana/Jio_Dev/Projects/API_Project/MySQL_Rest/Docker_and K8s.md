
/opt/mysql-rest-service

* Docker file used

```bash
FROM gcr.io/distroless/java:8
ADD ./coe-rest-mysql-assembly-1.0-SNAPSHOT.jar coe-rest-mysql-assembly-1.0-SNAPSHOT.jar
EXPOSE 9000
ENTRYPOINT ["java","-jar","-Dplay.http.secret.key=ad31779d4ee49d5ad5162bf1429c32e2e9933f3b", "-Dbdcoe.ext.conf.file=/opt/mysql-rest-service/api-service-config.properties","-Dbdcoe.mysql.security.master.conf.file=/opt/mysql-rest-service/mysql-api-secure.properties","coe-rest-mysql-assembly-1.0-SNAPSHOT.jar"]
```

sudo docker run -p 30090:9000 -d \
--network canary \
--name coe-rest-mysql-docker \
-v /opt/mysql-rest-service:/opt/mysql-rest-service \
coe-rest-mysql

sudo docker container logs coe-rest-mysql-docker 

sudo docker container stop coe-rest-mysql-docker 
sudo docker container rm coe-rest-mysql-docker 

java \
-Dbdcoe.mysql.security.master.conf.file="${PWD}/mysql-api-secure.properties" \
-Dbdcoe.ext.conf.file="${PWD}/api-service-config.properties" \
-cp "${PWD}/api-token-utils.jar" com.bdcoe.api.TokenGenerator \
"classicmodels" "crm_user" "crm1" "customer_churn"

export CORRECT_CRM_TOKEN=eyJzY2hlbWEiOiJjbGFzc2ljbW9kZWxzIiwidXNlcm5hbWUiOiJjcm1fdXNlciIsInBhc3NmaWxlIjoiL29wdC9teXNxbC1yZXN0LXNlcnZpY2UvcGFzc2ZpbGVzL2N1c3RvbWVyX2NodXJuX2NybV91c2VyIn0=

curl -H "X-Requested-With: Basic ${CORRECT_CRM_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.59:30090/bdcoe/services/mysql/query |jq


/opt/jdk1.8.0_321/bin/keytool \
-import -trustcacerts -alias bdpdata1479.jio.com \
-file /etc/ssl/certs/Req_2962.cer \
-keystore /opt/jdk1.8.0_321/jre/lib/security/cacerts

import java.io._
import java.security._
import javax.net.ssl._


https://jebware.com/blog/?p=340


10.143.168.19 - moni

AppSec and Privacy

http://<host>:<port>/bdcoe/services/mysql/query
http://<host>:<port>/bdcoe/services/mysql/stream

ISR-1844093

prashant12.patil

approval ya exception ( not bypassing )

Deepanshu1 Sharma

    Got token {"schema":"classicmodels","username":"crm_user","passfile":"/home/centos/nilanjan/rest_services/mysql/auth-token/passfiles/customer_churn_crm_user"}
Encoded Token 


Jio Infosec desk


https://www.youtube.com/watch?v=IuPGQY0nEkI

https://www.youtube.com/playlist?list=PLC5388289A61579AE


SELECT TABLESPACE_NAME, STATUS, CONTENTS FROM USER_TABLESPACES;

SELECT * FROM all_users ORDER BY username;


https://bdpdata1479.jio.com:8444


