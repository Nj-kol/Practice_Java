ibraryDependencies += "io.swagger" %% "swagger-play2" % "1.7.1"
libraryDependencies += "org.webjars" % "swagger-ui" % "3.43.0"

play.module.enabled+= "play.modules.swagger.SwaggerModule"
play.filters.disabled+= "play.filters.csrf.CSRFFilter"


https://www.youtube.com/watch?v=LM8E0FKfxcw

https://github.com/iheartradio/play-swagger

https://swagger.io/blog/api-development/playing-with-swagger-using-swagger-and-swagger-ui/


https://github.com/swagger-api/swagger-play


GET /api-docs controllers.ApiHelpController.getResources

GET /docs/swagger-ui/#file controllers.Assets.at(path="/public", file="index.html")

/public/lib/swagger-ui

http://10.159.25.62:9300/swagger.json
http://10.159.25.62:9300/bdcoe/services/swagger.json
http://10.159.25.62:9300/bdcoe/services/bdcoe/services/mysql/swagger.json


http://10.159.25.62:9300/public

addHeader