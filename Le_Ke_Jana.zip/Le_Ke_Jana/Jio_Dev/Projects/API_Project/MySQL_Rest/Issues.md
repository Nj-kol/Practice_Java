
## Observation

```bash
export CORRECT_CYBERSEC_TOKEN=eyJzY2hlbWEiOiJjbGFzc2ljbW9kZWxzIiwidXNlcm5hbWUiOiJjeWJlcnNlY191c2VyIiwicGFzc2ZpbGUiOiIvaG9tZS9jZW50b3MvbmlsYW5qYW4vcmVzdF9zZXJ2aWNlcy9teXNxbC9hdXRoLXRva2VuL3Bhc3NmaWxlcy90aHJlYXRfZGV0ZWN0aW9uX2N5YmVyc2VjX3VzZXIifQ==

curl -H "X-Requested-With: Basic ${CORRECT_CYBERSEC_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq
```

```json
{
  "data": [
    {
      "addressLine1": "Arenales 1938 3'A'",
      "city": "Auckland  ",
      "contactFirstName": "Tony",
      "state": "",
      "salesRepEmployeeNumber": "1612",
      "customerName": "Kelly's Gift Shop",
      "creditLimit": "110000.00",
      "country": "New Zealand",
      "postalCode": "",
      "addressLine2": "",
      "customerNumber": "496",
      "contactLastName": "Snowden",
      "phone": "+64 9 5555500"
    }
  ]
}
```

```bash
curl -H "X-Requested-With: Basic ${CORRECT_CYBERSEC_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=415\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq
```

```json
{
  "data": [
    {
      "addressLine1": "Hansastr. 15",
      "city": "Munich",
      "contactFirstName": "Michael",
      "state": "",
      "salesRepEmployeeNumber": "1504",
      "customerName": "\"Bavarian Collectables Imports, Co.\"",
      "creditLimit": "77000.00",
      "country": "Germany",
      "postalCode": "80686",
      "addressLine2": "",
      "customerNumber": "415",
      "contactLastName": "Donnermeyer",
      "phone": " +49 89 61 08 9555"
    }
  ]
}
```
