
## Transfer

**api utils**

```bash
set KEY_PATH="C:\Users\nilanjan1.sarkar\OneDrive - Reliance Corporate IT Park Limited\Jio_Env\JBDL_Canary\jbdl-canary-gw.pem"
set TARGET_HOST=centos@10.159.25.62
set TARGET_HOST_PATH=/home/centos/nilanjan/rest_services/mysql/auth-token
set ARTIFACT_BASE_PATH=C:\Users\nilanjan1.sarkar\Azure_Devops_Repos\JBDL_API_Platform\api-token-utils\target\scala-2.11

scp -i %KEY_PATH% -r %ARTIFACT_BASE_PATH%\api-token-utils.jar %TARGET_HOST%:%TARGET_HOST_PATH%
```

**rest service**

```bash
set KEY_PATH="C:\Users\nilanjan1.sarkar\OneDrive - Reliance Corporate IT Park Limited\Jio_Env\JBDL_Canary\jbdl-canary-gw.pem"

set TARGET_HOST=centos@10.159.25.62
set TARGET_HOST_PATH=/home/centos/nilanjan/rest_services/mysql/auth-token
set ARTIFACT_BASE_PATH=C:\Users\nilanjan1.sarkar\Azure_Devops_Repos\JBDL_API_Platform\coe-rest-mysql\target\scala-2.11

scp -i %KEY_PATH% -r %ARTIFACT_BASE_PATH%\coe-rest-mysql-assembly-1.0-SNAPSHOT.jar %TARGET_HOST%:%TARGET_HOST_PATH%
```

## Generate master key

cd /home/centos/nilanjan/rest_services/mysql/auth-token

java \
-Dbdcoe.ext.conf.file="${PWD}/api-service-config.properties" \
-cp "/home/centos/nilanjan/rest_services/mysql/auth-token/api-token-utils.jar" \
com.bdcoe.api.GenerateMasterKey

cat ${PWD}/mysql-api-secure.properties

```
com.jio.bdcoe.mysql.security.spec="G4AG0Ti7Y6FpGGnPM8T+Fib86Zh8oN0sJoJqyHl4utc="
com.jio.bdcoe.mysql.security.iv="V/3Iptbv+UEbJgK1laV6wA=="
```

## Generate tokens for API tenants

**Generate token for CRM**

java \
-Dbdcoe.mysql.security.master.conf.file="${PWD}/mysql-api-secure.properties" \
-Dbdcoe.ext.conf.file="${PWD}/api-service-config.properties" \
-cp "/home/centos/nilanjan/rest_services/mysql/auth-token/api-token-utils.jar" \
com.bdcoe.api.TokenGenerator \
"classicmodels" "crm_user" "crm1" "customer_churn"

export CORRECT_CRM_TOKEN=eyJzY2hlbWEiOiJjbGFzc2ljbW9kZWxzIiwidXNlcm5hbWUiOiJjcm1fdXNlciIsInBhc3NmaWxlIjoiL2hvbWUvY2VudG9zL25pbGFuamFuL3Jlc3Rfc2VydmljZXMvbXlzcWwvYXV0aC10b2tlbi9wYXNzZmlsZXMvY3VzdG9tZXJfY2h1cm5fY3JtX3VzZXIifQ==

export INCORRECT_CRM_TOKEN=DQogICAgICB7InNjaGVtYSI6ImNsYXNzaWNtb2RlbHMiLCJ1c2VybmFtZSI6ImNybV91c2VyIiwicGFzc2ZpbGUiOiIvaG9tZS9jZW50b3MvbmlsYW5qYW4vcmVzdF9zZXJ2aWNlcy9teXNxbC9hdXRoLXRva2VuL3Bhc3NmaWxlcy9wYXNzd29yZF9jcm1fdXNlci50eHQifQ0KICAgICBg

curl -H "X-Requested-With: Basic ${CORRECT_CRM_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq

-- Works fine

curl -H "X-Requested-With: Basic ${INCORRECT_CRM_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq

-- Works fine

**Generate token for Cybersec**


java \
-Dbdcoe.ext.conf.file="${PWD}/api-service-config.properties" \
-cp "/home/centos/nilanjan/rest_services/mysql/auth-token/api-token-utils.jar" \
com.bdcoe.api.TokenGenerator \
"classicmodels" "cybersec_user" "cybersec" "threat_detection"

export CORRECT_CYBERSEC_TOKEN=eyJzY2hlbWEiOiJjbGFzc2ljbW9kZWxzIiwidXNlcm5hbWUiOiJjeWJlcnNlY191c2VyIiwicGFzc2ZpbGUiOiIvaG9tZS9jZW50b3MvbmlsYW5qYW4vcmVzdF9zZXJ2aWNlcy9teXNxbC9hdXRoLXRva2VuL3Bhc3NmaWxlcy90aHJlYXRfZGV0ZWN0aW9uX2N5YmVyc2VjX3VzZXIifQ==


export INCORRECT_CYBERSEC_TOKEN=DQogICAgICB7InNjaGVtYSI6ImNsYXNzaWNtb2RlbHMiLCJ1c2VybmFtZSI6ImN5YmVyc2VjX3VzZXIiLCJwYXNzZmlsZSI6Ii9ob21lL2NlbnRvcy9uaWxhbmphbi9yZXN0X3NlcnZpY2VzL215c3FsL2F1dGgtdG9rZW4vcGFzc2ZpbGVzL3Bhc3N3b3JkX2N5YmVyc2VjX3VzZXIudHh0In0NCiAgICAgIY==

curl -H "X-Requested-With: Basic ${CORRECT_CYBERSEC_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq

-- Works fine

curl -H "X-Requested-With: Basic ${INCORRECT_CYBERSEC_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq


-- Works fine

## Change password

sudo docker exec -it mysql-standalone bash
mysql -u root -pasd
ALTER USER 'crm_user'@'%' IDENTIFIED WITH mysql_native_password BY 'crm1';
FLUSH PRIVILEGES;

Case 1 : Providing the old token should result in failure

export OLD_CYBERSEC_TOKEN=DQogICAgICB7InNjaGVtYSI6ImNsYXNzaWNtb2RlbHMiLCJ1c2VybmFtZSI6ImN5YmVyc2VjX3VzZXIiLCJwYXNzZmlsZSI6Ii9ob21lL2NlbnRvcy9uaWxhbmphbi9yZXN0X3NlcnZpY2VzL215c3FsL2F1dGgtdG9rZW4vcGFzc2ZpbGVzL3Bhc3N3b3JkX2N5YmVyc2VjX3VzZXIudHh0In0NCiAgICAgIA==

curl -H "X-Requested-With: Basic ${OLD_CYBERSEC_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq

Case 2 : Providing the new token should result in result

old encrypted password : eGPP/cWDPuxIuXOJKlI+RQ==

**Regenerate the password file**

java \
-Dbdcoe.ext.conf.file="${PWD}/api-service-config.properties" \
-cp "/home/centos/nilanjan/rest_services/mysql/auth-token/api-token-utils.jar" \
com.bdcoe.api.TokenGenerator "classicmodels" "crm_user" "crm1" 

new encrypted password : kGYvZd/4A1I0UBhm/QD5xA==

export NEW_CRM_TOKEN=DQogICAgICB7InNjaGVtYSI6ImNsYXNzaWNtb2RlbHMiLCJ1c2VybmFtZSI6ImNybV91c2VyIiwicGFzc2ZpbGUiOiIvaG9tZS9jZW50b3MvbmlsYW5qYW4vcmVzdF9zZXJ2aWNlcy9teXNxbC9hdXRoLXRva2VuL3Bhc3NmaWxlcy9wYXNzd29yZF9jcm1fdXNlci50eHQifQ0KICAgICAg

curl -H "X-Requested-With: Basic ${NEW_CRM_TOKEN}" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq



# Test password

**Correct**

echo '{"schema":"classicmodels","username":"crm_user","passfile":"/home/centos/nilanjan/rest_services/mysql/auth-token/passfiles/password_crm.txt"}' | base64

curl -H "X-Requested-With: Basic eyJzY2hlbWEiOiJjbGFzc2ljbW9kZWxzIiwidXNlcm5hbWUiOiJjcm1fdXNlciIsInBhc3NmaWxlIjoiL2hvbWUvY2VudG9zL25pbGFuamFuL3Jlc3Rfc2VydmljZXMvbXlzcWwvYXV0aC10b2tlbi9wYXNzZmlsZXMvcGFzc3dvcmRfY3JtLnR4dCJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq

**Incorrect**

curl -H "X-Requested-With: Basic DQogICAgICB7InNjaGVtYSI6ImNsYXNzaWNtb2RlbHMiLCJ1c2VybmFtZSI6ImNybV91c2VyIiwicGFzc2ZpbGUiOiIvaG9tZS9jZW50b3MvbmlsYW5qYW4vcmVzdF9zZXJ2aWNlcy9teXNxbC9wYXNzd29yZF9jcm1fdXNlci50eHQifQ0KICAgICAg" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq


**With Encryption**

curl -H "X-Requested-With: Basic DQogICAgICB7InNjaGVtYSI6ImNsYXNzaWNtb2RlbHMiLCJ1c2VybmFtZSI6ImNybV91c2VyIiwicGFzc2ZpbGUiOiIvaG9tZS9jZW50b3MvbmlsYW5qYW4vcmVzdF9zZXJ2aWNlcy9teXNxbC9wYXNzd29yZF9jcm1fdXNlci50eHQifQ0KICAgICAg" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d "{\"query\":\"select * from customers where customerNumber=496\"}" \
http://10.159.25.62:9300/bdcoe/services/mysql/query | jq


## Documents

* RR
* Usage
