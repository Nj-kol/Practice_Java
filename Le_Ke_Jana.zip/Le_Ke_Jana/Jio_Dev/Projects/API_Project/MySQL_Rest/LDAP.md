
## AD

**Correct**

com.jio.bdcoe.ldap.search.filter="(memberOf=CN=GALL--DEVJBDL--TOOLS--JDSP,OU=JBDL_DEV,OU=GROUPS,OU=JIO_IT,OU=MEMBER SERVERS,DC=rjil,DC=ril,DC=com)"

**Incorrect**

com.jio.bdcoe.ldap.search.filter="(memberOf=CN=GALL--DEVJBDL--TOOLS--NIFI,OU=JBDL_DEV,OU=GROUPS,OU=JIO_IT,OU=MEMBER SERVERS,DC=rjil,DC=ril,DC=com)"

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_workitems/edit/10646

