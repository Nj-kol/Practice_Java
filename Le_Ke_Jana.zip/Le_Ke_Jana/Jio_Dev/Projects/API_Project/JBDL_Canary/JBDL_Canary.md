
# JBDL Canary Environment

## Submit

cd /Users/nilanjan1.sarkar/hive-rest-service

java \
-Dbuild_env=jbdl-dev \
-Dbdcoe.ext.conf.file="/Users/nilanjan1.sarkar/Documents/Jio_Env/JBDL_Canary/hive-local-config.properties" \
-Dplay.http.secret.key=secretkey \
-Dhttp.port=9000 \
-Dhttp.address=localhost \
-cp ${HOME}/Documents/Eclipse_Workspaces/Platform_Components/coe-rest-services/target/coe-rest-services-assembly-1.1.0.jar \
play.core.server.ProdServerStart

## Connect Play to Canary

CODE_LOCATION = /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Platform_Components/coe-rest-services

cd ${CODE_LOCATION}

sbt \
-J-Xms512M -J-Xmx1024M -J-Xss1M -J-XX:+CMSClassUnloadingEnabled \
-J-Dsbt.repository.config="/Users/nilanjan1.sarkar/.sbt/.repositories" \
-J-Dbdcoe.ext.conf.file="/Users/nilanjan1.sarkar/Documents/Jio_Env/JBDL_Canary/hive-local-config.properties" \
-Dsbt.override.build.repos=true \
-Dhttp.address=0.0.0.0 

## Encode/decode Token

**Encode**

echo '{"principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/tmp/"}' | base64

echo '{"principal":"Nilanjan1.Sarkar","keytab":"March20"}' | base64

**Decode**

echo 'eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvaG9tZS9jbG91ZC11c2VyL2tlcmJlcm9zX2ZpbGVzL2Rldl9qYmRsX2hpdmVyZXN0LmtleXRhYiJ9Cg==' | base64 --decode | jq

{
  "principal": "dev_jbdl_hiverest@RJIL.RIL.COM",
  "keytab": "/tmp/"
}

# Making Request

## Unary

**Syntax**

curl -H "X-Requested-With: Basic <your_token>" \
-H "Accept: <requested_format>" \
-H "Content-Type: application/json" \
-X POST -d '{"query":"<your_sql_query>"}' \
http://<host>:<port>/bdcoe/services/hive/query

**Example**

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvdG1wLyJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d '{"query":"select * from platform.cars"}' \
http://localhost:9000/bdcoe/services/hive/query  | jq

select * from platform.dummy_data limit 87

## Streaming

**Syntax**

curl -H "X-Requested-With: Basic <your_token>" \
-H "Accept: <requested_format>" \
-H "Content-Type: application/json" \
-X POST -d '{"query":"<valid_sql_string>", "maxBatchSize": <valid_integer_value>}' \
http://<host>:<port>/bdcoe/services/hive/stream

**Example**

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvdG1wLyJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d '{"query":"select * from platform.dummy_data limit 1234", "maxBatchSize": 1000}' \
http://localhost:9000/bdcoe/services/hive/stream | jq

Note : The maxBatchSize is an optional paramters, an optimal value is set by default

**CSV**

-H "Accept: application/csv" 

## Submit

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvdG1wLyJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d '{"query":"select * from platform.cars"}' \
http://localhost:9000/bdcoe/services/hive/submit  | jq

## Log location

/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Platform_Components/coe-rest-services/logs/application.log

tail -100f /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Platform_Components/coe-rest-services/logs/application.log

## Git Repos

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_Hive_Rest_Service/coe-rest-services
https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_HDP_Integration/coe-platform

## Hack to load properties in local

In ConfigLoader.scala of coe-platform, comment the existing getConfig method and add :

```
private val configFile = new File(INSTANCE_CONF)

def getConfig: Config = {
	if(conf != null) return conf
	println(s"laodnf from ${INSTANCE_CONF}")
	conf =  ConfigFactory.parseFile(configFile)
	conf
}
```

open /Users/nilanjan1.sarkar/Documents/Jio_Env/JBDL_Canary/hive-local-config.properties

com.jio.bdcoe.mysql.jdbc.driverName=com.mysql.jdbc.Driver
com.jio.bdcoe.mysql.jdbc.url=jdbc:mysql://10.159.21.107:30006/sample?autoReconnect=true&useSSL=false
com.jio.bdcoe.mysql.jdbc.username=root
com.jio.bdcoe.mysql.jdbc.password=asd

ssh -i /Users/nilanjan1.sarkar/Documents/Jio_Env/JBDL_Canary/jbdl_dev_canary.pem centos@10.159.21.85

hdfs dfs -mkdir -p /tmp/Nilanjan/data/cybersecurity/analytics

hadoop fs -chmod -R 777 /tmp/Nilanjan/data/cybersecurity/analytics

hdfs dfs -ls /tmp/Nilanjan/data/cybersecurity/analytics

hdfs dfs -ls /tmp/Nilanjan/data/cybersecurity/analytics/partition_date=2020-10-20/cd40aed551000bd0169c258815dcd64f701986ba7deffbef04454922c5dcae2c

# Webhook

## Subscribe

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvdG1wLyJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d '{"tenantName":"cybersec","dbType" : "hive","channelType": "email","channelId" : "infosec@ril.com"}' \
http://localhost:9000/bdcoe/services/hive/webhooks/subscribe | jq

## Update subscription

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvdG1wLyJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d '{"tenantName":"cybersec","dbType" : "hive", "channelId" : "cybersec1@ril.com"}' \
http://localhost:9000/bdcoe/services/hive/webhooks/updatesubscription | jq

## Unsubscribe

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvdG1wLyJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d '{"tenantName":"cybersec","dbType" : "hive"}' \
http://localhost:9000/bdcoe/services/hive/webhooks/unsubscribe | jq


curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvdG1wLyJ9Cg==" \
-H "Accept: application/json"  \
-H "Content-Type: application/json" \
-X POST -d '{"tenantName":"crm","dbType" : "hive","channelType": "email","channelId" : "infosec@ril.com"}' \
http://localhost:9000/bdcoe/services/hive/webhooks/subscribe | jq