
# Chunked Transfer

Task 124858 : coe-rest-service App to have functionality to send large volumes of data back to user
Task 124859 : coe-rest-service App to provide other formats apart from CSV for the response
Task 125162 : Work on buffering rows in stream mode in coe-rest-services
Task 125262 : Performance testing and optimization of stream mode in coe-rest-services

Essentially, need to add an API in DBQueryServiceImpl that returns a stream back, keeping the DB connection open. 

This stream gets wrapped into a chunked response in play.


https://www.playframework.com/documentation/2.7.x/ScalaStream
https://stackoverflow.com/questions/11209818/java-sql-result-to-inputstream/11254010

https://www.playframework.com/documentation/2.7.x/ScalaStream#Chunked-responses


https://developer.lightbend.com/docs/telemetry/2.7.x/instrumentations/play/play.html

def chunked = Action {
  val data                               = getDataStream
  val dataContent: Source[ByteString, _] = StreamConverters.fromInputStream(() => data)
  Ok.chunked(dataContent)
}

RequestHandler -> HiveQueryController

Let’s say that we have a service somewhere ***that provides a dynamic InputStream computing some data.***

Step 1 : ***First we have to create an Source for this stream***

```
val data                               = getDataStream
val dataContent: Source[ByteString, _] = StreamConverters.fromInputStream(() => data)
```

Step 2 : We can now stream these data using a Ok.chunked:

def chunked = Action {
  val data                               = getDataStream
  val dataContent: Source[ByteString, _] = StreamConverters.fromInputStream(() => data)
  Ok.chunked(dataContent)
}



https://github.com/akka/akka/blob/master/akka-docs/src/test/scala/docs/stream/operators/converters/ToFromJavaIOStreams.scala


## Test

**Local**

curl -v -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/krb5-keytab-volume/dev_jbdl_hiverest.keytab"}' http://localhost:9000/bdcoe/services/hive/query/stream


binding defined in HiveQueryServiceFactory

## Router

HiveRequestRouter

## Flow 

HiveQueryResourceHandler -> HiveRepositoryImpl


## Execution steps

BASEPATH=/Users/nilanjan1.sarkar/Documents/JBDL_Repos/coe-rest-services-k8s
BASEPATH=/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Play_Apps/coe-rest-services

**Compile**

cd ${BASEPATH}

sbt -J-Dsbt.repository.config="${HOME}/.sbt/.repositories" -Dsbt.override.build.repos=true 
clean
assembly

**Transfer Jar**

scp -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem  \
-r ${BASEPATH}/target/coe-rest-services-k8s-assembly-1.0.0-SNAPSHOT.jar \
cloud-user@10.157.88.193:/home/cloud-user/

**Run the Jar**

ssh -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem cloud-user@10.157.88.193

java -jar \
-Dplay.http.secret.key=ad31779d4ee49d5ad5162bf1429c32e2e9933f3b \
-Djava.security.krb5.conf=/etc/krb5.conf \
-Dlog4j.configurationFile=log4j2.xml \
-Dhttp.port=30090 \
${HOME}/coe-rest-services-k8s-assembly-1.0.0-SNAPSHOT.jar

## Stream

curl -v -k -H "Accept: application/json"  -H "Content-Type: application/json" -X POST -d '{"query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 2","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30090/bdcoe/services/hive/query/stream

{
   "columns":[
      {
         "colName":"cell_area",
         "colType":"bigint",
         "colValue":"0"
      },
      {
         "colName":"userplane_upload_throughput_bucket_3_count",
         "colType":"bigint",
         "colValue":"0"
      },
      {
         "colName":"cell_area",
         "colType":"bigint",
         "colValue":"0"
      },
      {
         "colName":"userplane_upload_throughput_bucket_3_count",
         "colType":"bigint",
         "colValue":"0"
      }
   ]
}

curl -v -k -H "Accept: text/csv"  -H "Content-Type: application/json" -X POST -d '{"query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 2","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30090/bdcoe/services/hive/query/stream

```
cell_area,userplane_upload_throughput_bucket_3_count
0,0
```

## Regular

**JSON**

curl -v -k -H "Accept: application/json"  -H "Content-Type: application/json" -X POST -d '{"query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 2","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:9000/bdcoe/services/hive/query

```
{
   "data":[
      {
         "subscriber_id":"-396856807",
         "subscriber_age":"",
         "subscriber_gender":""
      },
      {
         "subscriber_id":"-395087719",
         "subscriber_age":"",
         "subscriber_gender":""
      },
      {
         "subscriber_id":"-347317075",
         "subscriber_age":"",
         "subscriber_gender":""
      },
      {
         "subscriber_id":"-334285083",
         "subscriber_age":"",
         "subscriber_gender":""
      }
   ]
}
```


**CSV**

curl -v -k -H "Accept: text/csv"  -H "Content-Type: application/json" -X POST -d '{"query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 3","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:9000/bdcoe/services/hive/query

["cell_area,userplane_upload_throughput_bucket_3_count","0,0","0,0","0,0"]

 java -jar -Dplay.http.secret.key=ad31779d4ee49d5ad5162bf1429c32e2e9933f3b \
 -Djava.security.krb5.conf=/etc/krb5.conf \
 -Dlog4j.configurationFile=${PWD}/log4j2.xml \
 ${HOME}/coe-rest-services-assembly-1.0.0-SNAPSHOT.jar


https://wiki.jio.com/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Projects/Hive%20Rest%20Service/?srid=npeyIuIc

## Pass data from URL to controller

<http_method>    /<path>/:<variable_name>    <controlller>.method(<variable_name>: <variable_type>)

Ex - 

GET     /welcome/:firtsname/:lastname                          controllers.HomeController.doSomething(firtsname: String,lastname: String)

## Create and Pass Data to Views 

app -> views

curl -v -k -H "Accept: application/json"  -H "Content-Type: application/json" -X POST -d '{"query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 15","maxRows":"5","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30090/bdcoe/services/hive/query/stream


Features :

https://wiki.jio.com/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Projects/Hive%20Rest%20Service/Features/?srid=fAuzXy1g

Metrics :

http://10.141.165.155:8080/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/JBDL%20API%20Platform/Representation%20of%20Metrics%20Grafana%20/

