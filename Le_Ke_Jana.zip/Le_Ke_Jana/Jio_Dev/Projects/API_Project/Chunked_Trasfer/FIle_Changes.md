
# Code Changes

## COE REST Service

git add app/bdcoe/services/hive/components

HiveRepository
HiveQueryResourceHandler
HiveQueryController
HiveRequestRouter

## Platform

package : com.jio.bdcoe.models

DBTableModels

git add src/main/scala/com/jio/bdcoe/models/

**package :  com.jio.bdcoe.services.db.hive**

HiveQueryServiceFactory

git add src/main/scala/com/jio/bdcoe/services/db/hive

**package : com.jio.bdcoe.services.db**

git add src/main/scala/com/jio/bdcoe/services/db
git add src/main/scala/com/jio/bdcoe/services/db

git add src/main/scala/com/jio/bdcoe/services/db/DBQueryService.scala
git add src/main/scala/com/jio/bdcoe/services/db/DBQueryServiceImpl.scala
git add src/main/scala/com/jio/bdcoe/services/db/StreamQueryServiceImpl.scala

DBQueryService
DBQueryServiceImpl
StreamQueryServiceImpl

**package : com.jio.bdcoe.services.utils**

git add src/main/scala/com/jio/bdcoe/services/utils

ApiSpecs
ResponseBodyWriterFactory
CSVResponseBodyWriter
CSVStreamingResponseBodyWriter
JSONResponseBodyWriter
JSONStreamingResponseBodyWriter