
## Parent

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform

## Platform related componets**

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core

Will contain components that are orthogonal to all services, acting as system services

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/traefik/
https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/prometheus/
https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/graphana/
https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/jaeger/

## Domain related Services**

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services

Will contain specific services, it may be use-case driven or as general services ( Ex - coe-rest-service for Hive )

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services/coe-rest-services-k8s
