
# JBDL API Platform

Proposal to build a robust and scalable API platform to serve data from the Jio Big Data Lake ( JBDL ) 

* An RTC feature has been created to track all activity : 

   **Feature 120006 - Building API Platform component - Microservices**

* To this end, several POCs were done to evaluate several techlogical and architectures practices. 
* Eventually Kubeerntes was chosen. The details of the POCs conducted can be seen in the following wiki page tree :

  http://10.141.165.155:8080/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/JBDL%20API%20Platform/

* Exclusive repositories have been created in JBDL GitLab for this platform. F
  or ease of organization, a top level folder to hold all artifacts has been created :

 https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform

Under this two sub-folders have been created :

1. https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core 

The objective of this folder is to group all platform components

2. https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services

The objective of this folder is to group all microservices

# Deployment plan

Instead of a big bang deployment, we chose a phased deployment plan. This will enable us to deliver faster and also evaluate the current approach.

## Phase 1 

In the first phase, the existing RESTful service *coe-rest-service* has been chosen. The exisitng app has been retrofitted to work with kubernetes.

As part of the initial rollout, we have chosen to do the following

* Deploy Traefik as an API Gateway
* Deployed the refactoted solution 

In phase 1, logs will be written to disk.

## Phase 2

* Centralized Logging of all components ( Elasticsearch )
  * Log Anyalitcs ( Kibana ) - Optional
* Monitoring ( Prometheus )
* Distributed Tracing ( Jaeger )

## Phase 3

* Token based authentication
* Metering
* Other Advanced features such as :
  * Traffic Splitting and mirroring
  * Canary Deployment
  * gRPC 

