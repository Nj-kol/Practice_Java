
# Netflix OSS Demo Runbook

**Quickstart**

docker container start zookeeper
docker container start kafka-sample 

docker container start microservice-config-server-v2
docker container start service-registry-v2
docker container start api-gateway-v2
docker container start mysql-standalone
docker container start elastic-standalone
docker container start kibana
docker container start prometheus-standalone
docker container start grafana-standalone
docker container start user-data-service-v2
docker container start user-services-api-v2

docker container run --rm -it \
--name jaeger \
--network=sandbox \
-e COLLECTOR_ZIPKIN_HTTP_PORT=9411 \
-p 5775:5775/udp \
-p 6831:6831/udp \
-p 6832:6832/udp \
-p 5778:5778 \
-p 16686:16686 \
-p 14268:14268 \
-p 9411:9411 \
jaegertracing/all-in-one

docker container start mongo-standalone
docker container start zipkin-v2

jvm_gc_pause_seconds_count
process_cpu_usage
process_files_open_files
logback_events_total
hystrix_execution_total

sum(jvm_memory_used_bytes{application="user-app", instance="user-services-api-v2:9181", area="heap"})

## Test through browser

http://localhost:8181/user/getbyid/4
http://localhost:9181/services/greet/4
http://localhost:8081/api/user-app/services/greet/4
http://localhost:8181/swagger-ui.html

*Circuit Breaker*
http://localhost:9181/hystrix
http://localhost:9181/actuator/hystrix.stream

*Monitoring*
http://localhost:9090/graph
http://localhost:3000/login

*Tracing*
http://localhost:16686/search

*Logging*
http://localhost:5601

**Detachable Storage**

docker container stop user-data-service
docker container rm user-data-service

docker container run -p 8181:8181 \
--name user-data-service \
--network sandbox \
-e MONGODB_HOST=mongo-standalone \
-e MONGODB_PORT=27017 \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin-v2 \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server \
-e CONFIG_SERVER_PORT=8888 \
mongodb-data-service

## Start the Tracing server

**Docker**

*Start Zipkin in a container*

docker container start zipkin-v2

docker container run -p 9411:9411 -d \
--name zipkin-v2 \
--network sandbox \
openzipkin/zipkin

*Check*

docker container logs zipkin-standalone
http://localhost:9411/zipkin/

**Manual**

nohup java -jar /opt/zipkin/1.28/zipkin-server-1.28.0-exec.jar </dev/null &>/dev/null & 
java -jar /opt/zipkin/1.28/zipkin-server-1.28.0-exec.jar

kill -9 21820

## Start Config Server 

**Docker**

*Start a config server in a container*

docker container start microservice-config-server-v2 

docker container run -p 8888:8888 -d \
--name microservice-config-server-v2 \
--network sandbox \
-e GITHUB_USER=Nj-kol \
-e GITHUB_PASS=@Somnath88 \
-e CONFIG_SERVER_PORT=8888 \
microservice-config-server-v2 

*Build config server image*

docker container stop microservice-config-server-v2
docker container rm microservice-config-server-v2
docker image rm microservice-config-server-v2
docker image build -t microservice-config-server-v2 /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/config-server

*Housekeeping*

ps -ef | grep config-server

docker container logs microservice-config-server-v2 

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/config-server/scripts/run_server.sh

## Start Service Registry

**Docker**

*Start discovery server in a container*

docker container start service-registry-v2

docker container run -p 8761:8761 -d \
--name service-registry-v2 \
--network sandbox \
-e ZIPKIN_SERVER_HOST=zipkin-standalone \
-e ZIPKIN_SERVER_PORT=9411 \
eureka-service-registry-v2

*Build config server image*

docker container stop service-registry-v2
docker container rm service-registry-v2
docker image rm eureka-service-discovery-v2
docker image build -t eureka-service-registry-v2 /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/service-registry

*Housekeeping*

ps -ef | grep service-registry
docker container logs service-registry-v2
http://localhost:8761

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/service-registry/scripts/run_server.sh

## Start API Gateway

**Docker**

*Start Zuul API gateway server in a container*

docker container start api-gateway-v2

docker container run -p 8081:8081 -d \
--name api-gateway-v2 \
--network sandbox \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry-v2 \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin-v2 \
-e ZIPKIN_SERVER_PORT=9411 \
zuul-api-gateway-v2

*Build API server image*

docker container stop api-gateway-v2
docker container rm api-gateway-v2
docker image rm zuul-api-gateway-v2

docker image build -t zuul-api-gateway-v2 /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/api-gateway

*Check*

docker container logs api-gateway-v2
docker container exec -it api-gateway bash
http://localhost:8761

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/api-gateway/scripts/run_server.sh

ps -ef| grep api-gateway

## Start Datastores

docker container start mongo-standalone
docker container start mysql-standalone

*House Keeping*

docker container exec -it mongo-standalone mongo
docker container exec -it mysql-standalone mysql -u root -pasd

## Start Storage APIs

#### MongoDB

**Docker**

*Start mongodb crud service in a container*

docker container start user-data-service-v2

docker container run -p 8181:8181 \
--name user-data-service \
--network sandbox \
-e MONGODB_HOST=mongo-standalone \
-e MONGODB_PORT=27017 \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry-v2 \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin-v2 \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server \
-e CONFIG_SERVER_PORT=8888 \
mongodb-data-service

*Build mysql crud service image*

docker image build \
--no-cache \
-t mongodb-data-service \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring/mongodb-data-service

docker container stop user-data-service
docker container rm user-data-service
docker image rm mongodb-data-service

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring/mongodb-data-service/scripts/run_server.sh 8181

#### MySql

**Docker**

*Start mysql crud service in a container*

docker container start user-data-service-v2 

docker container run -p 8181:8181 \
--name user-data-service-v2  \
--network sandbox \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry-v2 \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin-v2 \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server-v2 \
-e CONFIG_SERVER_PORT=8888 \
-e MYSQL_HOST=mysql-standalone \
-e MYSQL_PORT=3306 \
-e MYSQL_USER=root \
-e MYSQL_PASS=asd \
mysql-data-service-v2 

*Build mysql crud service image*

docker container stop user-data-service-v2 
docker container rm user-data-service-v2 
docker image rm mysql-data-service -v2 

docker image build \
--no-cache \
-t mysql-data-service-v2  \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/mysql-data-service

*House Keeping*

docker container start user-data-service
docker container logs user-data-service

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/mysql-data-service/scripts/run_server.sh 8181

**Refresh Scope**

http://localhost:8181/refresh

## Start API layer 

**Docker**

*Start user API service in a container*

docker container start user-services-api-v2

docker container run -p 9181:9181 \
--name user-services-api-v2 \
--network sandbox \
-e USER_SERVICE_PORT=9181 \
-e CRUD_SERVICE_URL=http://user-data-service-v2:8181/user \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry-v2  \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin-v2 \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server-v2 \
-e CONFIG_SERVER_PORT=8888 \
user-services-api-v2 

*Build image*

docker container stop user-services-api-v2
docker container rm user-services-api-v2
docker image rm user-services-api-v2

docker image build \
--no-cache \
-t user-services-api-v2 \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/user-services-api

*House Keeping*

docker container logs --tail user-services-api-v2
docker container inspect user-services-api-v2
docker container exec -it user-services-api-v2 bash

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Spring_2/user-services-api/scripts/run_server.sh 9181

## Start Monitoring Systems

**Prometheus**

*Start prometheus*

docker container run -p 9090:9090 -d \
--name prometheus-standalone \
--network sandbox \
-v /Users/nilanjan1.sarkar/Documents/BindMounts/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml \
prom/prometheus --config.file=/etc/prometheus/prometheus.yml 

docker container start prometheus-standalone

http://localhost:9090/graph

**Graphana**

*Start grafana*

docker container run -d \
-p 3000:3000 \
--network="sandbox" \
--name=grafana-standalone \
-v grafana-storage:/var/lib/grafana \
grafana/grafana

docker container start grafana-standalone

http://localhost:3000/login

Prom query : user_app_greet_request_seconds_count

## Start Logging Systems

TODO

## DB Checks

**MongoDB**

docker container exec -it mongo-standalone mongo
use test;
db.user.find()

**MySQL**

docker container exec -it mysql-standalone mysql -u root -pasd
use test;
select * from user;




