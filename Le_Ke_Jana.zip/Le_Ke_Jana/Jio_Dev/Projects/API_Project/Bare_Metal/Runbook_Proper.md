

# Netflix OSS Demo Runbook

https://wiki.jio.com/display/JBDL/JBDL+API+Platform

**Quickstart**

docker container restart microservice-config-server
docker container start service-registry
docker container start api-gateway
docker container start mysql-standalone
docker container start user-data-service
docker container start zookeeper

docker container start kafka-sample 

*wait*

docker container restart user-services-api

docker container start prometheus-standalone
docker container start grafana-standalone

docker container start elastic-standalone
docker container start kibana

docker container run --rm -it \
--name jaeger \
--network=sandbox \
-e COLLECTOR_ZIPKIN_HTTP_PORT=9411 \
-p 5775:5775/udp \
-p 6831:6831/udp \
-p 6832:6832/udp \
-p 5778:5778 \
-p 16686:16686 \
-p 14268:14268 \
-p 9411:9411 \
jaegertracing/all-in-one

docker container run --rm -it \
-p 5044:5044 -p 9600:9600 \
--name logstash-kafka \
--network sandbox \
-v /Users/nilanjan1.sarkar/Documents/BindMounts/logstash:/usr/share/logstash/config \
logstash:6.8.4 -f /usr/share/logstash/config/logstash-user-services-api.conf


docker container start mongo-standalone
docker container start zipkin-v2

## Test through browser

http://localhost:8181/user/getbyid/4
http://localhost:9181/services/greet/4
http://localhost:8081/api/user-app/services/greet/4
http://localhost:8181/swagger-ui.html

*Circuit Breaker*

http://localhost:9181/hystrix
http://localhost:9181/actuator/hystrix.stream

*Monitoring*

http://localhost:9090/graph
http://localhost:3000/login

*Tracing*

http://localhost:16686/search

*Logging*

http://localhost:5601

**Detachable Storage**

docker container stop user-data-service
docker container rm user-data-service

docker container run -p 8181:8181 \
--name user-data-service \
--network sandbox \
-e MONGODB_HOST=mongo-standalone \
-e MONGODB_PORT=27017 \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin-v2 \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server \
-e CONFIG_SERVER_PORT=8888 \
mongodb-data-service

## Start the Tracing server

**Docker**

*Start Zipkin in a container*

docker container start zipkin-v2

docker container run -p 9411:9411 -d \
--name zipkin-v2 \
--network sandbox \
openzipkin/zipkin

*Check*

docker container logs zipkin-standalone
http://localhost:9411/zipkin/

**Manual**

nohup java -jar /opt/zipkin/1.28/zipkin-server-1.28.0-exec.jar </dev/null &>/dev/null & 
java -jar /opt/zipkin/1.28/zipkin-server-1.28.0-exec.jar

kill -9 21820

## Start Config Server 

**Docker**

*Build config server image*

docker image build -t \
microservice-config-server \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/config-server

*Start a config server in a container*

docker container run -p 8888:8888 -d \
--name microservice-config-server \
--network sandbox \
-e GITHUB_USER=Nj-kol \
-e GITHUB_PASS=@Somnath88 \
-e CONFIG_SERVER_PORT=8888 \
microservice-config-server

*Housekeeping*

docker container logs microservice-config-server
docker container start microservice-config-server
docker container rm microservice-config-server

ps -ef | grep config-server

**Non-Docker**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/config-server/scripts/run_server.sh

## Start Service Registry

**Docker**

*Build config server image*

docker image build -t \
eureka-service-registry \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/service-registry

*Start discovery server in a container*

docker container start service-registry

docker container run -p 8761:8761 -d \
--name service-registry \
--network sandbox \
-e ZIPKIN_SERVER_HOST=zipkin-standalone \
-e ZIPKIN_SERVER_PORT=9411 \
eureka-service-registry

*Housekeeping*

ps -ef | grep service-registry
docker container logs service-registry
docker container stop service-registry
docker container rm service-registry
docker image rm eureka-service-discovery
docker container run service-registry

http://localhost:8761

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/service-registry/scripts/run_server.sh

## Start API Gateway

**Docker**

*Build API server image*

docker image build -t \
zuul-api-gateway \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/api-gateway

*Start Zuul API gateway server in a container*

docker container start api-gateway

docker container run -p 8081:8081 -d \
--name api-gateway \
--network sandbox \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin \
-e ZIPKIN_SERVER_PORT=9411 \
zuul-api-gateway

*Housekeeping*

docker container logs api-gateway
docker container stop api-gateway
docker container rm api-gateway
docker image rm zuul-api-gateway
docker container exec -it api-gateway bash
http://localhost:8761

**Manual**

sh <workspace_path>/api-gateway/scripts/run_server.sh

ps -ef| grep api-gateway

## Start Kafka for log streaming

**Zookeeper**

docker container start zookeeper

docker container run \
--name zookeeper -p 2181 \
--network sandbox \
-t wurstmeister/zookeeper

docker container stop zookeeper
docker container rm zookeeper

**Kafka**

docker container start kafka-sample

docker container run \
-p 9092:9092 \
--name kafka-sample \
--network sandbox \
-e KAFKA_ADVERTISED_HOST_NAME=kafka-sample \
-e KAFKA_ADVERTISED_PORT=9092 \
-e KAFKA_BROKER_ID=1 \
-e KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 \
-e ZK=zk \
-t wurstmeister/kafka

docker container stop kafka-sample
docker container rm kafka-sample

docker container exec -it kafka-sample bash

kafka-topics.sh --zookeeper zookeeper:2181 --list

kafka-console-consumer.sh \
--bootstrap-server localhost:9092 \
--topic user-services-api-logs

--from-beginning 

## Start Datastores

**MySql**

docker pull mysql

docker container run -d --name mysql -e MYSQL_ROOT_PASSWORD=asd  

docker container run -p 3306:3306 -d \
--name mysql-standalone \
--network sandbox \
-e MYSQL_ROOT_PASSWORD=asd \
 -v mysql-standalone-data:/var/lib/mysql \
mysql:5.6

**MongoDB**

docker pull mongo:4.2

docker container run -p 27017:27017 -d \
--name mongo-standalone \
--network sandbox \
-v mongodata:/data/db \
mongo:4.2

*House Keeping*

docker container start mongo-standalone
docker container exec -it mongo-standalone mongo

docker container start mysql-standalone
docker container exec -it mysql-standalone mysql -u root -pasd

## Start Storage APIs

#### MongoDB

**Docker**

*Build mysql crud service image*

docker image build \
--no-cache \
-t mongodb-data-service \
<workspace_path>/mongodb-data-service

*Start mongodb crud service in a container*

docker container start user-data-service

docker container run -p 8181:8181 \
--name user-data-service \
--network sandbox \
-e MONGODB_HOST=mongo-standalone \
-e MONGODB_PORT=27017 \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server \
-e CONFIG_SERVER_PORT=8888 \
mongodb-data-service

*Housekeeping*
docker container stop user-data-service
docker container rm user-data-service
docker image rm mongodb-data-service

**Manual**

sh <workspace_path>/mongodb-data-service/scripts/run_server.sh 8181

#### MySql

**Docker**

*Build mysql crud service image*

docker image build \
--no-cache \
-t mysql-data-service \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/mysql-data-service

*Start mysql crud service in a container*

docker container start user-data-service

docker container run -p 8181:8181 \
--name user-data-service  \
--network sandbox \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server \
-e CONFIG_SERVER_PORT=8888 \
-e MYSQL_HOST=mysql-standalone \
-e MYSQL_PORT=3306 \
-e MYSQL_USER=root \
-e MYSQL_PASS=asd \
mysql-data-service

*House Keeping*

docker container stop user-data-service
docker container rm user-data-service
docker image rm mysql-data-service

**Manual**

sh <workspace_path>/mysql-data-service/scripts/run_server.sh 8181

**Refresh Scope**

http://localhost:8181/refresh

## Start API layer 

**Docker**

*Build image*

docker image build \
--no-cache \
-t user-services-api \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/user-services-api

*Start user API service in a container*

docker container start user-services-api

docker container run -d -p 9181:9181 \
--name user-services-api \
--network sandbox \
-e USER_SERVICE_PORT=9181 \
-e CRUD_SERVICE_URL=http://user-data-service:8181/user \
-e API_GATEWAY_PORT=8081 \
-e REGISTRY_SERVER_HOST=service-registry \
-e REGISTRY_SERVER_PORT=8761 \
-e ZIPKIN_SERVER_HOST=zipkin \
-e ZIPKIN_SERVER_PORT=9411 \
-e CONFIG_SERVER_HOST=microservice-config-server \
-e CONFIG_SERVER_PORT=8888 \
user-services-api 

*House Keeping*

docker container logs user-services-api

docker container stop user-services-api
docker container rm user-services-api
docker image rm user-services-api

docker container exec -it user-services-api bash

**Manual**

sh /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/jbdl-api-framework-demo/scripts/run_server.sh 9181

## Start Monitoring Systems

**Prometheus**

*Start prometheus*

docker container start prometheus-standalone

docker container run -p 9090:9090 -d \
--name prometheus-standalone \
--network sandbox \
-v /Users/nilanjan1.sarkar/Documents/BindMounts/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml \
prom/prometheus --config.file=/etc/prometheus/prometheus.yml 

http://localhost:9090/graph

**Graphana**

*Start grafana*

docker container start grafana-standalone

docker container run -d \
-p 3000:3000 \
--network="sandbox" \
--name=grafana-standalone \
-v grafana-storage:/var/lib/grafana \
grafana/grafana

http://localhost:3000/login

Prom query : user_app_greet_request_seconds_count

## Start Logging Systems

**Elastic**

*Start a new container*

docker network create sandbox

sudo docker container run -p 9200:9200 -p 9300:9300 -d \
--name elastic-standalone \
--network sandbox \
-v esdata:/usr/share/elasticsearch/data \
-e "discovery.type=single-node" \
elasticsearch:6.8.4

*Housekeeping*  

docker container start elastic-standalone
docker container stop elastic-standalone
docker container logs elastic-standalone  

http://localhost:9200

**Kibana**

*Start a new container*

docker container run -p 5601:5601 -d \
--name kibana \
--network sandbox \
-e "ELASTICSEARCH_URL=http://elastic-standalone:9200" \
kibana:6.8.4

*Housekeeping*  

docker container start kibana
docker container stop kibana
docker container logs kibana

http://localhost:5601

**Logstash**

docker container run --rm -it \
-p 5044:5044 -p 9600:9600 \
--name logstash-kafka \
--network sandbox \
-v /Users/nilanjan1.sarkar/Documents/BindMounts/logstash:/usr/share/logstash/config \
logstash:6.8.4 -f /usr/share/logstash/config/logstash-user-services-api.conf

## DB Checks

**MongoDB**

docker container exec -it mongo-standalone mongo
use test;
db.user.find()

**MySQL**

docker container exec -it mysql-standalone mysql -u root -pasd
use test;
select * from user;




