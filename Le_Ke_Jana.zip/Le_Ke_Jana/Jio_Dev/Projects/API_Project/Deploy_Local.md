
# Deploy JBDL API Platform locally

# Intial Setup

## Create namespaces
 
kubectl create namespace jbdl-api-core
kubectl create namespace jbdl-api-services

## Label nodes as

kubectl get nodes

kubectl label nodes <node_name> ingress-controller-node=true

Ex - kubectl label nodes docker-desktop ingress-controller-node=true

## Create service accounts 

kubectl create sa coe-rest-services -n jbdl-api-services

# Deploy Traefik

git clone https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/traefik-v2

**Create Service account**

kubectl create sa traefik-ingress-controller -n jbdl-api-core

BASEPATH=/Users/nilanjan1.sarkar/Documents/JBDL_Repos  ( where code has been checked out )
cd ${BASEPATH}/traefik-v2/

kubectl apply -k ${BASEPATH}/traefik-v2/overlays/dev

**Check**

kubectl rollout status daemonset/traefik -n jbdl-api-core

**HouseKeeping**

kubectl get po -n jbdl-api-core
kubectl logs <pod_name> -n jbdl-api-core -f
kubectl describe ds traefik -n jbdl-api-core -f

**Teardown**

kubectl delete -k ${BASEPATH}/traefik-v2/overlays/canary

# Deploy Application

## Create artefacts

git clone https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services/coe-rest-services-k8s

CONFIG_PATH=/Users/nilanjan1.sarkar/Documents/Jio_Env/JBDL_Canary
K8S_NAMESPACE=jbdl-api-services

kubectl create secret generic config-secret \
--from-file=${CONFIG_PATH}/hdfs-site.xml \
--from-file=${CONFIG_PATH}/core-site.xml \
--from-file=${CONFIG_PATH}/hive-site.xml \
--from-file=${CONFIG_PATH}/hive-config.properties \
-n ${K8S_NAMESPACE}

kubectl create configmap krb5-config \
--from-file=${CONFIG_PATH}/krb5.conf \
-n ${K8S_NAMESPACE}

kubectl create secret generic krb5-secret \
--from-file=${CONFIG_PATH}/dev_jbdl_hiverest.keytab \
-n ${K8S_NAMESPACE}

kubectl get all -n ${K8S_NAMESPACE}

## Create image

BASEPATH=/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Play_Apps

cd ${BASEPATH}

**Build jar**

sbt -J-Dsbt.repository.config="${HOME}/.sbt/.repositories" -Dsbt.override.build.repos=true clean assembly

**Build image**

sudo docker image rm coe-rest-services-k8s

sudo docker build -t coe-rest-services-k8s ${BASEPATH}/coe-rest-services

## Storage

**Create a storage class**

kubectl create -f local_storage_class.yaml

**Prepare local disk location**

mkdir -p /Users/nilanjan1.sarkar/Documents/Volumes/jbdl-api-services/coe-rest-services
chmod 777 /Users/nilanjan1.sarkar/Documents/Volumes/jbdl-api-services/coe-rest-services

**Create a persistent volume**

```
apiVersion: v1
kind: PersistentVolume
metadata:
  name: coe-rest-services-pv
spec:
  capacity:
    storage: 1Gi
  accessModes:
  - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: my-local-storage
  local:
    path: /Users/nilanjan1.sarkar/Documents/Volumes/jbdl-api-services/coe-rest-services
  nodeAffinity:
    required:
      nodeSelectorTerms:
      - matchExpressions:
        - key: kubernetes.io/hostname
          operator: In
          values:
          - docker-desktop 
```

kubectl create -f coe_rest_services_pv.yaml

kubectl get pv

kubectl delete -f coe_rest_services_pv.yaml

kubectl get pvc -n jbdl-api-services

kubectl delete pvc logs-storage-coe-rest-services-0 -n jbdl-api-services

## Deploy

**Deploy statefulset**

BASEPATH=/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Play_Apps

kubectl apply -k ${BASEPATH}/coe-rest-services/deploy/app/overlays/canary

kubectl rollout status statefulset/coe-rest-services-k8s -n jbdl-api-services

**Apply Ingress**

kubectl apply -f ${BASEPATH}/coe-rest-services/deploy/ingress/traefik_ingress_rule.yaml -n jbdl-api-services

**HouseKeeping**

kubectl get all -n jbdl-api-services -o wide

kubectl get po -n jbdl-api-services -o wide
kubectl get svc -n jbdl-api-services
kubectl describe svc hive-service -n jbdl-api-services

kubectl logs coe-rest-services-0 -n jbdl-api-services -f

kubectl describe po coe-rest-services-0 -n jbdl-api-services
kubectl describe statefulsets/coe-rest-services -n jbdl-api-services

kubectl get pvc -n jbdl-api-services

**Teardown**

kubectl delete -k ${BASEPATH}/coe-rest-services/deploy/app/overlays/canary

## Test

#### K8s

**Query**

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXlUYWIiOiIvYXBwL3Jlc3RhcGlfa2V5dGFicy9kZXZfamJkbF9oaXZlcmVzdC5rZXl0YWIifQo=" \
-H "Content-Type: application/json" \
-X POST -d '{"query":"select * from platform.dummy_data limit 10","maxRows":"25"}' \
http://localhost:30080/bdcoe/services/hive/query | jq '.'

**Stream**

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXlUYWIiOiIvYXBwL3Jlc3RhcGlfa2V5dGFicy9kZXZfamJkbF9oaXZlcmVzdC5rZXl0YWIifQo=" \
-H "Content-Type: application/json" \
-X POST -d '{"query":"select * from platform.dummy_data limit 10000","maxRows":"25"}' \
http://localhost:30080/bdcoe/services/hive/query/stream | jq '.'

#### Bare Metal

java -jar \
-Dplay.http.secret.key=ad31779d4ee49d5ad5162bf1429c32e2e9933f3b \
-Djava.security.krb5.conf=/etc/krb5.conf \
-Dbdcoe.ext.conf.file="/Users/nilanjan1.sarkar/Documents/Jio_Env/JBDL_Canary/hive-local-config.properties" \
target/coe-rest-services-assembly-1.0.0-SNAPSHOT.jar  | jq '.'

curl -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXlUYWIiOiIvYXBwL3Jlc3RhcGlfa2V5dGFicy9kZXZfamJkbF9oaXZlcmVzdC5rZXl0YWIifQo=" \
-H "Content-Type: application/json" \
-X POST -d '{"query":"select * from platform.dummy_data limit 10","maxRows":"25"}' \
http://localhost:9000/bdcoe/services/hive/query | jq '.'


## Check Final YAML

# Prometheus

PROM_PATH=${HOME}/Documents/JKaas_Repos/jbdl-api-core
PROM_PATH=${HOME}/Documents/JBDL_Repos

**Create Service account**

kubectl create sa prometheus -n jbdl-api-core

**Check**

kubectl kustomize ${PROM_PATH}/prometheus/overlays/canary

**Deploy**

kubectl apply -k ${PROM_PATH}/prometheus/overlays/canary

kubectl get po -n jbdl-api-core

kubectl describe deployment.apps/prometheus-deployment -n jbdl-api-core
kubectl describe replicaset.apps/prometheus-deployment-88b6d6f4f -n jbdl-api-core
kubectl describe pods prometheus-deployment-88b6d6f4f-vpcmt -n jbdl-api-core

kubectl logs prometheus-deployment-88b6d6f4f-phfpv -n jbdl-api-core


**Teardown**

kubectl delete -k ${PROM_PATH}/prometheus/overlays/canary
 
http://localhost:30000

Promethus
Node exporter
Kube state metrics

prom/prometheus:v2.5.0

# Node Exporter

**Check**

kubectl kustomize ${HOME}/Documents/JKaas_Repos/jbdl-api-core/node-exporter/overlays/canary

**Deploy**

kubectl apply -k ${HOME}/Documents/JKaas_Repos/jbdl-api-core/node-exporter/overlays/canary

# Kube State Metrics

**Create Service account**

kubectl create sa kube-state-metrics -n jbdl-api-core

**Check**

kubectl kustomize ${HOME}/Documents/JBDL_Repos/kube-state-metrics/overlays/canary

**Deploy**

kubectl apply -k ${HOME}/Documents/JBDL_Repos/kube-state-metrics/overlays/canary

**Verify**

kubectl get pod -n jbdl-api-core

```
kube-state-metrics-d657c8bf4-fkzt2       2/2     Running   0          79s
prometheus-deployment-7b8856b968-rwczn   1/1     Running   0          130m
traefik-vtjx2                            1/1     Running   0          39h
```

kubectl describe pod kube-state-metrics-644f99fd88-4hkmr -n jbdl-api-core

**Teardown**

kubectl delete -k ${HOME}/Documents/JBDL_Repos/kube-state-metrics/overlays/canary

# Grafana

**Check**

kubectl kustomize ${HOME}/Documents/JBDL_Repos/grafana/overlays/canary

**Deploy**

kubectl apply -k ${HOME}/Documents/JBDL_Repos/grafana/overlays/canary

kubectl get pod -n jbdl-api-core

```
grafana-569d598b59-qbmzq                 1/1     Running   0          38m
kube-state-metrics-d657c8bf4-fkzt2       2/2     Running   0          79s
prometheus-deployment-7b8856b968-rwczn   1/1     Running   0          130m
traefik-vtjx2                            1/1     Running   0          39h
```

kubectl delete -k ${HOME}/Documents/JBDL_Repos/grafana/overlays/canary

http://localhost:32000

