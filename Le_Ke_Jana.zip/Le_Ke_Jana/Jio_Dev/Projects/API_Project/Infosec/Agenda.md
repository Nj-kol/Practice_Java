
# Agenda

## What exists currently

Prem to present

## Release Notes

* Major features

* Feature for streaming
* Standardized response

* Metrics & Visialization
  - Global
  - Client Level metrics

* Authentication

Performance and stability

* Hive restart 

Other notable changes

* Nginx changes 
 * Rate limiting
 * IP Whitelisting

## Detailed presentation

Authentication
Metrics & Visialization







