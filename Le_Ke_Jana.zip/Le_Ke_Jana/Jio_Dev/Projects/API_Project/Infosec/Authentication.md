
# Authentication

## Current 

The current implementation of our API lacks any means of authentiction/authoriation at the API level. 
Currently, we only have validation at the service level ( i.e. kerberos ).

It is desirable to have a robust and modern token based authentication capability added to out API. 

Thus a stop-gap solution is proposed in the interim, which can help us in the interim.

***Current Request Structure***

```
{
   "query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 2",
   "maxRows":"25",
   "principal":"dev_jbdl_hiverest@RJIL.RIL.COM",
   "keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"
}
```

#### Shortcomings

* The drawback in the current solution is that we are exposing the path of the keytab ( on the server ) to the client

## Proposed 

* Split the request into two parts :

1. Request 

```
{
   "query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 2",
   "maxRows":"25"
}
```

2. A token 

* Structure of the token :

```
{
   "principal":"dev_jbdl_hiverest@RJIL.RIL.COM",
   "keytab":"/app/restapi_keytabs/dev_jbdl_hiverest.keytab"
}
```

* Encode the above token using base64 

echo  '{"principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/dev_jbdl_hiverest.keytab"}' | base64

echo 'eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvYXBwL3Jlc3RhcGlfa2V5dGFicy9kZXZfamJkbF9oaXZlcmVzdC5rZXl0YWIifQo=' | base64 --decode

After encoding :

eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvaG9tZS9jbG91ZC11c2VyL2tlcmJlcm9zX2ZpbGVzL2Rldl9qYmRsX2hpdmVyZXN0LmtleXRhYiJ9

* To onboard a new client, a one time manual work has be be done to create a token using base64 encoding

* This token would be shared with particular client

* The client will then make subsequent requests with this token like :

```
curl -i -H "X-Requested-With: Basic eyJwcmluY2lwYWwiOiJkZXZfamJkbF9oaXZlcmVzdEBSSklMLlJJTC5DT00iLCJrZXl0YWIiOiIvaG9tZS9jbG91ZC11c2VyL2tlcmJlcm9zX2ZpbGVzL2Rldl9qYmRsX2hpdmVyZXN0LmtleXRhYiJ9" \
-H "Accept: application/json"  
-H "Content-Type: application/json" \
-X POST -d '{"query":"select cell_area,userplane_upload_throughput_bucket_3_count from network.probes_userplane_20191007 limit 2","maxRows":"25"}' \
http://localhost:9000/bdcoe/services/hive/query
```
#### Benefits

* The client does not have to give any KRB5 credentials, thus making it transparent at client level, 
  what algo we use for authentication on Hive ( or any service ) level

* We are not sending the location of the keytab on the server

* Because we are using HTTPS, the headers are also encrypted which means the token would be encrypted

# Roadmap

* In the future, the basic authentication could be replaced with JWT by simply changing the header :

 -H "X-Requested-With: Basic <some_token>"

 to

 -H "X-Requested-With: Bearer <jwt_token>" ( or anything else )

The protocol of token based authentication would be transparent to the client and could be implemented in any manner on the server

* JWT (JSON Web Tokens) could be a good candidate helping us achieving the same. However, it is a tad complicated to 
  implement correctly

* Given the cuurent timeline, it may be prudent to hold off on it until we have proper resources 
  ( time, people, machines ) to do so

