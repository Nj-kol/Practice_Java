
#bkup

/**
   * Convert a list of columns in a comma separated string to a byte Array
   *
   * @author Nilanjan Sarkar
   */
  private class JSONToByteArrayConverter(metaData: ResultSetMetaData) extends RowToByteArrayConverter {

    implicit val formats = DefaultFormats

    val numColumns = metaData.getColumnCount
    val columnValues = new Array[DBColumn](numColumns)

    override def rowToByteArray(rs: ResultSet): Array[Byte] = {

      for (i <- 1 to metaData.getColumnCount) {
        val colType = metaData.getColumnType(i)
        val colTypeName = metaData.getColumnTypeName(i)
        val colName = metaData.getColumnName(i)
        val objVal = rs.getString(i)
        val typedVal: String = colType match {
          case _ if objVal == null || StringUtils.isBlank(objVal) => StringUtils.EMPTY
          case _ => StringEscapeUtils.escapeCsv(objVal)
        }
        columnValues(i - 1) = DBColumn(colName, colTypeName, typedVal)
      }
      val row = DBRow(columnValues)
      val jsonString = write(row)
      jsonString.getBytes
    }
  }

  



case class Data(data: Seq[Map[String,String]])

// Proposed
case class Error(errorReason: String)
case class Metadata(somthing: String)
case class Response(data: Option[Seq[Map[String,String]]],error: Option[Error],meta: Option[Metadata])

```
object JSONResponseBodyWriter extends ResponseBodyWriter {

  private val logger = LoggerFactory.getLogger(getClass)

  override def modelResponse(rs: ResultSet, maxRowCount: Int): String = {

    import scala.collection.mutable.ListBuffer

    val metaData = rs.getMetaData
    val numColumns: Int = metaData.getColumnCount
    val columnNames = new Array[String](numColumns)

    for (i <- 1 to metaData.getColumnCount) columnNames(i - 1) = metaData.getColumnName(i)

    val cols = new ListBuffer[DBColumn]()
    val rows = new ListBuffer[DBRow]()

    val records = new ListBuffer[Map[String, String]]()
    
    var counter: Int = 0
    breakable {
      while (rs.next) {

        val data = scala.collection.mutable.Map[String, String]()
        val columnValues = new Array[String](numColumns)
        for (i <- 1 to metaData.getColumnCount) {
          val colType = metaData.getColumnType(i)
          val colTypeName = metaData.getColumnTypeName(i)
          val colName = metaData.getColumnName(i)
          val objVal = rs.getString(i)
          val typedVal: String = colType match {
            case _ if objVal == null || StringUtils.isBlank(objVal) => StringUtils.EMPTY
            case _ => StringEscapeUtils.escapeCsv(objVal)
          }
          cols += DBColumn(colName, colTypeName, typedVal)
          
          if(colName.contains(".")) {
           val actualColNm = colName.split("\\.")(1)
           logger.info(s"The actual colname is : $actualColNm")
           data += (actualColNm -> typedVal)
          }else{
            data += (colName -> typedVal)
          }
        }
       // rows += DBRow(cols)
        records  += data.toMap
        counter = counter + 1
        if (counter > maxRowCount) break
      }
    }

    implicit val formats = DefaultFormats

    //val table = DBTable(rows)
    //val table = Data(records.toSeq)
    val table = Response(Some(records.toSeq),None,None)
    val jsonString = write(table)
    jsonString
  }
}
```

https://jsonapi.org/format/

## Correct

curl -v -k -H "Accept: application/json"  -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_msisdn,cell_subdivision_name,userequipment_model_name,device_current_ip_address from network.probes_userplane_20191007 limit 2","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30090/bdcoe/services/hive/query


{
   "data":[
      {
         "cell_subdivision_name":"I-MU-MUMB-ENB-A227",
         "userequipment_model_name":"M1903C3EI",
         "subscriber_msisdn":"-742713104",
         "device_current_ip_address":"2405:200:1901:a181:51:0:0:99"
      },
      {
         "cell_subdivision_name":"I-MU-MUMB-ENB-A232",
         "userequipment_model_name":"Redmi NOTE4",
         "subscriber_msisdn":"-1134858341",
         "device_current_ip_address":"2405:200:1901:a181:51:0:0:11"
      }
   ],
   "meta":{
      "somthing":"Number of records consumed : 2"
   }
}

## Error

curl -v -k -H "Accept: application/json"  -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_msisdn,cell_subdivision_name,userequipment_model_name,device_current_ip_address from network.probes_userplan_20191007 limit 2","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/home/cloud-user/kerberos_files/dev_jbdl_hiverest.keytab"}' http://10.157.88.193:30090/bdcoe/services/hive/query

{
   "Error while fetching data, Please verify keytab, principal and query are correct if yes then contact the operations team":"Unexpected exception[HiveSQLException: Error while compiling statement: FAILED: SemanticException [Error 10001]: Line 1:103 Table not found 'probes_userplan_20191007']"
}


