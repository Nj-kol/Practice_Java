
# Deploy Traefik

## Tag & Push image to registry

sudo docker image tag traefik:2.1 10.141.51.157:5700/traefik:2.1 
sudo docker push 10.141.51.157:5700/traefik:2.1

Tag format : sudo docker image tag SOURCE_IMAGE[:TAG] TARGET_IMAGE[:TAG]

## Repository

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/traefik-v2

## Deploy

kubectl create sa traefik-ingress-controller -n jbdl-api-core

kubectl label nodes <node_name> ingress-controller-node=true

Ex - kubectl label nodes bdpprdmasternode19.jio.com bdpprdmasternode32.jio.com ingress-controller-node=true

git clone https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/traefik-v2

BASEPATH=<location_of_git_clone>
kubectl apply -k ${BASEPATH}/traefik-v2/overlays/prod 

## Housekeeping

kubectl get all -n jbdl-api-core

kubectl get po -n jbdl-api-core -o wide
kubectl get deploy -n jbdl-api-core -o wide
kubectl rollout status daemonset/traefik -n jbdl-api-core

## Teardown

kubectl delete -k ${BASEPATH}/traefik-v2/overlays/dev

**Apply Ingress for Traefik UI**

kubectl apply -f ${BASEPATH}/traefik-v2/overlays/dev/traefik_crd_ui.yaml

