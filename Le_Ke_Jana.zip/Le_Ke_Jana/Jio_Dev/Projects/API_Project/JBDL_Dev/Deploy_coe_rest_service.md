
# Deploy coe-rest-services-k8s application

**Create namespace**

kubectl create namespace jbdl-api-services

**Create service account**

kubectl create sa coe-rest-services -n jbdl-api-services

## Create Application artifacts

* This is a once time activity that needs to be done at the time of deployment.
* This is not going to be part of the CI/CD pipeline
* Only if the configuration is changed, these artifacts needs to be re-deployed

* The following files would be environment specific :
  * hdfs-site.xml
  * core-site.xml
  * hive-site.xml
  * hive-config.properties 
  * krb5.conf
  * dev_jbdl_hiverest.keytab 

All the above files needs to be made available for proceeding with the steps below 

mkdir -p <some_path>/coe-rest-services-k8s 
mkdir -p <some_path>/coe-rest-services-k8s/config
mkdir -p <some_path>/coe-rest-services-k8s/krb

export ARTIFACTS_PATH=<some_path>/coe-rest-services-k8s 
export CONFIG_PATH=${ARTIFACTS_PATH}/config
export KRB_PATH=${ARTIFACTS_PATH}/krb               
export K8S_NAMESPACE=jbdl-api-services

**Place all the files in their respective locations**

cp hdfs-site.xml core-site.xml hive-site.xml hive-config.properties ${CONFIG_PATH}
cp krb5.conf dev_jbdl_hiverest.keytab ${KRB_PATH}

**Create configuration secrets**

kubectl create secret generic config-secret \
--from-file=${CONFIG_PATH}/hdfs-site.xml \
--from-file=${CONFIG_PATH}/core-site.xml \
--from-file=${CONFIG_PATH}/hive-site.xml \
--from-file=${CONFIG_PATH}/hive-config.properties \
-n ${K8S_NAMESPACE}

**Create Kerberos configmap**

kubectl create configmap krb5-config \
--from-file=${CONFIG_PATH}/krb5.conf \
-n ${K8S_NAMESPACE}

**Create keytab secrets**

kubectl create secret generic krb5-secret \
--from-file=${KRB_PATH}/dev_jbdl_hiverest.keytab \
-n ${K8S_NAMESPACE}

## Deploy the actual application 

git clone https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services/coe-rest-services-k8s

export ENV=prod
export BASE_PATH=/home/cloud-user/JKaaS_Repos/coe-rest-services-k8s  

kubectl apply -k ${BASE_PATH}/deploy/app/overlays/${ENV}

#### Apply the ingress Rule

kubectl apply -f ${BASE_PATH}/deploy/ingress/traefik_ingress_rule.yaml -n ${K8S_NAMESPACE} 

Notes
======
* There is no need to create persistent volume claims since we are using statefulsets
* Persistent volumes needs to be created which will be equal to the number of instances.

  For example, if we would be deploying 2 instances of coe-rest-services-k8s then we need to 
  create two persistent volumes. Otherwise all instances will bind to the same PV which
  is not desirable

* The following things needs to be specfied correctly (in custom-statefulset.yaml ) 
  for volume binding to happen correctly :

  * accessModes         ( Must be ReadWriteOnce )
  * storageClassName
  * storage

  *The value of the storage must be the same as the size of the PV requested*

  Example of the spec section of volumeClaimTemplates :

```
spec:
  volumeClaimTemplates:
  - metadata:
      name: logs-storage
    spec:
      accessModes: [ "ReadWriteOnce" ]
      storageClassName: local-storage
      resources:
        requests:
          storage: 20Gi
```

## TODO

* Need to know the storage class name for prod ( in dev it is local-storage )
* Need to know the number of instances of coe-rest-services to be deployed in production
* Need to know the hive/zookeeper server IPs for production
* Need to get the following files for prod :
  * hdfs-site.xml
  * core-site.xml
  * hive-site.xml
  * hive-config.properties 
  * krb5.conf
  * dev_jbdl_hiverest.keytab 

* Need to check the pipeline status for the repo :
