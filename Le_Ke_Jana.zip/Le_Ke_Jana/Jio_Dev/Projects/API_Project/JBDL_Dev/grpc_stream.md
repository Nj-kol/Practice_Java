
# gRPC Streaming

## Traefik

**Traefik nodes**

bdpprdmasternode19.jio.com
bdpprdmasternode32.jio.com

**See logs**

**Ingress Rule**

```
apiVersion: traefik.containo.us/v1alpha1
kind: IngressRoute
metadata:
  name: hivegrpc-ingressroute
  namespace: jbdl-api-services
spec:
  entryPoints:
    - web
  routes:
  - match: PathPrefix(`/user.UserService`)
    kind: Rule
    services:
    - name: jbdl-hive-grpc-server
      port: 30061
      scheme: h2c
```

# Application

## Build and push image to Nexus

scp -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem  \
-r /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/grpc-demos/jbdl-hive-grpc-server/target/jbdl-hive-grpc-server-0.0.1-SNAPSHOT.jar \
cloud-user@10.157.88.193:/home/cloud-user/

ssh -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem cloud-user@10.157.88.193

BASE_PATH=/home/cloud-user/JKaas_Repos/jbdl-hive-grpc-server

sudo mv jbdl-hive-grpc-server-0.0.1-SNAPSHOT.jar ${BASE_PATH}/target

sudo docker build -t 10.141.51.157:5700/jbdl-hive-grpc-server ${BASE_PATH}
sudo docker push 10.141.51.157:5700/jbdl-hive-grpc-server

## Deploy

**Point kubectl to JBDL Dev cluster**

export KUBECONFIG="/home/cloud-user/k8s/conf/jbdl_dev/jbdl-api-core/config"

kubectl config get-contexts

APP_PATH=/home/cloud-user/JKaaS_Repos/jbdl-hive-grpc-server
kubectl apply -f ${APP_PATH}/external_endpoints.yaml -n jbdl-api-services
kubectl apply -f ${APP_PATH}/deploy.yaml -n jbdl-api-services
kubectl apply -f ${APP_PATH}/service.yaml -n jbdl-api-services
kubectl apply -f ${APP_PATH}/traefik-grpc.yaml -n jbdl-api-services

## Debug & Housekeeping

kubectl get po -n jbdl-api-services -o wide
kubectl get services -n jbdl-api-services 
kubectl get sa -n jbdl-api-services
kubectl get deploy -n jbdl-api-services

kubectl logs jbdl-hive-grpc-server-5f4b88b4f4-5thk7 -n jbdl-api-services -f

kubectl describe pod jbdl-hive-grpc-server-5f4b88b4f4-8zs8z -n jbdl-api-services
kubectl describe service jbdl-hive-grpc-server -n jbdl-api-services

## Teardown

kubectl delete -f ${APP_PATH}/deploy.yaml -n jbdl-api-services
kubectl delete -f ${APP_PATH}/service.yaml -n jbdl-api-services

# Client

scp -i /Users/nilanjan1.sarkar/Documents/K8s/analytics-jkaas.pem  \
/Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/grpc-demos/jbdl-hive-grpc-client/target/jbdl-hive-grpc-client-0.0.1-SNAPSHOT.jar \
cloud-user@10.157.88.204:/home/cloud-user/

java -jar jbdl-hive-grpc-client-0.0.1-SNAPSHOT.jar "SELECT subscriber_id,subscriber_gender,subscriber_age FROM network.probes_userplane_20191007 LIMIT 1000000"

${HOME}/softwares/evans --host bdpprdmasternode19.jio.com -p 30080 --reflection true


## JBDL git Repos

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services/jbdl-hive-grpc-client
https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services/jbdl-hive-grpc-server

Main page

http://10.141.165.155:8080/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/JBDL%20API%20Platform/Large%20Scale%20Data%20Transfer%20Using%20gRPC/

NGINX

http://10.141.165.155:8080/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/JBDL%20API%20Platform/Large%20Scale%20Data%20Transfer%20Using%20gRPC/Configure%20NGINX%20as%20Reverse%20Proxy%20for%20gRPC%20Servers/

Traefik

http://10.141.165.155:8080/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/JBDL%20API%20Platform/Large%20Scale%20Data%20Transfer%20Using%20gRPC/Configure%20Traefik%20as%20Reverse%20Proxy%20for%20gRPC%20Servers/

POC
http://10.141.165.155:8080/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/JBDL%20API%20Platform/Proof%20of%20Concepts/gRPC%20Server%20side%20push/


 The hypothetical ideal option is an Indian low-cost feeder fund that invests in the Vanguard US S&P 500 ETF, or the equivalent index fund.

 * I will be done by the RR today or tommorow
 * Whom to contact to review for the RR
 * I need some clarity on the ARB provides


