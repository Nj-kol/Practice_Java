
# Deploy

As of now, I have the following requirements :
 
Namespaces to be created :
 
kubectl create namespace jbdl-api-core
kubectl create namespace jbdl-api-services

Label nodes as :
 
ingress-controller-node=true

kubectl label nodes <node_name> ingress-controller-node=true

Ex - kubectl label nodes jmngd1bad110v01 ingress-controller-node=true

kubectl label nodes docker-desktop ingress-controller-node=true

## Repos 

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Core/traefik-v2.git
https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_API_Platform/Services/coe-rest-services-k8s.git

# New JBDL node

## Check Node Connectivity 

telnet bdpprdmasternode19.jio.com 30080
telnet bdpprdmasternode32.jio.com 30080

## Point kubectl to JBDL Dev cluster

export KUBECONFIG="/home/cloud-user/k8s/conf/jbdl_dev/jbdl-api-core/config"

kubectl config get-contexts

kubectl get nodes

## Check artifacts

kubectl get all -n jbdl-api-core
kubectl get po -n jbdl-api-core
kubectl get svc -n jbdl-api-core

kubectl get all -n jbdl-api-services
kubectl get statefulsets -n jbdl-api-services
kubectl get po -n jbdl-api-services
kubectl get svc -n jbdl-api-services
kubectl get pvc -n jbdl-api-services

kubectl get storageclass
kubectl get pv

kubectl describe pod coe-rest-services-0 -n jbdl-api-services
kubectl describe pvc local-pvc-claim -n jbdl-api-services
kubectl describe pvc logs-storage-coe-rest-services-0 -n jbdl-api-services

kubectl describe pv local-pv

## Housekeeping

**See logs**

stern traefik -n jbdl-api-core --tail 5
kubectl logs traefik-2s4f6 -n jbdl-api-core -f
kubectl logs traefik-mk7ch -n jbdl-api-core -f

stern coe-rest-services -n jbdl-api-services --tail 5
kubectl logs coe-rest-services-0 -n jbdl-api-services -f

## Teardown

kubectl delete -k ${BASEPATH}/traefik-v2/overlays/dev
kubectl delete -k ${BASEPATH}/traefik-v2/overlays/dev

kubectl delete pvc logs-storage-coe-rest-services-0 -n jbdl-api-services
kubectl delete -k ${BASE_PATH}/deploy/app/overlays/${ENV}

## Test 

**Test dummy app**

curl http://bdpprdmasternode32.jio.com:30080/jbdl/dummy/message

**Node 1**

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/krb5-keytab-volume/dev_jbdl_hiverest.keytab"}' http://bdpprdmasternode32.jio.com:30080/bdcoe/services/hive/query

**Node 2**

curl -k -H "Content-Type: application/json" -X POST -d '{"query":"select subscriber_id,subscriber_gender,subscriber_age from network.probes_userplane_20191007 limit 25","maxRows":"25","principal":"dev_jbdl_hiverest@RJIL.RIL.COM","keytab":"/app/restapi_keytabs/krb5-keytab-volume/dev_jbdl_hiverest.keytab"}' http://bdpprdmasternode19.jio.com:30080/bdcoe/services/hive/query

## Create service accounts 

kubectl create sa traefik-ingress-controller -n jbdl-api-core
kubectl create sa coe-rest-services -n jbdl-api-services

kubectl get sa -n jbdl-api-core
kubectl get sa -n jbdl-api-services

kubectl describe sa traefik-ingress-controller -n jbdl-api-core
kubectl describe sa coe-rest-services -n jbdl-api-services

kubectl get clusterrole 
kubectl get clusterrolebinding -n jbdl-api-services

kubectl describe clusterrole traefik-ingress-controller -n jbdl-api-core
kubectl describe clusterrolebinding traefik-ingress-controller -n jbdl-api-core

kubectl create clusterrolebinding traefik-ingress-controller --clusterrole cluster-admin --serviceaccount=jbdl-api-core:traefik-ingress-controller

kubectl get roles -n jbdl-api-services
kubectl describe role api-role -n jbdl-api-services

kubectl get rolebinding -n jbdl-api-services
kubectl describe rolebinding api-role-binding -n jbdl-api-services

kubectl get roles -n jbdl-api-services -o yaml --export > api-role-binding.yaml
kubectl get rolebinding api-role-binding -n jbdl-api-service -o yaml --export > api-role-binding.yaml

kubectl get roles -n jbdl-api-services

kubectl describe role api-role -n jbdl-api-services
kubectl describe rolebinding api-role-binding -n jbdl-api-services
