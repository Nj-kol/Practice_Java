
# DS Scratchpad

## Data Quality Management process

* Data Profiling
	- Discover
	- Profile
	- Assess
	- Understand

* Data Cleansing
- 

## Data Profiling

**Simple Statistics**

* Look out for no. of NULL/Blank values
* Check primary key has distinct values only
* Check list of possible values for a particular field

**Pattern**

* Check all values in a field are in a pre-determined format

**Threshold**

* Define business rules, set threshold and check anomalies

**Functional Dependencies**

* Check relation between attrubutes
   Ex - zip code and city must be in line

## Data Quality dimensions

* Completeness
  - What is missing or unsuable

  Ex - Age is missing

* Validity/Conformity
  - Is the stored valid?

  Ex - Age is negetive

* Integrity

  Ex - Same city stored with different zipcode

* Consistency
  - What data values give conflicting information

* Accuracy
  - What data is incorrect or out of date

* Duplicates

## Data Sanity

* Incomplete data ingestion
  - Missing Records
  - Duplicates

* primary key + update timestamp col


Creating hive table over snapshots

hdfs snapshot for read time consistency

References
==========
https://www.youtube.com/watch?v=sozxWzAXLBM&t=73s

