
# Data Quality

aishwarya.d@ril.com
9082618388

val path ="/Users/nilanjan1.sarkar/Downloads/oracle_config.json"
val lines = scala.io.Source.fromFile(path).mkString

case class JDBCParamSet(jdbcUrl: String, driverClass: String, jdbcUsername: String, jdbcPassword: String,
  dbName: String, tableName: String, dateFilter: Option[String]) 

import org.json4s._
import org.json4s.jackson.JsonMethods._
implicit val formats = DefaultFormats

val jdbcAst = parse(lines)
val jdbcParam = jdbcAst.extract[JDBCParamSet]

## Json config

**RDBMS**

*Oracle*

{
   "jdbcUrl" : "jdbc:oracle:thin:@10.137.81.197:1521/XCOMPRD_STB",
   "driverClass" : "oracle.jdbc.driver.OracleDriver",
   "jdbcUsername" : "isocgranite",
   "jdbcPassword": "Qwcbd4#g",
   "dbName": "RJILCUSTOMISATIONS",
   "tableName": "FETCH_CONTAINER_DETAILS"
}

{"jdbcUrl":"jdbc:oracle:thin:@10.137.81.197:1521/XCOMPRD_STB","driverClass":"oracle.jdbc.driver.OracleDriver","jdbcUsername":"isocgranite","jdbcPassword":"Qwcbd4#g","dbName":"RJILCUSTOMISATIONS","tableName":"FETCH_CONTAINER_DETAILS"}

*MySql*

{
   "jdbcUrl": "jdbc:mysql://localhost:3306/test",
   "driverClass": "com.mysql.jdbc.Driver",
   "jdbcUsername":"root",
   "jdbcPassword":"asd",
   "dbName":"test",
   "tableName":"product_sales"
}

{"jdbcUrl":"jdbc:mysql://localhost:3306/test","driverClass":"com.mysql.jdbc.Driver","jdbcUsername":"root","jdbcPassword":"asd","dbName":"test","tableName":"product_sales"}

## Hive Config

{
   "dbName"   : "network",
   "tableName": "GRANITE_FETCH_CONTAINER_DETAILS_PO",
   "dateFilter"   : "partition_date='2019-11-17'"
}

{"hiveDbName":"network","hiveTableName":"GRANITE_FETCH_CONTAINER_DETAILS_PO","dateFilter":"partition_date='2019-11-17'"}

## Source

sudo hostname -s 127.0.0.1
sudo spark-shell --conf spark.ui.port=4041 --jars /opt/jars/mysql-connector-java-5.0.8.jar

```
val jdbcHostname = "localhost"
val jdbcPort = 3306
val jdbcDatabase ="test"
val jdbcTable = "product_sales"
val jdbcUsername = "root"
val jdbcPassword = "asd"
val driverClass = "com.mysql.jdbc.Driver"

// Create the JDBC URL without passing in the user and password parameters.
val jdbcUrl = s"jdbc:mysql://${jdbcHostname}:${jdbcPort}/${jdbcDatabase}"

val partitionColumn = "date"
val lowerBound = "2012-03-02"
val upperBound = "2012-04-29"
val numPartitions = 4

val countQuery = "select count(1) as num_records from product_sales "
val countDf = spark.read.format("jdbc")
      .option("url", jdbcUrl)
      .option("driver", driverClass)
      .option("user", jdbcUsername)
      .option("password", jdbcPassword)
      .option("query",countQuery)
      .load().collect

val sourceDf = spark.read
  .format("jdbc")
  .option("url", jdbcUrl)
  .option("driver", driverClass)
  .option("dbtable", jdbcTable)
  .option("user", jdbcUsername)
  .option("password",jdbcPassword)
  .option("pushDownPredicate","true")
  .option("partitionColumn",partitionColumn)
  .option("lowerBound",lowerBound)
  .option("upperBound",upperBound)
  .option("numPartitions",numPartitions)
  .load().where("date='2012-03-02'")

val missingDataDf = sourceDf.where("productsize!=16.0")
val dupDataDf =sourceDf.unionAll(sourceDf.where("productsize=16.0"))
dupDataDf.createOrReplaceTempView("dupes")

val temp = sourceDf.withColumn("user_id",$"user_id"+1)
val destDf = sourceDf.unionAll(temp)

//destDf.show
destDf.createOrReplaceTempView("users_dest")


val destDb = ""
val destTable = ""
val destCount = spark.sql("select count(1) from ${destDb}.${destTable}")

//userDf.printSchema
userDf.createOrReplaceTempView("users")

```

```
val sourceCols = userDf.schema.fields.map(_.name)
val selectiveDifferences = sourceCols.map(col => userDf.select(col).except(destDf.select(col)))

val userSample = user.sample(false,0.20)
val userSchema = user.schema
```

# Sanity

## Count Diff

**Get source count**

```
case class JDBCParamSet(jdbcUrl: String,driverClass: String,jdbcUsername: String,jdbcPassword: String,
dbName: String,tableName: String,dateFilter: Option[String])

/**
 * Gets source data count
*/
def getSourceDataCountRDBMS(param: JDBCParamSet): Long = {

  var countQuery = ""

  val dbName = param.dbName
  val tableName = param.tableName
  val dateFilter = param.dateFilter

  dateFilter match {
    case Some(clause) => countQuery = s"SELECT count(1) as num_records FROM ${dbName}.${tableName} WHERE ${clause}"
    case None         => countQuery = s"SELECT count(1) as num_records FROM ${dbName}.${tableName}"
  } 

  val countDf = spark.read
    .format("jdbc")
    .option("url", param.jdbcUrl)
    .option("driver", param.driverClass)
    .option("user", param.jdbcUsername)
    .option("password",param.jdbcPassword)
    .option("pushDownPredicate","true")
    .option("query",countQuery)
    .load().collect
    
    countDf(0).getLong(0)
}

val jdbcHostname = "localhost"
val jdbcPort = 3306
val jdbcDatabase ="test"
val jdbcTable = "product_sales"
val jdbcUsername = "root"
val jdbcPassword = "asd"
val driverClass = "com.mysql.jdbc.Driver"
val ingestDate = "2012-03-02"
val dateFilter = Some(s"date='${ingestDate}'")

// Create the JDBC URL without passing in the user and password parameters.
val jdbcUrl = s"jdbc:mysql://${jdbcHostname}:${jdbcPort}/${jdbcDatabase}"

val param = JDBCParamSet(jdbcUrl,driverClass,jdbcUsername,jdbcPassword,jdbcDatabase,jdbcTable,dateFilter)
val srcCount= getSourceDataCountRDBMS(param)
```

**Get destination count**

```
case class HiveParamSet(dbName: String,tableName: String,dateFilter: Option[String])

/**
 * Gets dest data count
*/
def getDestDataCountHive(param: HiveParamSet): Long = {

  val dbName = param.dbName
  val tableName = param.tableName
  val dateFilter = param.dateFilter
  var countQuery = ""

  dateFilter match {
    case Some(clause) => countQuery = s"SELECT count(1) as num_records FROM ${dbName}.${tableName} WHERE ${clause}"
    case None         => countQuery = s"SELECT count(1) as num_records FROM ${dbName}.${tableName}"
  }

  val countDf = spark.sql(countQuery).collect
  countDf(0).getLong(0)
}

val hiveDbName = ""
val hiveTableName = ""
val ingestDate = "2012-03-02"
val dateFilter = Some(s"date='${ingestDate}'")
val param = HiveParamSet(hiveDbName,hiveTableName,dateFilter)
val destCount= getDestDataCountHive(param)
```

## Missing Record count

```
import org.apache.spark.sql.DataFrame

def findMissingRecordCount(sourceDf: DataFrame, destDf: DataFrame) : Long = {
  sourceDf.except(destDf).count
}
```

## Duplicate Check

```
def findDuplicateRecordCount(tableName: String, keycols: Seq[String], dateFilter: Option[String]): Long = {
  val keyColLst = keycols.mkString(",")
  var dateClause = " "
  dateFilter match {
    case Some(clause) => dateClause = s" WHERE ${clause} "
    case None =>
  }
  val dupQuery =
    s"""SELECT COUNT(*) as num_dupes 
  FROM (
    SELECT ${keyColLst}
    FROM  ${tableName}
    ${dateClause}
    GROUP BY ${keyColLst} 
    HAVING COUNT(*) > 1) temp"""
   val temp = spark.sql(dupQuery).collect
   temp(0).getLong(0)
}

import org.apache.spark.sql.DataFrame

def fetchDuplicateRecord(tableName: String, keycols: Seq[String], dateFilter: Option[String]): DataFrame = {
  val keyColLst = keycols.mkString(",")
  var dateClause = " "
  dateFilter match {
    case Some(clause) => dateClause = s" WHERE ${clause} "
    case None =>
  }
  val dupQuery =
    s"""
    SELECT ${keyColLst}
    FROM  ${tableName}
    ${dateClause}
    GROUP BY ${keyColLst} 
    HAVING COUNT(*) > 1"""

  spark.sql(dupQuery)
}
```

**Test dupes**

```
sourceDf.createOrReplaceTempView("nondupes")
val keycols = Seq("id","chain","dept", "category","company","brand")

// No date filter ( works )
findDuplicateRecordCount("dupes",keycols,None)

// With date filter ( works )
findDuplicateRecordCount("dupes",keycols,Some("date='2012-03-02'"))

val keycols = Seq("id","chain","dept", "category","company","brand","date","productsize")
// no dupes
findDuplicateRecordCount("nondupes",keycols,None)
```

*View duplicates*
fetchDuplicateRecord("nondupes",keycols,None)

SELECT * FROM product_sales 
WHERE id=86246 AND chain=205 AND dept=19 
AND category=1905 AND company=105150050 
AND brand=16728 AND date='2012-03-02'
AND productsize=32;

## Sanity

```
def doSanity() : String = {

  var report = ""
  val srcCount = getSourceDataCountRDBMS(param)
  val destCount = getDestDataCountHive(param)
  if(srcCount > destCount) {
   val missRecCount = (srcCount - destCount)
   report = s"There are ${missRecCount} Missing Records"
  }else if (srcCount < destCount) {
   val dupRedCount = (destCount - srcCount)
   report = s"${dupRedCount} duplicates found!"
  }else {
   report = "Records matched!"
  }
  report
}

val ingestDate = "2012-03-02"
val dfFilter = s"date='${ingestDate}'"
val cols = Array("id","chain","dept", "category","company","brand")
doSanity(cols,dfFilter,dfFilter)
```

**Ad-hoc**

```
val tableName ="dest"
val ingestDate = "2012-03-02"
val dfFilter = s"date='${ingestDate}'"
val keycols = Array("id","chain","dept", "category","company","brand")
val keyColLst = keycols.mkString(",")
val dupQuery = s"""SELECT COUNT(*) as num_dupes 
FROM (
SELECT ${keyColLst}
FROM  ${tableName}
WHERE ${dateFilter}
GROUP BY ${keyColLst} 
HAVING COUNT(*) > 1) 
temp"""
spark.sql(dupQuery).count
```

## Quality checks 

**Text**

```
spark.sql("SELECT count(*) as count FROM users_temp WHERE length(trim(fisrt_name)) = 0 OR fisrt_name IS NULL").show

```


Spark dataframe libraries
=========================
https://github.com/FRosner/drunken-data-quality/wiki/Drunken-Data-Quality-4.1.1
https://github.com/awslabs/deequ
https://spark.apache.org/docs/latest/sql-data-sources-jdbc.html

https://github.com/agile-lab-dev/DataQuality

# Data Profiling

* Numeric
  - 
* Non numeric 
  - histograms

https://databricks.com/session/scalable-and-incremental-data-profiling-with-spark
