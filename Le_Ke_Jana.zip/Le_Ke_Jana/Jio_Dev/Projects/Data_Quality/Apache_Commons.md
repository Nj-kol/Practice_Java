
# Apache Commons Validator


## Other Validators


Regular Expressions - validates using Java 1.4+ regular expression support
Check Digit - validates/calculates check digits (i.e. EAN/UPC, credit card, ISBN).
Code Validation - provides generic code validation - format, minimum/maximum length and check digit.
ISBN Validation - provides ISBN-10 and ISBN-13 validation.

## IP Address Validation 

* provides IPv4 address validation.

## Email Address Validation

* provides email address validation according to RFC 822 standards.

## URL Validation 

* provides URL validation on scheme, domain, and authority.

## Domain Name Validation - provides domain name and IANA TLD validation.

References
===========
https://commons.apache.org/proper/commons-validator/apidocs/org/apache/commons/validator/routines/package-summary.html