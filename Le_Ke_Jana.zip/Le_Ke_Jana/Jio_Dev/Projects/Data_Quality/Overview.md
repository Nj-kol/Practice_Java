
https://wiki.jio.com/xwiki/bin/view/Jio%20Big%20Data%20Lake%20%28JBDL%29%20Home/Data%20Engineering/Data%20Quality%20Platform/?srid=lBz73THl