
# Runbook

**jar location**

/home/dev_network_granite/test

**Submit Spark job**

--/usr/hdp/current/spark2-client/bin/spark-submit \
--class com.jio.bdcoe.validation.demo.FetchContainerDetailsJob \
--name FetchContainerDetailsJob \
--master yarn \
--deploy-mode client \
--driver-memory 4g \
--executor-memory 5g \
--num-executors 2 \
--executor-cores 3 \
--files /app/app_keytabs/dev_network_granite.keytab,/usr/hdp/current/spark2-client/conf/hive-site.xml \
--conf 'spark.hadoop.mapreduce.fileoutputcommitter.marksuccessfuljobs=false' \
--conf 'spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2' \
--conf spark.ui.port=5777 \
--queue network-jobs \
/home/dev_network_granite/test/jbdl-data-validator.jar

**Credentials**

P@ssw0rd#@!
ssh dev_network_granite@10.143.165.75
10.143.165.75 jbdl gateway dev