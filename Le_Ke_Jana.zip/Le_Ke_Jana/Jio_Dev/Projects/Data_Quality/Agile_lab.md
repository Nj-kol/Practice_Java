
#Checks


References
==========
https://github.com/agile-lab-dev/DataQuality/tree/master/docs


javap -c /Users/nilanjan1.sarkar/Documents/Eclipse_Workspaces/Jio_Spark/jbdl-data-validator/target/classes/com/jio/bdcoe/validation/demo/FetchContainerDetailsJob$delayedInit$body.class


## Range checks

between(Object lowerBound, Object upperBound)
isin(Object... list)

## String

contains(Object other)
like(String literal)
rlike(String literal)
startsWith(Column other)
startsWith(String literal)
endsWith(Column other)
endsWith(String literal)

## Null Checks

isNotNull()
isNull()

## Equality Checks

* Inequality test.

  notEqual(Object other)

* Equality test that is safe for null values.

  eqNullSafe(Object other)

## Numeric 

Basic check between current metric result and threshold (constant)/other metric result

* Greater than or equal to an expression.

  geq(Object other) 

* Greater than

  gt(Object other)

* Less than or equal to
	
  leq(Object other)

* Less than

  lt(Object other)

