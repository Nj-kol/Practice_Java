
# Data Validation

## Launch Spark Shell

sudo hostname -s 127.0.0.1
sudo spark-shell --conf spark.ui.port=4041 --jars /opt/jars/mysql-connector-java-5.0.8.jar

## Validator Code

```
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import org.apache.spark.sql.RowFactory
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.count
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.Encoders
import org.apache.spark.sql.types._
import org.apache.spark.sql.catalyst.encoders._

case class ColumnValiationResult(colName: String, reason: String)

/**
 * Contains certain methods which help in validating 
 * a DataFrame and also to create a validation report
 *
 * @author Nilanjan Sarkar
 * @since  November 2019
 */
class JBDLValidator extends Serializable {

  private def createFinalRecord(currRow: Row, results: Seq[ColumnValiationResult]): Row = {
    val valRes = ArrayBuffer[Row]()
    results.foreach { rec => valRes += Row.fromSeq(Seq(rec.colName, rec.reason)) }
    Row.merge(currRow, RowFactory.create(valRes))
  }

  private def validateColumns(validator: Row => Seq[ColumnValiationResult], rec: Row): Row = {
    val valRes = validator(rec)
    createFinalRecord(rec, valRes)
  }

  /**
   * Validates the entire input DataFrame per row, based on the
   * validation function passed and produces a column
   * that contains validation results
   *
   * @param input The DataFrame to be validated
   * @param validator A lambda of type : {@code Row => Seq[ColumnValiationResult]}, that does the actual data validation
   *
   * @return A DataFrame containing a new column called "validation_report" that contains the validation results
   */
  def validateDataset(input: DataFrame, validator: Row => Seq[ColumnValiationResult]): DataFrame = {
    val valResSchema = Encoders.product[ColumnValiationResult].schema
    val originalSchema = input.schema
    val finalSchema = originalSchema.add("validation_report", ArrayType(valResSchema, true), true)
    input.map { row => validateColumns(validator, row) }(RowEncoder.apply(finalSchema))
  }

  /**
   * Creates a report out of validated Dataframe of aggregate statistics
   *
   * @param validatedDf A validated DataFrame
   * @return A DataFrame containing containing a report of the validation of various fields
   */
  def createPerColValidationReport(validatedDf: DataFrame): DataFrame = {

    val flattened = validatedDf.withColumn("report", explode(col("validation_report"))).select("report")
    val perRecordReport = flattened.select("report.colName", "report.reason")
    perRecordReport.createOrReplaceTempView("validation_report")
    perRecordReport
      .groupBy("colName", "reason").agg(count("*") as "invalid_record_count")
      .select("colName", "reason", "invalid_record_count")
  }
}
```

## Demo

```
val jdbcHostname = "localhost"
val jdbcPort = 3306
val jdbcDatabase ="test"
val jdbcTable = "product_sales"
val jdbcUsername = "root"
val jdbcPassword = "asd"
val driverClass = "com.mysql.jdbc.Driver"
// Create the JDBC URL without passing in the user and password parameters.
val jdbcUrl = s"jdbc:mysql://${jdbcHostname}:${jdbcPort}/${jdbcDatabase}"

val partitionColumn = "date"
val lowerBound = "2012-03-02"
val upperBound = "2012-04-29"
val numPartitions = 4

val sourceDf = spark.read
  .format("jdbc")
  .option("url", jdbcUrl)
  .option("driver", driverClass)
  .option("dbtable", jdbcTable)
  .option("user", jdbcUsername)
  .option("password",jdbcPassword)
  .option("pushDownPredicate","true")
  .option("partitionColumn",partitionColumn)
  .option("lowerBound",lowerBound)
  .option("upperBound",upperBound)
  .option("numPartitions",numPartitions)
  .load()

val productValidator = (row: Row) => {
	val valRes = ArrayBuffer[ColumnValiationResult]()
	val brandCode = row.getAs[Int]("brand")
	val purchasequantity = row.getAs[Int]("purchasequantity")
	if(brandCode==0){
	  valRes += ColumnValiationResult("brand","Brand code cannot be zero")
	}
	if(purchasequantity==0){
	  valRes += ColumnValiationResult("purchasequantity","Purchase Quantity cannot be zero")
	}
	valRes
}

// Initialize a new instance of validator
val validator = new JBDLValidator()

val validatedDf = validator.validateDataset(sourceDf,productValidator)

validatedDf.show(false)
validatedDf.select("brand","purchasequantity","validation_report").show(false)
validatedDf.where($"purchasequantity"===0).show

val dirtyRecords = validatedDf.where("size(validation_report)>0")
dirtyRecords.show(false)

val cleanRecords = validatedDf.where("size(validation_report)=0")
cleanRecords.show(false)

val perColReport= validator.createPerColValidationReport(validatedDf)
perColReport.show(false)
```

**Publish entire df report**

```
def publishValidationReport(validatedDf: DataFrame) {
	val flattened = validatedDf.withColumn("report", explode($"validation_report")).select("report")
	val perRecordReport = flattened.select("report.colName","report.isValid","report.reason")	
	perRecordReport.show(false)
}

publishValidationReport(validatedDf)
```

## Sample validated data

```
+-----+-----+----+--------+----------+-----+----------+-----------+--------------+----------------+--------------+-------------------------------------------+
|id   |chain|dept|category|company   |brand|date      |productsize|productmeasure|purchasequantity|purchaseamount|validation_report                          |
+-----+-----+----+--------+----------+-----+----------+-----------+--------------+----------------+--------------+-------------------------------------------+
|86246|205  |97  |9753    |1022027929|0    |2012-03-02|1.00       |CT            |1               |5.99          |[[brand, false, Brand code cannot be zero]]|
|86246|205  |97  |9753    |1021015020|0    |2012-03-02|1.00       |CT            |1               |7.80          |[[brand, false, Brand code cannot be zero]]|
|86246|205  |97  |9753    |1021013323|0    |2012-03-02|1.00       |CT            |1               |8.87          |[[brand, false, Brand code cannot be zero]]|
|86246|205  |97  |9753    |10000     |0    |2012-03-02|1.00       |CT            |1               |0.69          |[[brand, false, Brand code cannot be zero]]|
|86246|205  |97  |9753    |1021013424|0    |2012-03-02|1.00       |CT            |4               |14.64         |[[brand, false, Brand code cannot be zero]]|
+-----+-----+----+--------+----------+-----+----------+-----------+--------------+----------------+--------------+-------------------------------------------+
```

## Next

 
    val validationMsg = "vendor name cannot be more than 15 characters"
    val fieldName = ""
    val fieldType =""
    fieldType match {
      case "String" => 
          val fieldValue = row.getAs[String](fieldName)
    }
  
    if (false) {
      valRes += ColumnValiationResult(fieldName, false, validationMsg)
    }
    

References
==========
https://stackoverflow.com/questions/46136715/field-data-validation-using-spark-dataframe/46139584#46139584