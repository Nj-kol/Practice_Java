
https://coedevanalytics2.jio.com:8443

Discussion regarding power and utility report for Neo4j/UTM/TempIP integration

HPSM
- gg started
- historical pending
- master table creation pending

TEMIP
- gg started
- historical pending
- master table

UTM
- gg started
- historical pending
- master table creation pending


Neo4j 
- historical not done

