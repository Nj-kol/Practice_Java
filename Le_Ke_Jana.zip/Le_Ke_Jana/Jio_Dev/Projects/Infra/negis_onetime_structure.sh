
current_date=`date +'%Y-%m-%d'`
partitiondate="$(date "+%Y-%m-%d" -d "2 days ago")"

user="SI_JBDL"
pass_word="Eblaw2#at"

beeline_connection="jdbc:hive2://bdpdata1592.jio.com:2181,bdpdata1591.jio.com:2181,bdpdata1598.jio.com:2181,bdpdata1595.jio.com:2181,bdpdata1594.jio.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2?tez.queue.name=network-jobs"

################ cleanup stage  ##########


##### removing directories ########

array=(/data/hdfs11/proddeployement/SIJLGis/negis_new/structure)

for i in "${array[@]}"
do
    if [ -d "${i[@]}" ]; then
       rm -r ${i[@]}
       echo "directories removed"
    else
       mkdir ${i[@]}
       echo "directories created"
fi
done


###### removing landing directories ##########

msg=$(hadoop fs -rm -r /data/devices/gis/ne/structure_landing 2>&1) && echo "INFO landingDirectory removed" || echo "ERROR ${msg}"


##### removing staging files ###########

msg=$(hadoop fs -rm -f /data/devices/gis/ne/structure_staging/* 2>&1) && echo "INFO staging files removed" || echo "ERROR ${msg}"

#### removing avro schema's directories #######


msg=$(hadoop fs -rm -r /data/devices/gis/ne/structure_avsc 2>&1) && echo "INFO schema Directory removed" || echo "ERROR ${msg}"


######### Initialising directories ##############

structure_landing="/data/devices/gis/ne/structure_landing"

pids_path="/data/hdfs11/proddeployement/SIJLGis/negis_new/pids/${current_date}"
stats_path="/data/hdfs11/proddeployement/SIJLGis/negis_new/stats"
#load_stats="/tmp/load_stats/"

[ -d "${pids_path}" ] && echo "Directory ${pids_path} exists" || echo "Creating for today ${pids_path}"
mkdir -p "${pids_path}"
mkdir -p "${stats_path}"
mkdir -p "${load_stats}"

fn_post_updates() {
  step_name=$1
  step_status=$2
  msg=$3
  if [ ${step_status} -ne 0 ]; then
    touch "${pids_path}/pid_${step_name}_failed"
    echo "ERROR ${step_name} failed: ${msg}"
    echo -e "${step_status}\t${current_date}\t${step_name}\tFAILED\t${msg}\t$(date '+%F %T')" >> "${stats_path}/stats_${current_date}.out"
    exit 1
  else
    touch "${pids_path}/pid_${step_name}_succeeded"
    echo "INFO ${step_name} succeeded"
    echo -e "${step_status}\t${current_date}\t${step_name}\tSUCCEEDED\t${msg}\t$(date '+%F %T')" >> "${stats_path}/stats_${current_date}.out"
  fi
}


#####  sqoop for structure table #####

echo "INFO : executing sqoop for negis structures for ${current_date}"

cd /data/hdfs11/proddeployement/SIJLGis/negis_new/structure

sqoop import \
-Dmapreduce.job.classloader=true \
-Dmapreduce.job.user.classpath.first=true \
-Dmapred.job.queue.name=network-jobs  
--connect jdbc:oracle:thin:@10.147.180.112:1522/SAT_DR \
--username ${user} \
--password ${pass_word} \
--relaxed-isolation 
--query "select OBJECTID ,STRUCTURE_NAME,CATEGORY_NAME,TYPE_NAME,LOCATION_CODE,OWNERSHIP_TYPE_CODE,INVENTORY_STATUS_CODE,PARENT_STRUCTURE_NAME,WORK_ORDER_NAME  ,WORK_ORDER_ITEM_NUMBER,STRUCTURE_REF_NAME,LENGTH_ADJUSTMENT,REMARKS,FIELD_NAME,ACCOUNT_CODE,PLACEMENT_DATE,HEIGHT,WIDTH ,LENGTH,DEPTH_PLACED ,AIR_COND_REQUIREMENT,POWER_TYPE_AVAILABLE,MAX_POWER_REQUIREMENT,CUSTOMER_NAME,CLLI_CODE,FQN  ,PURCHASE_ORDER,INSTALLED_COST,JOINT_USE ,VOLUME,KEY_ACCESS_ID ,SITE_TYPE ,MODIFICATION_IND ,DIAMETER ,WEIGHT ,MATERIAL_COST ,MATERIAL_TYPE,ORDERABLE,UUID  ,REF_UUID ,MANUFACTURER_CODE,PRODUCT_LINE_CODE ,PART_NUMBER ,ROTATION ,MANAGED_OBJECT_ID ,DI_TOKEN ,GLOBAL_ID,GROUND_HEIGHT ,MR  ,MODEL_UUID ,AVERAGE_FLOOR_HEIGHT,STARTING_FLOOR,ENDING_FLOOR ,UNITS ,GROUND_FLOOR_NUMBER,SERVING_STRUCTURE ,SERVING_EQUIPMENT ,TRANSMEDIA_DEMAND ,ENABLED,ANCILLARYROLE,RJ_IIEP_DOMAIN,RJ_NETWORK_ENTITY_ID,RJ_STATE_NAME ,RJ_DISTRICT_NAME ,RJ_CITY_NAME ,RJ_WARD_NAME ,RJ_RF_SITEID ,RJ_TOWER_HEIGHT  ,RJ_NO_OF_POLES,RJ_TOWER_TYPE ,RJ_CITY_CODE,RJ_SITE_ADDRESS,RJ_PINCODE,RJ_PROMINANT_LANDMARK,RJ_NO_OF_SECTORS,RJ_CONNECTIVITY_TYPE,RJ_STATE_CODE,RJ_MODEL_TYPE ,RJ_STRUCTURE_ID  ,RJ_SITE_OWNER ,RJ_MWSTATUS ,RJ_LOCALITY_NAME ,RJ_LOCALITY_CODE,RJ_R4G_STATE_NAME ,RJ_R4G_STATE_CODE,RJ_LDCA_NAME ,RJ_SDCA_NAME ,RJ_STRUCTURE_RJID ,RJ_SAPID ,RJ_TRAI_CIRCLE_NAME ,RJ_TRAI_CIRCLE_CODE,RJ_STATUS,RJ_LOCATION_TYPE,RJ_STRUCTURE_TYPE ,RJ_OLT_NUMBER ,RJ_NETWORK_TYPE  ,RJ_NETWORK_CATEGORY ,RJ_SWITCH_ON_NETWORK,RJ_FINAL_NETWORK ,RJ_ROUTE_LINK_ID ,RJ_SCOPE_CATEGORY ,RJ_NEIGHBOUR_EAST ,RJ_NEIGHBOUR_WEST ,RJ_PARENT1 ,RJ_PARENT2 ,RJ_PARENT3 ,RJ_PARENT_EAST,RJ_PARENT_WEST,RJ_SITE_RADIUS,RJ_MAINTENANCE_ZONE_NAME,RJ_MAINTENANCE_ZONE_CODE,RJ_CDP_HQ_NAME,RJ_SDCA_CODE,RJ_LDCA_CODE,RJ_DISTRICT_CODE,RJ_VILLAGE_CODE_2001,RJ_WARD_CODE_2011 ,RJ_VILLAGE_NAME  ,RJ_CITY_CLUSTER_HQ_NAME,RJ_TALUK_NAME ,RJ_TALUK_CODE,FILTERED_OUT,LATITUDE ,LONGITUDE,RJ_PRIORITY,RJ_RADIUS,RJ_LOADING_CONDITION,RJ_MH_COVER_MATERIAL,RJ_BUILDING_RJID ,RJ_LAST_MODIFIED_BY ,RJ_LAST_MODIFIED_DATE,RJ_VISIBLE ,RJ_PARENTING_AG1_EAST,RJ_PARENTING_AG1_WEST,RJ_PARENTING_AG2_EAST,RJ_PARENTING_AG2_WEST,RJ_FACILITY_STATUS ,RJ_LEASE_REF ,RJ_COUNTRY_NAME  ,RJ_SITE_NAME ,RJ_COMMISSIONING_DATE,RJ_INSERVICE_DATE,RJ_JC_NAME ,RJ_JC_CODE ,RJ_FSA_ID,RJ_LEASE_NETWORK_ID ,RJ_FAULT_NUMBER  ,RJ_COLO_SAPID ,RJ_DSA_ID  ,RJ_CSA_ID  ,RJ_ELECT_CONN,RJ_SANC_LOAD_KW,RJ_ELECT_CONN_PH,RJ_TOWER_DESIGN_TYPE,RJ_TOWER_FEASIBILITY,RJ_CONSUMER_NUMBER ,RJ_METER_NUMBER  ,RJ_METER_MAKE ,RJ_METER_OWNER,RJ_METER_TYPE ,RJ_TRAFO_MAKE ,RJ_TRAFO_RATING  ,RJ_TRAFO_OWNERSHIP ,RJ_EB_BILL_CYCLE ,RJ_AVERAGE_EB,RJ_MAINTENANCE_STATE,RJ_MAINTENANCE_STATE_CODE,RJ_ESA_ID,RJ_SCOPE ,RJ_JIOPOINT_NAME ,RJ_JIOPOINT_SAPCODE ,RJ_COMPANY_CODE_1,RJ_COMPANY_CODE_2,RFE1_HOTO_DATE,RJ_CAPITALISATION_STATUS,GLOBALID ,NE_OBJECTID ,RJ_HUB_CATEGORY,RJ_DEPEDENT_SITE_COUNT,RJ_ENERGY_TYPE 
from  APP_FTTX.Structures where \$CONDITIONS" 
--target-dir ${structure_landing} \
--split-by OBJECTID \
--as-avrodatafile \
--num-mappers 30 || fn_post_updates "sqoop_structure" $? "${msg}" 


##copying files from landing to staging directories ##


msg=$(hadoop fs -cp ${structure_landing}/* /data/devices/gis/ne/structure_staging/ 2>&1) && echo "INFO copied structure landing to staging" || echo "ERROR ${msg}"


############ creating avsc directories for avsc files ###########


msg=$(hadoop fs -mkdir /data/devices/gis/ne/structure_avsc 2>&1) && echo "INFO structure avsc directory created " || echo "ERROR ${msg}"


####### copying avsc files generated in local dirs to hdfs directories  ##############


hadoop fs -copyFromLocal /data/hdfs11/proddeployement/SIJLGis/negis_new/structure/AutoGeneratedSchema.avsc /data/devices/gis/ne/structure_avsc/
 

############### creating external staging avro tables ###############

query_create="create external table if not exists network.negis_structure_avro stored as avro location '/data/devices/gis/ne/structure_staging' TBLPROPERTIES ('avro.schema.url'=' /data/devices/gis/ne/structure_avsc/AutoGeneratedSchema.avsc');"

msg=$(beeline -u "${beeline_connection}" --silent=true --showHeader=false --outputformat=tsv2 -e "${query_create}" 2>&1) && echo "tables are created" || echo "ERROR ${msg}"

########### updating records for external tables ############

query="msck repair table network.negis_structure_avro;"

msg=$(beeline -u "${beeline_connection}" --silent=true --showHeader=false --outputformat=tsv2 -e "${query}" 2>&1) && echo "tables are updated" || echo "ERROR ${msg}"

echo "${msg}"

date | echo $?
