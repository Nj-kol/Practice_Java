
# GI Or granite tables

## Granite Tables to be ingested

* SITE_INST
    - Possibly ingested

* SITE_ATTR_SETTINGS
    - Possibly ingested

* EQUIP_INST
    - Possibly ingested

* EQUIP_ATTR_SETTINGS
    - Possibly ingested

* CARD_INST
  - Possibly ingested

* EPA
    - Possibly ingested

* CIRC_PATH_INST
    - Possibly ingested

* CIRC_PATH_ELEMENT
    - Possibly ingested

* VAL_ATTR_NAME
    - Possibly ingested

* SLOT_INST
* CARD_ATTR_SETTINGS
* PORT_ATTR_SETTINGS
* CABLE_INST
* CABLE_PAIR_INST
* CABLE_ATTR_SETTINGS
* CABLE_PAIR_ATTR_SETTINGS
* CIRC_PATH_ATTR_SETTINGS
* PATH_LEG_INST
* PATH_LEG_MEMBER
* PATH_CHAN_INST
* PATH_CHAN_USAGE
* VAL_ATTR_GROUP

## Confirmed by Atul

SITE_INST
SITE_ATTR_SETTINGS
EQUIP_INST
EQUIP_ATTR_SETTINGS

## Sample Hive Table creation for GG tables

```sql
create external table network.xc_circ_path_element
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.avro.AvroSerDe'
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat'
LOCATION '/ogg1/xc.circ_path_element'
TBLPROPERTIES ('avro.schema.url'='/ogg1/avro_def/XC.CIRC_PATH_ELEMENT.avsc');
```

# Notes

1. GG replication for all the table with current date
2. 16 out of 22 table to be replicated with historic data

3. 6 out of 22 tables historic data to be ingested with Pipe separated CSV file
4. Mr. Shikhar suggested to have Union based hive View for adding the historic and current data.
5. A system to match the row counts to be established.

