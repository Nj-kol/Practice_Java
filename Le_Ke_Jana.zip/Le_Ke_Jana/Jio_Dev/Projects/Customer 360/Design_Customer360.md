
# Customer 360

## Load 

* Bulk load data from Hive to HBase using Spark. 

* This job should run as sort of a *Snapshot* process. That is the job will 
  run every *X interval of time* and ferry data from Hive to HBase

* This process entails the following high level details :
  - Use Spark to create read data the HFiles
  - Write the HFiles to a temp HDFS location 
  - Load the HFile to HBase

* The Spark job will do the following :
  - Read data from Hive
  - Convert it to the target data model in HBase
  - Write the HFile to HDFS

  This process of loading HFiles instead of writing records to HBase in parallel
  has the advntage of skipping the regular write path and thus achieve a better throughput

* As an added optimization step, the column family data could be kept in Avro format 
  ( instead of JSON typically ) to reduce the size of storage

**Tech Stack**

* Hive
* Spark
* HDFS
* HBase
* Avro ( Optional )

## Serve

* The serving process should consist of a typical 3-tier architecture as :
	- HBase for Storage
	- An Webservice which exposes the underlying data as a URL enpoint :
	- A UI layer which calls the API endpoint to consume theb data

* The webservice would typically do the following :
  - Reads the data from the underlying data store
  - Does message format translations
  - Validates 

**Tech Stack**

* HBase 
* Spring based ( This can be accomodated in our upcoming API Layer ) 
* Some UI technology ( React, Angular etc )

# Data Model

* This has to be deliberated  in great detail by studying the exising data model
  and for any upcoming systems. If HBase is chosen, then having the correct data
  model is crucial for Scalability

# Pros and Cons 

**Pros**

* Storing data in HBase makes it Highly Scalable
* Data Model is flexible
* Can accept streaming writes at moderate volumes

**Cons**

* No secondary indices, thus you can only look up via row key i.e
  retrieve the entire row or none at all
* Data model is flexible 
  - Since the data model is flexible, if not done properly can be abused


