
# Requirement 1 : Customer 360

## Requirements

* Fast writes
  - Ability to ingest data from multiple sources fast
* Online querying 
  - Sub millisecond latencies
* Flexible data model
  - Same entity can have different data model across disparate source systems
  - Entities can 
* Sparse data store
  - Every source may not have all the attributes, so storage should not be wasted

# Requirement 2 : Adhoc reporting

## Requirements

* Roll up 
* Drill down
* Ad-hoc queries