
References
==========
https://www.opencore.com/de/blog/2016/10/efficient-bulk-load-of-hbase-using-spark/

https://phoenix.apache.org/tuning_guide.html

Kylin : https://www.youtube.com/watch?v=gf-zHe4eFSM



Hbase 
- Online querying 

Apache Phoenix: Use Cases and New Features : https://www.youtube.com/watch?v=-qCCMuWYpls


Phoenix-Hbase ORM


create 'customer360', 'demographics', 'savings', 'loan', 'credit', 'deposit', 'credittrxsummary'


The row key is a reverse of that cookie ID. 

This begs the question of why to reverse a generated UUID. 

There are two primary offenders that require reverse keys: 
websites and time series data. 

In this case, the beginning of the cookie ID has
the timestamp on it. This would lead to monotonically 
increasing row keys; by simply reversing the row key, 
the randomly generated portion now occurs first in the row key.


Indeed, every time we
query HBase for a row, we will use its rowID so that we can be sure that it exists. Also,
most of the time, the entire dataset will be processed and not just a single line. Therefore,
having to look at the Bloom filter just to confirm that the row exists is an overhead.

