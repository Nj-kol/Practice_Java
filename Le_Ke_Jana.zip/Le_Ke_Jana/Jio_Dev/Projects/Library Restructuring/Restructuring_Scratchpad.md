
# Restructuring 

sbt new scala/scala-seed.g8

## Design Language

coe-<category>-<implementation>

## Ingestion

coe-ingestion

## Services

coe-services-commons

coe-services-hive
coe-services-redis
coe-services-ignite
coe-services-elastic
coe-services-druid

## Processing

coe-processing-spark
coe-processing-flink

## Cross Cutting Concerns

coe-utils-commons
coe-utils-security

org.apache.commons commons-text 1.5
org.apache.commons commons-dbcp2 2.7.0


git checkout -b ignite


Symbolic vs Numeric math

```
import sympy as sym
sym.init_printing()
from IPython.display import display

# Create symbolic variables
x,y = sym.symbols('x,y')

display(x**y)
display(x/y)

display(sym.sqrt(2))

display(y*x**2)
```

# Latex

```
from IPython.display import Math,display

display(Math('\\sigma'))


display(Math('\\sigma = \\mu \\times \\sqrt{5}'))
```

## Subscript & Superscipts

```
# Subscipt

display(Math('x_m'))
display(Math('x_{mn}'))

# Superscipt

display(Math('x^n'))
display(Math('x^{mn}'))

display(Math('x^{2} + 2xy + y^2 = (x+y)^2'))
```

## Frction


```
display(Math('\\frac{x+1}{y+2}'))
```

## Text

```
display(Math('\\text{The solution to this problem is denoted by the expression : } \\frac{x+1}{y+2}'))
```

# With Markdown

```
# This is markdown

The solution to this problem is denoted by the expression :

$$\frac{x+1}{y+2}$$
```

* The latex code is written between two $$
* In Markdown version, only one \ is needed


# Sympy with Latex

expr = 3/x

sl = sym.latex(expr)

display(Math(sl))

sf = sym.sympify('3/4')
l  = sym.latex(sf)
display(Math(l))

