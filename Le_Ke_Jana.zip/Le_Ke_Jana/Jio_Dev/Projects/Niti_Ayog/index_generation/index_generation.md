## DDL

```sql
create table network_dev.user_location_hourly_index_mumbai_po(
masked_imsi string,
geohash7 string,
city string
)
PARTITIONED BY (partition_date date ,hour int)
STORED AS ORC
TBLPROPERTIES ('orc.bloom.filter.columns'='geohash7,masked_imsi,city');
```

## Driver

```bash
#! /bin/bash
beeline -u "jdbc:hive2://bdpdata1592.jio.com:2181,bdpdata1591.jio.com:2181,bdpdata1598.jio.com:2181,bdpdata1595.jio.com:2181,bdpdata1594.jio.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2?tez.queue.name=development" \
--hivevar partition_date='2020-04-05' \
--hivevar UDFjar_path='hdfs://JioBigDataLakeha/tmp/PawanUDF/ScalaUDF-assembly-0.3.jar' \
--hivevar circle=Mumbai \
--hivevar target_DB=network_dev \
--hivevar target_table=user_location_hourly_index_mumbai \
--hivevar source_DB=network \
--hivevar source_table=lsr_mumbai_po \
-f index.hql
```

## Ingestion

```sql
USE ${hivevar:target_DB};
SET mapred.reduce.tasks=150;
SET tez.grouping.min-size=1073741824;
SET tez.grouping.max-size=1073741824;
SET hive.tez.container.size=16192;

ADD JAR ${hivevar:UDFjar_path};
DROP FUNCTION IF EXISTS GeoHashEncodeUDF;
CREATE FUNCTION GeoHashEncodeUDF AS 'com.jio.udf.GeoHashEncodeUDF';

create temporary table lsr_temp_hour as
   select 0 as hour, "" as geohash
   union all  select 1 , null 
   union all  select 2 , null
   union all  select 3, null
   union all  select 4, null
   union all  select 5, null
   union all  select 6, null
   union all  select 7, null
   union all  select 8, null
   union all  select 9, null
   union all  select 10, null
   union all  select 11, null
   union all  select 12, null
   union all  select 13, null
   union all  select 14, null
   union all  select 15, null
   union all  select 16, null
   union all  select 17, null
   union all  select 18, null
   union all  select 19, null
   union all  select 20, null
   union all  select 21, null
   union all  select 22, null
   union all  select 23, null;

with user_mig_loc_info as (
Select
loc.masked_imsi,
loc.geohash7,
'Mumbai' as circle,
loc.partition_date,
loc.hour
from
(
    select masked_imsi, geohash7, partition_date, hour , 
    row_number() over (partition by masked_imsi, hour order by cnt desc) as row_num
    from (
        select masked_imsi,geohash7, hour,partition_date, 
        count(geohash7) over (partition by masked_imsi, hour) as cnt 
        from (
            select 
            mask_hash(cast(imsi as String)) as masked_imsi, 
            GeoHashEncodeUDF(end_latitude,end_longitude,7) as geohash7,  
            hour(end_time) as hour,partition_date 
            from network.lsr_mumbai_po
            where partition_date = '${hivevar:partition_date}' 
            and end_latitude is not null and end_longitude is not null
            ) a
        ) b
    ) loc
where loc.row_num =1  and loc.masked_imsi is not null
),
cte1 as (
select *
from lsr_temp_hour cross join (select distinct  circle, partition_date, masked_imsi from user_mig_loc_info) h
),
cte2 as (
    select
    cte1.masked_imsi ,
    ab.geohash7 as geohash7, 
    cte1.circle, 
    cte1.partition_date, 
    cte1.hour from cte1 left outer join user_mig_loc_info ab on cte1.masked_imsi = ab.masked_imsi
    and cte1.partition_date = ab.partition_date
    and cte1.hour = ab.hour
),
cte3 as (
    select masked_imsi, 
    COALESCE(geohash7 , 
            LAST_VALUE(geohash7, TRUE) OVER(partition by masked_imsi order by hour asc ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
            ) as geohash7, 
    circle, partition_date, hour 
    from cte2
)
insert into network_dev.user_location_hourly_index_mumbai partition(circle='Mumbai',partition_date,hour)
Select 
masked_imsi, 
COALESCE(geohash7 ,
LAST_VALUE(geohash7, TRUE) OVER(partition by masked_imsi order by hour desc 
    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)) as geohash7, 
partition_date, 
hour from cte3;
```
```

## References

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_git/coe-business?path=%2Fscripts%2Fhive%2Fcovid-analysis%2Findex_generation_v1&version=GBfix%2Fone_infra_tower_operate_release_106