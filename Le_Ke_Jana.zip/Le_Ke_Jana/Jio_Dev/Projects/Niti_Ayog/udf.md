

https://github.com/davidmoten/geo/blob/master/geo/src/main/java/com/github/davidmoten/geo/GeoHash.java


Create a Hive UDF that takes in five parameters 

– bounding box lat long details 
- length of geohash (5 or 6 or 7)  

and returns a list of geohash’s necessary to cover the region. --> Nilanjan

coverBoundingBox(topLeftLat, topLeftLon, bottomRightLat, bottomRightLon, length) : Set[Hash]
 
See https://github.com/davidmoten/geo/blob/master/geo/src/main/java/com/github/davidmoten/geo/GeoHash.java line number #612 & Coverage.java #53 of the same package for details of the exact implementation.

https://github.com/davidmoten/geo/blob/master/geo/src/main/java/com/github/davidmoten/geo/Coverage.java

Coverage - A set of hashes and a measure of how well those hashes cover a region

https://www.flickr.com/places/info; 
https://www.latlong.net/; 
https://tools.wmflabs.org/geohack;

## Shikhar

spark-shell --packages  "com.github.davidmoten:geo:0.7.1"

```scala
import com.github.davidmoten.geo._

def evaluate(topLeftLat: Double,topLeftLon: Double,bottomRightLat: Double,bottomRightLon: Double,length: Int): java.util.Set[String] = {
        val coverage = GeoHash.coverBoundingBox(topLeftLat,topLeftLon,bottomRightLat,bottomRightLon,length)
        coverage.getHashes()
}

val level = 7
val e = evaluate(topLeftLat, topLeftLon, bottomRightLat, bottomRightLon,level)
```

## Centroid coordinates

**Bangalore**

val topLeftLat =13.163544
val topLeftLon= 77.320523
val bottomRightLat=12.736943
val bottomRightLon= 77.858853

tdqb, tdqc, tdqf, tdr0, tdr1, tdr2, tdr3, tdr4, tdr6

**Chennai**

val topLeftLat = 13.254652
val topLeftLon= 80.071630
val bottomRightLat= 12.827873
val bottomRightLon= 80.351782

tf2b, tf2c, tf2f, tf2g, tf30, tf31, tf34, tf35

**Hyderabad**

val topLeftLat = 17.603185
val topLeftLon = 78.151227
val bottomRightLat = 17.246792
val bottomRightLon = 78.679944

tepd, tepe, tepf, tepg, teps, tepu

**Bangalore**

val topLeftLat =13.163544
val topLeftLon= 77.320523
val bottomRightLat=12.736943
val bottomRightLon= 77.858853

**Chennai**

val topLeftLat = 13.254652
val topLeftLon= 80.071630
val bottomRightLat= 12.827873
val bottomRightLon= 80.351782

**Hyderabad**

val topLeftLat = 17.603185
val topLeftLon = 78.151227
val bottomRightLat = 17.246792
val bottomRightLon = 78.679944




