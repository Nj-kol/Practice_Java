
# Mobility

## Area wise mobility data

```sql
CREATE EXTERNAL TABLE network_dev.shivam_mumbai_mobility_table_with_lat_long (
geohash7 string,
user_count bigint,
distance_avg double,
distance_stddev double,
lat double,
long double) 
PARTITIONED BY(partition_date date) 
STORED AS ORC
TBLPROPERTIES('orc.bloom.filter.columns'='geohash7');
```
per geo hash, per day :

- what is the lat, long for the geohash
- no. of users
- avg distance travelled in that geohash

## Ingestion

frequency_cte                   -> per day, per user per geohash how many times has the user been there
frequency_cte2 & frequency_cte3 -> take the top geohash where the user has been
distance_cte1 & distance_cte2   -> take top geohash where the user has been for the next hour
distance_cte3 & distance_cte4   -> 

SET tez.grouping.min-size=536870912;
SET tez.grouping.max-size=536870912;
SET mapred.reduce.tasks=50;

```sql
WITH frequency_cte AS (
SELECT
partition_date,
masked_imsi,
geohash7,
count(geohash7) as pid_data_geohash_count
FROM network_dev.Pawan_user_mig_loc_mumbai_info_V1
GROUP BY partition_date,masked_imsi,geohash7
), 
frequency_cte2 AS (
SELECT
partition_date,
masked_imsi,
geohash7,
row_number() over (PARTITION BY partition_date,masked_imsi order by pid_data_geohash_count desc) as rn
FROM frequency_cte
), 
frequency_cte3 AS(
SELECT 
partition_date,
masked_imsi,
geohash7 
FROM frequency_cte2 WHERE rn=1
), 
distance_cte1 as (
SELECT 
partition_date,
masked_imsi,
geohash7,
lead(geohash7,1) over (partition by partition_date,masked_imsi order by hour) as next_geohash7,
hour
FROM network_dev.Pawan_user_mig_loc_mumbai_info_V1
), 
distance_cte2 AS (
SELECT partition_date,
masked_imsi,
geohash7,
hour,
GeoHashDecodeUDF(geohash7) as current_geohash,
GeoHashDecodeUDF(next_geohash7) as next_geohash
FROM distance_cte1 WHERE next_geohash7 is NOT NULL
), 
distance_cte3 AS (
SELECT partition_date,
masked_imsi,
geohash7,
hour,
DistanceUDF(current_geohash.lat,current_geohash.lon,next_geohash.lat,next_geohash.lon) as distance
FROM distance_cte2
),
distance_cte4 AS (
SELECT masked_imsi,
partition_date,
sum(distance) as distance_sum
FROM distance_cte3
GROUP BY partition_date,masked_imsi
),  
frequency_distance_cte1 AS (
SELECT t1.*, t2.distance_sum
FROM frequency_cte3 t1
JOIN
distance_cte4 t2
ON(t1.masked_imsi = t2.masked_imsi AND t1.partition_date=t2.partition_date)
), 
frequency_distance_cte2 AS (
SELECT
geohash7,
count(masked_imsi) as user_count,
avg(distance_sum) as distance_avg,
stddev(distance_sum) as distance_stddev,
partition_date
FROM frequency_distance_cte1
GROUP BY partition_date,geohash7
), 
frequency_distance_cte3 AS (
SELECT geohash7,
user_count,
distance_avg,
distance_stddev,
GeoHashDecodeUDF(geohash7) as lat_long,
partition_date
FROM frequency_distance_cte2
) 
INSERT INTO network_dev.shivam_mumbai_mobility_table_with_lat_long PARTITION(partition_date)
SELECT 
geohash7,
user_count,
distance_avg,
distance_stddev,
lat_long.lat as lat,
lat_long.lon as long,
partition_date
FROM frequency_distance_cte3;
```

# Notes


My Intuition
- For a particular location, how much many users had visited and how much distance did they travel on an average


## References
https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_git/coe-business?path=%2Fscripts%2Fhive%2Fcovid-analysis%2Fmobility&version=GBfix%2Fone_infra_tower_operate_release_106
