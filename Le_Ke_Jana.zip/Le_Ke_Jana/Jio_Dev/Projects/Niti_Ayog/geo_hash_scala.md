
# Geo Hash in Scala

<dependency>
    <groupId>com.github.davidmoten</groupId>
    <artifactId>geo</artifactId>
    <version>0.7.1</version>
</dependency>

```bash
spark-shell --packages  "com.github.davidmoten:geo:0.7.1"
```

```scala
import org.apache.spark.sql.functions._
import com.github.davidmoten.geo.GeoHash

def getGeoHash(lattitude: Double,longitude: Double,precision: Int): String = {
  GeoHash.encodeHash(lattitude,longitude,precision)
}

val geoHashUdf = udf[String,Double,Double,Int](getGeoHash)

val userData =
Seq(
(111,19.166152,72.835385),
(145,19.166664,72.83455),
(346,19.166459,72.835619),
(347,19.166169,72.834954),
(348,19.166536,72.835709)).toDF("pid","lat","long")

userData.withColumn("geohash", geoHashUdf(col("lat"),col("long"),lit(8))).show(false)

// David algo
+---+---------+---------+--------+
|pid|lat      |long     |geohash |
+---+---------+---------+--------+
|111|19.166152|72.835385|te7v13j4|
|145|19.166664|72.83455 |te7v13ht|
|346|19.166459|72.835619|te7v13jk|
|347|19.166169|72.834954|te7v13hg|
|348|19.166536|72.835709|te7v13jm|
+---+---------+---------+--------+
```

// Exisiting

["2020-03-18","57","te7v13j7","['19.166152', '72.835385']"],
["2020-03-18","249","te7v13hn","['19.166664', '72.83455']"],
["2020-03-18","140","te7v13jn","['19.166459', '72.835619']"],
["2020-03-18","217","te7v13g1","['19.166169', '72.834954']"],
["2020-03-18","39","te7v13jk","['19.166536', '72.835709']"],



















