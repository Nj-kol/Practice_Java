
# Migration

## Migration by hour

CREATE TABLE `network_dev.Sunny_user_mig_by_hour_v1`( 
`from_geohash` string, 
`to_geohash` string,
`from_geohash_lat` double,
`from_geohash_long` double,
`to_geohash_lat` double,
`to_geohash_long` double,
`people_who_moved` string) 
PARTITIONED BY ( `partition_date` date, `hour` int)
STORED AS ORC
TBLPROPERTIES ( 
'orc.bloom.filter.columns'='from_geohash,to_geohash');

No of people who moved from one geohash to another

## Ingestion

SET mapred.reduce.tasks=100;
SET tez.grouping.min-size=1073741824;
SET tez.grouping.max-size=1073741824;
SET hive.exec.dynamic.partition.mode=nonstrict;

WITH phase_one AS (
SELECT 
concat(partition_date,":",masked_imsi) AS key, 
geohash7 AS geohash_from,
partition_date,
hour
FROM network_dev.Pawan_user_mig_loc_mumbai_info
ORDER BY hour asc),
phase_two AS (
SELECT 
key,
hour,
geohash_from,
lead(geohash_from,1) OVER ( PARTITION BY partition_date ORDER BY hour asc) AS geohash_to,
partition_date
FROM phase_one
WHERE key IS NOT NULL)
INSERT INTO network_dev.Sunny_user_mig_by_hour_v1 partition(partition_date,hour)
SELECT
geohash_from,geohash_to, 
GeoHashDecodeUDF(geohash_from).lat, 
GeoHashDecodeUDF(geohash_from).lon, 
GeoHashDecodeUDF(geohash_to).lat, 
GeoHashDecodeUDF(geohash_to).lon,
count(key) AS people_who_moved,
partition_date,
hour
FROM phase_two
GROUP BY partition_date,hour, geohash_from, geohash_to;

* Tuples are formed of (geohash_from, geohash_to) 
* These tuples are aggregated per day per hour

## Data Flow 

LSR data per region -> Pawan_user_mig_loc_mumbai_info -> Sunny_user_mig_by_hour_v1

## References

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_git/coe-business?path=%2Fscripts%2Fhive%2Fcovid-analysis%2Fmigration&version=GBfix%2Fone_infra_tower_operate_release_106