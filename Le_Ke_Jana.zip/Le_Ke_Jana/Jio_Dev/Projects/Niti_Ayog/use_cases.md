
# Corona use cases

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_HDP_Integration/coe-business/tree/user_location/scripts/hive/user_location

# Feature 122572 : COVID-19 Analysis end to end pipeline to be created

## System Story 123077 : COVID-19 | Telecom Data | Density, Mobility and Migration analysis for different dates and geohash locations

Task 123092 : Work on providing data for Telecom Data Dashboards

## System Story 122862 : End-to-end algo execution for Covid 4-1 suspects generation for 1000 cases in Mumbai over last 7 days

Task 123093 : Write jobs for Covid Tracking

https://git.rjil.ril.com/Jio_Big_Data_Centre_of_Excellence/JBDL_HDP_Integration/coe-business/tree/master/scripts/init/covid-tracking
