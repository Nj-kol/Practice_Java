
# Niti Ayog Dashboard

We have two sources of data:

1. Telecom Data and Symptom Checker data
2. External Data (confirmed cases)

## Telecom Data

### 1.1.	Raw Who-Where-When Data (Raw-WH3)

•	Who is where and when based on their activities on the network
•	FORMAT: (pid, date, time-stamp, latitude, longitude)

LSR data

#### 1.2.	Processed Who-Where-When Data by 5min (WH3-5min)

•	Quantize Time in Raw-WH3 data into time5 time quantization
•	Quantize Location in Raw-WH3 data into geohash8 quantization
•	Interpolate to all the other 5-min’s in between by last known locations
•	FORMAT: (pid, date, time-5, geohash8)

#### 1.3.	Processed Who-Where-When data by hour (WH3-hour)

INPUT: WH3-5min (1.2)

SQL(pid, date, time-5, geohash8) 

a)	Add an hour column to this table (pid, date, time-5, hour(time-5), geohash8)
b)	Do group by (pid, date, time-5) and count the most frequent hour there.
c)	That becomes the dominant location of the user in that hour
d)	Remove the time-5
e)	Output: (pid, date, hour, geohash8)

Table name(1.3) which has been created on saturday --> 

network_dev.Pawan_user_mig_loc_mumbai_info

#### 1.7.	Population Migration by Hour (Migration-By-Hour)

•	How many people moved from one location to another within the last hour
•	FORMAT: (date, hour, from-geohash8, to-geohash8, #people-who-moved)
•	Note: that if from and to are same that is the number of people who stayed wherever they were
•	Using this we can measure the effectiveness of the lockdown at some scale




