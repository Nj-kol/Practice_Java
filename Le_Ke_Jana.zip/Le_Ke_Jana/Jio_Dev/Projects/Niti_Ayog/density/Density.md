
# Density

## Create table

```sql
CREATE TABLE network_dev.Pawan_density_mumbai_with_lat_long_v1(
geohash7 string,
jio_user_count int,
latitude double,
longitude double)
PARTITIONED BY (partition_date date ,hour int)
STORED AS ORC
TBLPROPERTIES ('orc.bloom.filter.columns'='geohash7');
```

Per day, per hour per geohash, how many user were present?

## Ingestion

Pawan_user_mig_loc_mumbai_info_v1 ->  Pawan_density_mumbai_with_lat_long_v1

```sql
SET mapred.reduce.tasks=100;
SET tez.grouping.min-size=1073741824;
SET tez.grouping.max-size=1073741824;
SET hive.exec.dynamic.partition.mode=nonstrict;

insert into network_dev.Pawan_density_mumbai_with_lat_long_v1 partition(partition_date,hour)
select 
geohash7,
count(masked_imsi) as jio_user_count,
geohashdecodeudf(geohash7).lat as latitude,
geohashdecodeudf(geohash7).lon as longitude,
partition_date,
hour
from network_dev.Pawan_user_mig_loc_mumbai_info_v1
group by partition_date, hour, geohash7
```

```sql
SET mapred.reduce.tasks=100;
SET tez.grouping.min-size=1073741824;
SET tez.grouping.max-size=1073741824;
SET hive.exec.dynamic.partition.mode=nonstrict;

insert into network_dev.Pawan_user_mig_loc_mumbai_info_v1 partition(circle,partition_date,hour)
Select
loc.masked_imsi ,
loc.geohash7,
"Mumbai" as circle,
loc.partition_date,
loc.hour
from
   (select masked_imsi,geohash7,
        partition_date,
        hour ,
        row_number() over (partition by masked_imsi, hour order by cnt desc) as row_num
        from (
        select
        masked_imsi,
        geohash7,
        hour,
        partition_date,
        count(geohash7) over (partition by masked_imsi,last_ho_target_cell_id, hour) as cnt
        from (
        select
        mask_hash(cast(imsi as String)) as masked_imsi,
        end_latitude,
        end_longitude,
        geohash(end_latitude,end_longitude,7) as geohash7,
        last_ho_target_cell_id,
        hour(end_time) as hour,
        partition_date
        from network.lsr_mumbai_po
        where partition_date = "2020-03-27" 
        and end_latitude is not null and end_longitude is not null)a
        )b) loc
where loc.row_num =1 
and loc.masked_imsi is not null
```


## References

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_git/coe-business?path=%2Fscripts%2Fhive%2Fcovid-analysis%2Fdensity&version=GBfix%2Fone_infra_tower_operate_release_106