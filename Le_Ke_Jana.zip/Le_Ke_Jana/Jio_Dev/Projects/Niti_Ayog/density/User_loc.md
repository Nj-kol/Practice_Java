
# User Location data

## User location by hour

```sql
CREATE TABLE network_dev.Pawan_user_mig_loc_mumbai_info_v1 (
masked_imsi string,
geohash7 string)
PARTITIONED BY ( circle string, partition_date date ,hour int)
STORED AS ORC
TBLPROPERTIES ('orc.bloom.filter.columns'='geohash7,masked_imsi');
```

## Ingestion

```sql
SET mapred.reduce.tasks=100;
SET tez.grouping.min-size=1073741824;
SET tez.grouping.max-size=1073741824;
SET hive.exec.dynamic.partition.mode=nonstrict;

INSERT INTO network_dev.Pawan_user_mig_loc_mumbai_info_v1 PARTITION (circle,partition_date,hour)
SELECT
loc.masked_imsi ,
loc.geohash7,
"Mumbai" as circle,
loc.partition_date,
loc.hour
FROM
   (SELECT 
    masked_imsi,geohash7,
    partition_date,
    hour ,
    row_number() over (partition by masked_imsi, hour order by cnt desc) as row_num
    FROM (
        SELECT
        masked_imsi,
        geohash7,
        hour,
        partition_date,
        count(geohash7) over (partition by masked_imsi,last_ho_target_cell_id, hour) as cnt
        FROM (
	        SELECT
	        mask_hash(cast(imsi as String)) as masked_imsi,
	        end_latitude,
	        end_longitude,
	        geohash(end_latitude,end_longitude,7) as geohash7,
	        last_ho_target_cell_id,
	        hour(end_time) as hour,
	        partition_date
	        FROM network.lsr_mumbai_po
	        WHERE partition_date = "2020-03-27" 
	        and end_latitude is not null 
	        and end_longitude is not null) a
        ) b 
) loc
WHERE loc.row_num =1 and loc.masked_imsi is not null
```

a -> per user data
b -> partition per user data per hour data per last_ho_target_cell_id by imsi
loc -> ??

## References

https://devops.jio.com/AnalyticsAndDataScience/Data%20Platforms/_git/coe-business?path=%2Fscripts%2Fhive%2Fcovid-analysis&version=GBfix%2Fone_infra_tower_operate_release_106