
# 

spark-shell --packages  "com.github.davidmoten:geo:0.7.1"

+-----------------------------------+------------------------+------------+------------+--+
| customerid | time | lat | long |
+-----------------------------------+------------------------+------------+------------+--+
| b8d8b059fcf9467b62ff44b8183565c1 | 2020-03-25 06:36:32.0 | 19.060943 | 72.868246 |
| 9550e0e83991ad1be08ca9497e799523 | 2020-03-25 06:36:46.0 | 19.051504 | 72.871641 |
| 968a8e8e6603d3741f592d7c5496e13c | 2020-03-25 06:36:48.0 | 19.067537 | 72.845473 |
| 01d804c2048c01c89d51a20d074a1e5d | 2020-03-25 06:36:41.0 | 19.071961 | 72.879412 |
| 48b0021071eaa5ee889b863b243f1ff3 | 2020-03-25 06:36:30.0 | 19.045729 | 72.823411 |
+-----------------------------------+------------------------+------------+------------+--+

## Conversion

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType
import com.github.davidmoten.geo.GeoHash

import scala.collection.mutable.ListBuffer
import java.text.SimpleDateFormat
import java.util.Date

import org.apache.spark.sql.types._
import spark.implicits._


var data =
Seq(
("b8d8b059fcf9467b62ff44b8183565c1","2020-03-25 06:36:32.0",19.060943,72.868246),
("968a8e8e6603d3741f592d7c5496e13c","2020-03-25 06:36:48.0",19.067537,72.845473),
("48b0021071eaa5ee889b863b243f1ff3","2020-03-25 06:36:30.0",19.045729,72.823411),
("9550e0e83991ad1be08ca9497e799523","2020-03-25 06:36:46.0",19.051504,72.871641),
("01d804c2048c01c89d51a20d074a1e5d","2020-03-25 06:36:41.0",19.071961,72.879412)).toDF("customerid","time","lat","long")


def getGeoHash(lattitude: Double,longitude: Double,precision: Int): String = {
 GeoHash.encodeHash(lattitude,longitude,precision)
}

def getDateQtimeloc(data: DataFrame):  DataFrame = {

 // Returns: DataFrame object having DateQtime with their coresponding location for each ID
 var input = data.withColumn("id_time_lat_long_geohash",array("customerID","time","lat","long","geohash"))

	def get_new_keys(lst: Seq[Seq[String]]): Seq[Seq[String]] = {

		val pattern = "yyyy-MM-dd HH:mm:ss.SSS"
		val df = new SimpleDateFormat(pattern)
		val list_keys = ListBuffer[Seq[String]]()
	  
	    val timestamp_event= lst.map{ row => df.parse(row(1)) }
	    val minutes_of_day_event = timestamp_event.map{ timestamp => timestamp.getHours * 60 + timestamp.getMinutes}
	  
		for (window <- 0 to 287) {
		  val nearest_score_time_called = minutes_of_day_event.map { event =>(window * 5 + 5 / 2 - event).abs }
	      val minpos = nearest_score_time_called.indexOf(nearest_score_time_called.min)
		  val loc = (lst(minpos)(2),lst(minpos)(3))
		  val geohash = lst(minpos)(4)
		  val date = lst(minpos)(1).split(' ')(0)
		  list_keys += Seq(date,window.toString,geohash,loc.toString)
		}

	  list_keys.toSeq
	}

  val udf_get_new_keys = udf[Seq[Seq[String]],Seq[Seq[String]]](get_new_keys)
  input = input.groupBy("customerID").agg(collect_set("id_time_lat_long_geohash").alias("id_time_lat_long_geohash"))
  input.withColumn("new_keys",udf_get_new_keys(col("id_time_lat_long_geohash")))
}

val geoHashUdf = udf[String,Double,Double,Int](getGeoHash)
data = data.withColumn("geohash", geoHashUdf(col("lat"),col("long"),lit(8)))

getDateQtimeloc(data).show


// data.show(false)

var input = data.withColumn("id_time_lat_long_geohash",array("customerID","time","lat","long","geohash"))
input = input.groupBy("customerID").agg(collect_set("id_time_lat_long_geohash").alias("id_time_lat_long_geohash"))

def get_new_keys(lst: Seq[Seq[String]]): Seq[Seq[String]] = {

	val pattern = "yyyy-MM-dd HH:mm:ss.SSS"
	val df = new SimpleDateFormat(pattern)
	
	val timestamp_event = ListBuffer[Date]()
	val minutes_of_day_event = ListBuffer[Int]()
	val list_keys = ListBuffer[Seq[String]]()
    val nearest_score_time_called = ListBuffer[Int]()

    for ( row <- lst ) {
      timestamp_event +=df.parse(row(1))
	}

	for ( timestamp <- timestamp_event ) {
      minutes_of_day_event += timestamp.getHours*60 + timestamp.getMinutes
	}

	for (window <- 0 to 287) {

	  minutes_of_day_event.foreach { 
	  	event => nearest_score_time_called += (window*5+5/2 - event).abs
	  }

	  val minpos = nearest_score_time_called.indexOf(nearest_score_time_called.min)

	  val loc = (lst(minpos)(2),lst(minpos)(3))
	  val geohash = lst(minpos)(4)
	  val date = lst(minpos)(1).split(' ')(0)
      println(s"Record is ${nearest_score_time_called.min} ${minpos} ${loc} ${geohash} ${date}")
	  list_keys += Seq(date,window.toString,geohash,loc.toString)
	}

  list_keys.toSeq
}

val udf_get_new_keys =  udf[Seq[Seq[String]],Seq[Seq[String]]](get_new_keys)
val output = input.withColumn("new_keys",udf_get_new_keys(col("id_time_lat_long_geohash")))
output.show


## Python code

 def get_new_keys(lst):
        timestamp_event = [dt.datetime.strptime(row[1], "%Y-%m-%d %H:%M:%S") for row in lst[0]]
        minutes_of_day_event = [timestamp.hour*60+timestamp.minute for timestamp in timestamp_event]
        list_keys=[]
        for window in range(0,int(1440/5)):
            nearest_score_time_called = [abs(window*5+5/2 - minutes_of_day_event) for minutes_of_day_event in minutes_of_day_event]
            minpos = nearest_score_time_called.index(min(nearest_score_time_called))
            loc = lst[0][minpos][2:4]
            geohash = lst[0][minpos][4]
            date = lst[0][minpos][1].split(' ')[0]
            list_keys.append([date,str(window),geohash,str(loc)])
        return list_keys



import java.text.SimpleDateFormat
import java.util.Date

val pattern = "yyyy-MM-dd HH:mm:ss.SSS"
val df = new SimpleDateFormat(pattern)
val timestamp_event=df.parse("2020-03-25 06:36:30.0")

minutes_of_day_event = timestamp_event.getHours*60+timestamp_event.getMinutes


