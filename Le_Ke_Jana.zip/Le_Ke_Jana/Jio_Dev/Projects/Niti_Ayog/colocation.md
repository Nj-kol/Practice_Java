
## Query

```sql
with infected_colocate as (
    select 
    person_id, 
    min(trace_start_date) as trace_start_date, 
    max(trace_end_date) as trace_end_date, 
    max(vds_score) as vds_score 
    from( 
        select person_id, trace_start_date,trace_end_date,vds_score 
        from network_dev.pawank1_infected_data
        union 
        select infected_person_id,infected_date,partition_date,score 
        from network_dev.shivam_colocate_table
        where infected_date = ${partition_date} 
        ) 
    where col.vds_score = cast(${vds_score} as int) 
    group by col.person_id
 ) 
 Select 
 cvd_ctxt.date_time5_geo_hash as date_time5_geo_hash, 
 cvd_ctxt.perid_lat_long_values as pid_lat_long_cvd_ctxt, 
 cont_ppl.pid_lat_long as pid_lat_long_ctxt_ppl 
 from ( 
    select 
     concat(cont_map_col[0],":",cont_map_col[2],":",cont_map_col[1]) as date_time5_geo_hash,
     collect_set(array(customerid,cont_map_col[3])) as perid_lat_long_values, 
     c.partition_date, c.vds_score
      from (
        select cont_map.customerid, 
        cont_map.date_time5_geo_hash_lat_long, 
        cont_map.partition_date,
        infctd.vds_score 
        from infected_colocate as infctd inner join (
            select customerid, date_time5_geo_hash_lat_long, partition_date 
            from network_dev.shivam_people_to_context_mapping_po 
            where partition_date = ${partition_date}
            ) cont_map 
            on cont_map.customerid = infctd.person_id 
            where cont_map.partition_date 
            between infctd.trace_start_date and infctd.trace_end_date
            ) c 
            lateral view explode(date_time5_geo_hash_lat_long) Pep_to_cont_map cont_map_col 
            group by date_time5_geo_hash, partition_date,vds_score) cvd_ctxt inner join 
            (
                select * from network_dev.shivam_context_people_to_mapping_po 
                where partition_date = ${partition_date}
            ) cont_ppl 
            on cvd_ctxt.date_time5_geo_hash = cont_ppl.date_geohash8_time5 
            and cvd_ctxt.partition_date = cont_ppl.partition_date' 5 "390" 0.005 "network_dev.shivam_colocate_table" \"2020-03-21\"
```

## Driver

```bash
#! /bin/bash
/usr/hdp/current/spark2-client/bin/spark-submit \
--class com.jio.bdcoe.covid.tracking.ColocationGenerator \
--name "Colocation_Generator_new_approach" \
--master yarn \
--deploy-mode cluster \
--driver-memory 8g \
--executor-memory 30g \
--num-executors 65 \
--executor-cores 6 \
--files /usr/hdp/current/spark2-client/conf/hive-site.xml \
--conf 'spark.serializer=org.apache.spark.serializer.KryoSerializer' \
--conf 'spark.hadoop.mapreduce.fileoutputcommitter.marksuccessfuljobs=false' \
--conf 'spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2' \
--conf spark.executor.memoryOverhead=4g \
--conf spark.sql.shuffle.partitions=390 \
--queue development \
/home/Prem7.Kumar/covid19/coe-business-assembly-0.8.4.jar
```