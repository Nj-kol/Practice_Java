
# OLAP Operations

* OLAP operations usually comprises the following :

1. Pivoting

* It is the technique of changing from one-dimensional orientation
  to another

* It is also called *Rotation*

2. Slice and Dice

* In Slice,

3. Rollup and drill down

* Rollup converts data will finer granualarity to coarser granuality
* Drill down converts data will coarser granualarity to finer granuality

