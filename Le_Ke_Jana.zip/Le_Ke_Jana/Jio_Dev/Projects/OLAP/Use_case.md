# Use Case

Average downloads across vendors

## Dimension Hierarchy

Make -> Model -> IMEI 

*Sample*

SELECT make,model,imei, avg(rlc_pdu_download_volume) as avg_downlod_volume
FROM network.lsr_andhrapradesh_po 
WHERE make IN ('SAMSUNG','LYF')
GROUP BY make,model,imei WITH CUBE
ORDER BY make DESC NULLS LAST,model DESC NULLS LAST, imei DESC NULLS LAST
LIMIT 100;

## ETL 

**Create table for persisting cube data**

CREATE TABLE network.nilanjan_avg_downloads_cube (
make string,
model string,
imei string,
avg_downlod_volume decimal(38,2)) 
STORED AS ORC;

**Build Cube with Common Table Expression**

WITH avg_downloads AS (
	SELECT make,model,imei, avg(rlc_pdu_download_volume) as avg_downlod_volume
	FROM network.lsr_andhrapradesh_po 
	GROUP BY make,model,imei WITH CUBE
	ORDER BY make DESC NULLS LAST,model DESC NULLS LAST, imei DESC NULLS LAST
)
INSERT OVERWRITE TABLE network.nilanjan_avg_downloads_cube
SELECT
make,model,imei,avg_downlod_volume
FROM avg_downloads;

## Reporting with Multi-Dimentional Aggregation*

// what is the average download for a user who uses samsung phone irrespective of model

select * 
from network.nilanjan_avg_downloads_cube 
where make='SAMSUNG';

// For a manufacturer(make), what is the average download

select * 
from network.nilanjan_avg_downloads_cube 
where make='SAMSUNG'
and model is null
and imei is null;

// For a particular model, what is the average download

select * 
from network.nilanjan_avg_downloads_cube 
where model='SM-Z400F'
and make is null
and imei is null

**Housekeeping**

select count(1) as num_rec from network.nilanjan_avg_downloads_cube;
select count(distinct(imei)) from network.nilanjan_avg_downloads_cube;
select * from network.nilanjan_avg_downloads_cube limit 10;
select * from network.nilanjan_avg_downloads_cube where make='SAMSUNG' limit 10;

