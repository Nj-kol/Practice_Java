
# Data Cubes

* Data cube takes data from the star schema

* A cube is a data structure that has :

  1. Dimensions ( Branches, Products, dates  )
  2. Measures   ( Inside cell intersections )

* Each *Dimension* has a number of *Members*
  
  Ex - Branches : London, Sheifield
       Products : drinks, fruits, chips

* Members have *attributes*, such as name/description

* *Measures* inside the cube **will always be numeric**

## Dimensions vs Measures

To make sense of using cubes for building graphs, it helps to think as :

*Dimensions members* provide the *labels* of column of the graph ( = text )

*Measures* provide the height of the bars of the graph ( = numeric )

References
============
Basics of Data Cubes: https://www.youtube.com/watch?v=XDrZ3kt1tUg
Playlist of Mathew love : https://www.youtube.com/channel/UCSfwTRXNODsuqF_qFWD5AuQ/videos
