

sbt new scala/scala-seed.g8

coe-api-notifications


# Slick

Note: A Database object usually manages a thread pool and a connection pool. You should always shut it down properly when it is no longer needed (unless the JVM process terminates anyway). Do not create a new Database for every database operation. A single instance is meant to be kept alive for the entire lifetime your your application.

Referneces
==========
https://scala-slick.org/doc/3.3.2/database.html
https://scala-slick.org/doc/3.3.2/gettingstarted.html
https://github.com/slick/slick/issues/1667

https://medium.com/@kennajenifer1234/scala-tutorial-create-crud-with-slick-and-mysql-1b0a5092899f

https://www.becompany.ch/en/blog/2016/12/15/slick-dos-and-donts

https://adekunleba.github.io/scalalang/scalaandslick


Multi-Way Trees : http://www.cse.iitd.ac.in/~mausam/courses/col106/autumn2017/lectures/10-234trees.pdf

https://code.google.com/archive/p/java-algorithms-implementation/
https://github.com/phishman3579/java-algorithms-implementation

