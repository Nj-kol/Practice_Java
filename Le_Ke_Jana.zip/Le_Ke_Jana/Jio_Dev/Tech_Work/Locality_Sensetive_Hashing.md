# Localilty Sensetive Hashing ( Min hashing )

* Find similar items in two datsets

* Use Cases
  - Near neighbour seach
  - Clustering

Locality Sensitive Hashing By Spark : https://www.youtube.com/watch?v=Ha7_Vf2eZvQ


https://github.com/soundcloud/cosine-lsh-join-spark

Google S2 cels

To look for
- Shingles


* Distance functions
  - Jaccard ( MinHash )
  - Cosine
  - Hamming

  libraryDependencies += "com.soundcloud" % "cosine-lsh-join-spark_2.11" % "1.0.1"