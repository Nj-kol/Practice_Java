
# RR Flow

## Initial

* Change Date
* Change Title
* Change Author

/ogg1/hpsm.device2m1 ( 5.3 G )

/ogg1/temipadmin.cibase (87.5 G )

* If a failure happens, and a computation is *retried*, the resukt is same as if each record would
  have been processed exactly-once. 

* Exactly-once does not mean there are no retries

# Error Scenarios

## Duplicate writes in sink/target system

* This can happen due to retries in writing to target

* Can solved by making writes idempotent ( upserts )

## Duplicate state updates in the processing engine.

* This can happen in a stateful application in a distributed engine where can the node 
  computing state has failed and hence is retried as part of it resiliency directives ( ex Spark )

## Re-read input

* This is where the processing engine re-reads a single record from source.

  This can happen when :

  - the processing engine, acting as a consumer, does not properly acknowledge the producer/source

  - the broker, in a system like kafka, which is responsible for sending messages to consumers
    (push model), crashes and resends a record to consumer

  - the producer of the in a system like kafka does not have strict durability guarantees
    (say, the producer sends a record to a topic, but does not receive an acknowledgement on time,
    which triggers a retry and eventually a duplicate record in topic )

# End-to-end exactly once

* To do properly do exactly-once processing, you have to have a All-or-nothing scenario where 
  - Writing the results 
  - Updating all states
  - Marking input as consumed ( acking )

## Implication of "exactly once"

* Write path
  - Idempotency
  - Atomic multi-partition writes

* Read path
  - Only read commited data

* Exactly-Once Processsing
  - Transactional read-process-write pattern

* Kafka's idempotent producer means broker side de-duplication (via producer ID and sequence no, which
  are stored in the log itself )


# Kafka Transactions

* Atomic multi-partition writes
* 2-phase commit protocol
* Aborted data can be skipped on-read by consumer



References
==========
https://www.youtube.com/watch?v=zm5A7z95pdE ( seen till 13:43 )