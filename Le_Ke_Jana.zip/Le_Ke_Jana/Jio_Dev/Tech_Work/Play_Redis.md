
## Add library

* In your *build.sbt* add :

```
// enable Play cache API (based on your Play version)
libraryDependencies += play.sbt.PlayImport.cacheApi

// include play-redis library
libraryDependencies += "com.github.karelcemus" %% "play-redis" % "2.5.1"
```

## Enable

* In the *application.conf* file located under the *conf* directory add :

```
play.modules {
  # By default, Play will load any class called Module that is defined
  # in the root package (the "app" directory), or you can define them
  # explicitly below.
  # If there are any built-in modules that you want to disable, you can list them here.
  enabled += play.api.cache.redis.RedisCacheModule
}

play.cache.redis {
  host:       10.159.21.107
  # redis server: port
  port:       30379
  # redis server: database number (optional)
  database:   0
  # authentication password (optional)
  password:   null
}
```

## Sample Implementation
  
/**
* Simple Look-aside Cache
*/
def show(id: String) = Action {
val cacheName = "my-map"
var resp : Int = 0

// get single value
val cachresp = cache.map[Int](cacheName).get(id)

cachresp match {
  case Some(value) => 
    logger.info("Cache Hit, serving values from cache")
    resp = value
  case None =>    
    logger.info("Cache Miss")
    logger.info("Fetching value from DB")
    resp = getValueFromMockDB(id)
    logger.info(s"Add value for key ${id}from cache")
    // add values into the map
    cache.map[Int](cacheName).add(id, resp)
}

Ok(s"The response from cache is ${resp}")
}


def getValueFromMockDB(id: String) : Int = {
val mockDB = Map("ABC" -> 5,"CDE" -> 6, "PRQ" -> 34, "XYZ" -> 30 )
mockDB(id)


## Changes

* In build.sbt

```
// enable Play cache API
libraryDependencies += play.sbt.PlayImport.cacheApi
libraryDependencies ++= Seq( caffeine)
```

* In ApiUtils

```
import org.apache.hive.common.util.Murmur3

/**
* Returns a hash of the query string using the Murmur hashing algorithm
*
* @param query The query String
* @return A String representing a MurMur3 hash of the query
*/
def getHashKeyFromQuery(query: String): String = {
	val normalizedQuery = query.toLowerCase()
	Murmur3.hash64(normalizedQuery.getBytes).toString()
}
```

* In HiveRepository

```
import scala.concurrent.duration._
import play.api.cache.SyncCacheApi

import bdcoe.utils.api.ApiUtils
import bdcoe.conf.ConfigLoader

class HiveRepositoryImpl @Inject() (clientMetrics: ClientMetricLogger, cache: SyncCacheApi)(implicit ec: DBExecutionContext) extends HiveRepository {

  private val config = ConfigLoader.getInstance
  private val cacheExpiryMin = config.getOrDefaultInt("com.jio.bdcoe.hive.cache.expiry.minutes")

  override def list(requestInput: HiveRequestInput): Future[String] = {
    Future {
      var hiveService: DBQueryService = null
      var res: ResponseContext = null
      val kerberosConfig: KerberosConfig = KerberosConfig(requestInput.principal, requestInput.keyTab)
      try {
        val cacheKey = ApiUtils.getHashKeyFromQuery(requestInput.query)
        var response: String = ""
        // Simple Look-aside cache implementation
        cache.get[String](cacheKey) match {
          case Some(res) => {
            logger.info("Cache Hit, serving values from cache")
            response = res
          }
          case None => {
            logger.info("Cache Miss")
            logger.info("Fetching value from Hive")
            hiveService = HiveQueryServiceFactory.getHiveQueryService(kerberosConfig)
            res = hiveService.fetchResult(requestInput.query, Math.min(requestInput.maxRows.toInt, 1000), Math.min(requestInput.maxRows.toInt, 1000), requestInput.dataFormat)
            clientMetrics.updateClientMetrics(requestInput.principal, requestInput.ipAddress, res.resultMetrics)
            response = if (StringUtils.containsIgnoreCase(requestInput.dataFormat, FormatType.JSON.toString)) {
              res.streamResult.mkString("""{"data":""", " ", "]}")
            } else res.streamResult.mkString
            cache.set(cacheKey, response,cacheExpiryMin.minutes)
            logger.info("Populated data in cache from Hive")
          }
        }
        response
      } catch {
        case th: SQLException => th.getCause() match {
          case ts: TTransportException =>
            logger.error("Refresing Connection Pool ", th)
            hiveService = HiveQueryServiceFactory.getHiveQueryService(kerberosConfig, true)
            throw th
          case ts: org.apache.hive.service.cli.HiveSQLException =>
            if ((ts.getMessage() != null || ts.getMessage().length() != 0) && ts.getMessage().contains("Invalid SessionHandle")) {
              logger.error("Refresing Connection Pool ", th)
              hiveService = HiveQueryServiceFactory.getHiveQueryService(kerberosConfig, true)
            }
            throw th
        }
        case th: Throwable =>
          logger.error("error occurred while getting data in normal endpoint", th)
          clientMetrics.updateClientMetricsOnFailure(requestInput.principal, requestInput.ipAddress)
          throw th
      } finally {
        if (res != null) {
          hiveService.cleanUp(res)
        }
      }
    }
  }
```

* In the property file

com.jio.bdcoe.hive.cache.expiry.minutes=2
