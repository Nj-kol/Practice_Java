
# Caffeine

libraryDependencies ++= Seq(caffeine)

## Accessing the Cache API

* The cache API is defined by the *AsyncCacheApi* and *SyncCacheApi* traits, depending on whether you want an asynchronous
 or synchronous implementation, and can be injected into your component like any other dependency

* For example:

```
import play.api.cache._
import play.api.mvc._
import javax.inject.Inject

class Application @Inject() (cache: AsyncCacheApi, cc: ControllerComponents) extends AbstractController(cc) {}
```

## Caching HTTP responses

You can easily create smart cached actions using standard Action composition.

Note: Play HTTP Result instances are safe to cache and reuse later.

The Cached class helps you build cached actions.

**Wiring**

```
import play.api.cache.Cached
import javax.inject.Inject

class Application @Inject() (cached: Cached, cc: ControllerComponents) extends AbstractController(cc) {}
```

* You can cache the result of an action using a fixed key like "homePage".

```
def index = cached("homePage") {
  Action {
    Ok("Hello world")
  }
}
```

If results vary, you can cache each result using a different key. In this example, each user has a different cached result.

```
def userProfile = WithAuthentication(_.session.get("username")) { userId =>
  cached(req => "profile." + userId) {
    Action.async {
      User.find(userId).map { user =>
        Ok(views.html.profile(user))
      }
    }
  }
}
```

The trait play.api.cache.CacheApi is now deprecated and should be replaced by play.api.cache.SyncCacheApi or play.api.cache.AsyncCacheApi.


{name: "John", age: 31, city: "New York"}

References
==========
https://www.playframework.com/documentation/2.8.x/ScalaCache
https://www.playframework.com/documentation/2.8.x/CacheMigration26