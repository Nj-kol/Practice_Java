package io.prometheus.client.dropwizard

import java.util
import java.util.concurrent.TimeUnit
import java.util._
import java.util.logging.{Level, Logger}

import com.codahale.metrics._
import com.codahale.metrics.Timer
import io.prometheus.client.Collector
import io.prometheus.client.Collector.{MetricFamilySamples, Type}
import io.prometheus.client.dropwizard.samplebuilder.SampleBuilder

class CustomDropwizardExports(registry: MetricRegistry, sampleBuilder: SampleBuilder) extends DropwizardExports(registry,sampleBuilder){

  private val LOGGER = Logger.getLogger(classOf[DropwizardExports].getName)

  override def fromSnapshotAndCount(dropwizardName: String, snapshot: Snapshot, count: Long, factor: Double, helpMessage: String) : MetricFamilySamples = {

    val samples: util.List[MetricFamilySamples.Sample] = Arrays.asList (
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("quantile"), Arrays.asList ("0.5"), snapshot.getMedian * factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("quantile"), Arrays.asList ("0.75"), snapshot.get75thPercentile * factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("quantile"), Arrays.asList ("0.95"), snapshot.get95thPercentile * factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("quantile"), Arrays.asList ("0.98"), snapshot.get98thPercentile * factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("quantile"), Arrays.asList ("0.99"), snapshot.get99thPercentile * factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("quantile"), Arrays.asList ("0.999"), snapshot.get999thPercentile * factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("stat"), Arrays.asList ("mean"), snapshot.getMean*factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("stat"), Arrays.asList ("median"), snapshot.getMedian*factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("stat"), Arrays.asList ("stddev"), snapshot.getStdDev*factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("stat"), Arrays.asList ("min"), snapshot.getMin*factor),
      sampleBuilder.createSample (dropwizardName, "", Arrays.asList ("stat"), Arrays.asList ("max"), snapshot.getMax*factor),
      sampleBuilder.createSample (dropwizardName, "_count", new ArrayList[String], new ArrayList[String], count)
    )

    return new Collector.MetricFamilySamples(samples.get (0).name, Collector.Type.SUMMARY, helpMessage, samples)
  }


  override def fromHistogram(dropwizardName: String, histogram: Histogram) = {
    fromSnapshotAndCount(dropwizardName, histogram.getSnapshot, histogram.getCount, 1.0, getHelpMessage(dropwizardName, histogram))
  }


  private def getHelpMessage(metricName: String, metric: Metric) = String.format("Generated from Dropwizard metric import (metric=%s, type=%s)", metricName, metric.getClass.getName)


  override def collect: util.List[Collector.MetricFamilySamples] = {

    val mfSamplesMap = new util.HashMap[String, Collector.MetricFamilySamples]
    import scala.collection.JavaConversions._
    for (entry <- registry.getGauges.entrySet) {
      addToMap(mfSamplesMap, fromGauge(entry.getKey, entry.getValue))
    }
    import scala.collection.JavaConversions._
    for (entry <- registry.getCounters.entrySet) {
      addToMap(mfSamplesMap, fromCounter(entry.getKey, entry.getValue))
    }
    import scala.collection.JavaConversions._
    for (entry <- registry.getHistograms.entrySet) {
      addToMap(mfSamplesMap, fromHistogram(entry.getKey, entry.getValue))
    }
    import scala.collection.JavaConversions._
    for (entry <- registry.getTimers.entrySet) {
      addToMap(mfSamplesMap, fromTimer(entry.getKey, entry.getValue))
    }
    import scala.collection.JavaConversions._
    for (entry <- registry.getMeters.entrySet) {
      addToMap(mfSamplesMap, fromMeter(entry.getKey, entry.getValue))
    }
    new util.ArrayList[Collector.MetricFamilySamples](mfSamplesMap.values)
  }

  private def addToMap(mfSamplesMap: util.Map[String, Collector.MetricFamilySamples], newMfSamples: Collector.MetricFamilySamples): Unit = {
    if (newMfSamples != null) {
      val currentMfSamples = mfSamplesMap.get(newMfSamples.name)
      if (currentMfSamples == null) mfSamplesMap.put(newMfSamples.name, newMfSamples)
      else {
        val samples = new util.ArrayList[MetricFamilySamples.Sample](currentMfSamples.samples)
        samples.addAll(newMfSamples.samples)
        mfSamplesMap.put(newMfSamples.name, new Collector.MetricFamilySamples(newMfSamples.name, currentMfSamples.`type`, currentMfSamples.help, samples))
      }
    }
  }


  /**
    * Export Dropwizard Timer as a histogram. Use TIME_UNIT as time unit.
    */
  override private[dropwizard] def fromTimer(dropwizardName: String, timer: Timer)

  = {

    fromSnapshotAndCount(dropwizardName, timer.getSnapshot, timer.getCount, 1.0D / TimeUnit.SECONDS.toNanos(1L), getHelpMessage(dropwizardName, timer))
  }

  /**
    * Export a Meter as as prometheus COUNTER.
    */
  override private[dropwizard] def fromMeter(dropwizardName: String, meter: Meter) = {
    val sample = sampleBuilder.createSample(dropwizardName, "_total", new util.ArrayList[String], new util.ArrayList[String], meter.getCount)
    new Collector.MetricFamilySamples(sample.name, Type.COUNTER, getHelpMessage(dropwizardName, meter), util.Arrays.asList(sample))
  }


  /**
    * Export counter as Prometheus <a href="https://prometheus.io/docs/concepts/metric_types/#gauge">Gauge</a>.
    */
  override private[dropwizard] def fromCounter(dropwizardName: String, counter: Counter) = {
    val sample = sampleBuilder.createSample(dropwizardName, "", new util.ArrayList[String], new util.ArrayList[String], new java.lang.Long(counter.getCount).doubleValue)
    new Collector.MetricFamilySamples(sample.name, Type.GAUGE, getHelpMessage(dropwizardName, counter), util.Arrays.asList(sample))
  }

  /**
    * Export gauge as a prometheus gauge.
    */
  override private[dropwizard] def fromGauge(dropwizardName: String, gauge: Gauge[_]): Collector.MetricFamilySamples = {
    val obj = gauge.getValue
    var value = .0
    if (obj.isInstanceOf[Number]) value = obj.asInstanceOf[Number].doubleValue
    else if (obj.isInstanceOf[Boolean]) value = if (obj.asInstanceOf[Boolean]) 1
    else 0
    else {
      LOGGER.log(Level.FINE, String.format("Invalid type for Gauge %s: %s", Collector.sanitizeMetricName(dropwizardName), if (obj == null) "null"
      else obj.getClass.getName))
      return null
    }
    val sample = sampleBuilder.createSample(dropwizardName, "", new util.ArrayList[String], new util.ArrayList[String], value)
    new Collector.MetricFamilySamples(sample.name, Type.GAUGE, getHelpMessage(dropwizardName, gauge), util.Arrays.asList(sample))
  }
}
