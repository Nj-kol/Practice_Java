package com.jio.bdcoe.services.metrics

import io.prometheus.client.{Collector, CollectorRegistry}
import io.prometheus.client.dropwizard.{CustomDropwizardExports, DropwizardExports}
import io.prometheus.client.dropwizard.samplebuilder.{CustomMappingSampleBuilder, MapperConfig}
import javax.inject.{Inject, Singleton}
import play.api.{Configuration, Logger}
import play.api.inject.ApplicationLifecycle
import java.util.{Arrays, HashMap}

import scala.concurrent.Future

trait PrometheusMetrics {
  val collectorRegistry : CollectorRegistry
  def collector: Collector
}

@Singleton
class PrometheusMetricsImpl @Inject() (lifecycle: ApplicationLifecycle, configuration: Configuration, metrics: Metrics) extends PrometheusMetrics {
  private val innerLogger: Logger = Logger(classOf[PrometheusMetricsImpl])

  val collectorRegistry: CollectorRegistry = new CollectorRegistry()

  val metricsAppName = configuration.get[String]("metrics.appName")

  // Acive Requests Metric Config
  val activeRequestsCountConfig =  new MapperConfig()
  activeRequestsCountConfig.setMatch(metricsAppName + ".*.*.active_requests_count")
  activeRequestsCountConfig.setName(metricsAppName + ".active_requests_count")
  val activeRequestsCountLabel = new HashMap[String,String]()
  activeRequestsCountLabel.put("level", "${0}")
  activeRequestsCountLabel.put("ip_addr", "${1}")
  activeRequestsCountConfig.setLabels(activeRequestsCountLabel)

  // Response Size Metric Config
  val responseSizeConfig =  new MapperConfig()
  responseSizeConfig.setMatch(metricsAppName + ".*.*.response_size_bytes")
  responseSizeConfig.setName(metricsAppName + ".response_size_bytes")
  val responseSizeLabel = new HashMap[String,String]()
  responseSizeLabel.put("level", "${0}")
  responseSizeLabel.put("ip_addr", "${1}")
  responseSizeConfig.setLabels(responseSizeLabel)

  // Response Time Metric Config
  val responseTimeConfig =  new MapperConfig()
  responseTimeConfig.setMatch(metricsAppName + ".*.*.response_time_seconds")
  responseTimeConfig.setName(metricsAppName+ ".response_time_seconds")
  val responseTimeLabel = new HashMap[String,String]()
  responseTimeLabel.put("level", "${0}")
  responseTimeLabel.put("ip_addr", "${1}")
  responseTimeConfig.setLabels(responseTimeLabel)

  // Status Codes Metric Config
  val statusCodesConfig =  new MapperConfig()
  statusCodesConfig.setMatch(metricsAppName + ".*.*.status_code.*")
  statusCodesConfig.setName(metricsAppName + ".status_code")
  val statusCodesLabel = new HashMap[String,String]()
  statusCodesLabel.put("level", "${0}")
  statusCodesLabel.put("ip_addr", "${1}")
  statusCodesLabel.put("status", "${2}")
  statusCodesConfig.setLabels(statusCodesLabel)

  val responseNumRowsConfig =  new MapperConfig()
  responseNumRowsConfig.setMatch(metricsAppName + ".*.*.response_num_rows")
  responseNumRowsConfig.setName(metricsAppName + ".response_num_rows")
  val responseNumRowsLabel = new HashMap[String,String]()
  responseNumRowsLabel.put("level", "${0}")
  responseNumRowsLabel.put("ip_addr", "${1}")
  responseNumRowsConfig.setLabels(responseNumRowsLabel)


  val sampleBuilder = new CustomMappingSampleBuilder(Arrays.asList(activeRequestsCountConfig,responseSizeConfig,responseTimeConfig,statusCodesConfig,responseNumRowsConfig))
  def collector: Collector = new CustomDropwizardExports(metrics.defaultRegistry,sampleBuilder).register(collectorRegistry)


  def onStart(): Unit = {
    collectorRegistry.register(collector)
  }

  def onStop(): Unit = {
    collectorRegistry.unregister(collector)
  }

  onStart()
  lifecycle.addStopHook(() => Future.successful{ onStop() })

}
