package com.jio.bdcoe.services.metrics

import javax.inject.Inject
import akka.stream.Materializer
import play.api.mvc._
import play.api.http.Status
import com.codahale.metrics._
import com.codahale.metrics.MetricRegistry.name
import play.api.Configuration

import scala.concurrent.{ExecutionContext, Future}

trait MetricsFilter extends Filter

class DisabledMetricsFilter @Inject()(implicit val mat: Materializer) extends MetricsFilter {
  def apply(nextFilter: (RequestHeader) => Future[Result])(rh: RequestHeader): Future[Result] = {
    nextFilter(rh)
  }
}

class MetricsFilterImpl @Inject() (metrics: Metrics, configuration: Configuration)(implicit val mat: Materializer, val ec: ExecutionContext) extends MetricsFilter {

  def registry: MetricRegistry = metrics.defaultRegistry

  /** Specify a meaningful prefix for metrics
    *
    * Defaults to classOf[MetricsFilter].getName for backward compatibility as
    * this was the original set value.
    *
    */
  def labelPrefix: String = configuration.get[String]("metrics.appName") + ".global.app"

  /** Specify which HTTP status codes have individual metrics
    *
    * Statuses not specified here are grouped together under otherStatuses
    *
    * Defaults to 200, 400, 401, 403, 404, 409, 201, 304, 307, 500, which is compatible
    * with prior releases.
    */
  def knownStatuses = Seq(Status.OK, Status.BAD_REQUEST, Status.FORBIDDEN, Status.NOT_FOUND,
    Status.CREATED, Status.TEMPORARY_REDIRECT, Status.INTERNAL_SERVER_ERROR, Status.CONFLICT,
    Status.UNAUTHORIZED, Status.NOT_MODIFIED)


  def statusCodes: Map[Int, Meter] = knownStatuses.map(s => s -> registry.meter(name(labelPrefix + ".status_code", s.toString))).toMap

  def requestsTimer: Timer = registry.timer(name(labelPrefix, "response_time_seconds"))
  def activeRequests: Counter = registry.counter(name(labelPrefix, "active_requests_count"))
  def otherStatuses: Meter = registry.meter(name(labelPrefix + ".status_code", "other_status_codes"))

  def apply(nextFilter: (RequestHeader) => Future[Result])(rh: RequestHeader): Future[Result] = {

    val context = requestsTimer.time()

    def logCompleted(result: Result): Unit = {
      activeRequests.dec()
      context.stop()
      statusCodes.getOrElse(result.header.status, otherStatuses).mark()
      result.body.asJava.isKnownEmpty
    }

    activeRequests.inc()
    nextFilter(rh).transform(
      result => {
        logCompleted(result)
        result
      },
      exception => {
        logCompleted(Results.InternalServerError)
        exception
      }
    )
  }
}