package com.jio.bdcoe.services.metrics

import java.util.concurrent.TimeUnit

import com.jio.bdcoe.services.api.data.ResultMetrics
import com.codahale.metrics.MetricRegistry.name
import com.codahale.metrics._
import javax.inject.{Inject, Singleton}
import play.api.Configuration
import play.api.http.Status
import play.api.mvc.{Result, Results}

import scala.collection.mutable
import scala.concurrent.{ExecutionContext, Future}

trait MetricLoggingContext{
  val clientMetricMap: mutable.HashMap[String, ClientMetrics]
  def registerClient(clientId: String,ip: String): Unit
  def apply(clientId: String,ip:String,x: Future[Result]): Future[Result]
  def updateClientMetrics(clientId:String, ip:String,resMetrics: ResultMetrics): Unit
  def updateClientMetricsOnFailure(principal: String, ipAddress: String): Unit
}

case class ClientMetrics(statusCodes:Map[Int, Meter],requestsTimer: Timer,activeRequests: Counter,otherStatuses: Meter,responseSizes:Histogram,responseNumRows:Histogram)

@Singleton
class ClientMetricLogger @Inject() (metrics: Metrics,configuration: Configuration) (implicit val ec: ExecutionContext) extends MetricLoggingContext{

  def registry: MetricRegistry = metrics.defaultRegistry
  def labelPrefix: String = configuration.get[String]("metrics.appName") + ".client_"


  val clientMetricMap: mutable.HashMap[String, ClientMetrics] = new mutable.HashMap[String,ClientMetrics]()

  def registerClient(clientId: String,ip: String) = {

    val clientKey = clientId + "_" + ip

    if(!clientMetricMap.contains(clientKey)){
      val metricPrefix: String = labelPrefix + clientId + "." + ip


      def knownStatuses = Seq(Status.OK, Status.BAD_REQUEST, Status.FORBIDDEN, Status.NOT_FOUND,
        Status.CREATED, Status.TEMPORARY_REDIRECT, Status.INTERNAL_SERVER_ERROR, Status.CONFLICT,
        Status.UNAUTHORIZED, Status.NOT_MODIFIED)
      def statusCodes: Map[Int, Meter] = knownStatuses.map(s => s -> registry.meter(name(metricPrefix+".status_code", s.toString))).toMap

      def requestsTimer: Timer = registry.timer(name(metricPrefix, "response_time_seconds"))
      def activeRequests: Counter = registry.counter(name(metricPrefix, "active_requests_count"))
      def otherStatuses: Meter = registry.meter(name(metricPrefix+".status_code", "other_status_codes"))
      def responseSizes: Histogram = registry.histogram(name(metricPrefix,"response_size_bytes"))
      def responseNumRows: Histogram = registry.histogram(name(metricPrefix,"response_num_rows"))
      clientMetricMap(clientKey) = ClientMetrics(statusCodes,requestsTimer,activeRequests,otherStatuses,responseSizes,responseNumRows)
    }

  }

  def apply(clientId: String, ip:String, res: Future[Result]): Future[Result] = {
    val clientKey = clientId + "_" + ip

    def logCompleted(result: Result): Unit = {
      clientMetricMap(clientKey).statusCodes.getOrElse(result.header.status, clientMetricMap(clientKey).otherStatuses).mark()
    }

    clientMetricMap(clientKey).activeRequests.inc()

    res.transform(result =>  {
      logCompleted(result)
      result},{
      exception => {
        logCompleted(Results.InternalServerError)
        exception
      }
    })
  }

  def updateClientMetrics(clientId:String, ip:String,resMetrics: ResultMetrics) = {
    val clientKey = clientId.replaceAll("\\.","_") + "_" + ip.replaceAll("\\.","_")
    clientMetricMap(clientKey).responseSizes.update(resMetrics.resultSize.get())
    clientMetricMap(clientKey).responseNumRows.update(resMetrics.resultNumRows.get())
    clientMetricMap(clientKey).requestsTimer.update((System.nanoTime() - resMetrics.startTime.get()),TimeUnit.NANOSECONDS)
    clientMetricMap(clientKey).activeRequests.dec()
  }

  def updateClientMetricsOnFailure(clientId: String, ip: String) = {
    val clientKey = clientId.replaceAll("\\.","_") + "_" + ip.replaceAll("\\.","_")
    clientMetricMap(clientKey).activeRequests.dec()
  }

}