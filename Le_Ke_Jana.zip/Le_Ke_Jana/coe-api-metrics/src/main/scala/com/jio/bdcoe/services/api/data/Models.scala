package com.jio.bdcoe.services.api.data

import java.util.concurrent.atomic.AtomicLong

/**
  * Type for defining result specific metrics.
  * @param resultSize -   size in bytes of the resultant records
  * @param resultNumRows - number of records in the result.
  */
case class ResultMetrics(resultSize: AtomicLong, resultNumRows: AtomicLong, startTime: AtomicLong)
