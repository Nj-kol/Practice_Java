
# COE API Metrics

Common module containing logic for display API metrics

## Usage

```scala
class Module(environment: Environment, configuration: Configuration) extends AbstractModule with ScalaModule {

  override def configure() = {

    if (configuration.get[Boolean]("metrics.enabled")) {
      bind[Metrics].to[MetricsImpl].in[Singleton]
      bind[MetricsFilter].to[MetricsFilterImpl].in[Singleton]
      bind[MetricLoggingContext].to[ClientMetricLogger].in[Singleton]
      bind[PrometheusMetrics].to[PrometheusMetricsImpl].in[Singleton]
      bind[MySQLRepository].to[MySQLRepositoryImpl].in[Singleton]
    } else {
      bind[MetricsFilter].to[DisabledMetricsFilter].in[Singleton]
      bind[Metrics].to[DisabledMetrics].in[Singleton]
    }
  }


class MySQLRepositoryImpl @Inject() (clientMetrics: ClientMetricLogger,conf: ConfigLoader)(implicit ec: DBExecutionContext) extends MySQLRepository {

...
clientMetrics.updateClientMetrics(clientId, requestInput.ipAddress, streamResponse.get.resultMetrics)
clientMetrics.updateClientMetricsOnFailure(clientId, requestInput.ipAddress)
}
```